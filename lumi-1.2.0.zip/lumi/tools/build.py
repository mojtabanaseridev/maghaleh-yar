from pathlib import Path
import re,gzip,json
root=Path(__file__).resolve().parents[1]
def jsmin(source):
 pattern=re.compile(r'''(?P<space>\s+)|(?P<comment>//[^\n]*|/\*[\s\S]*?\*/)|(?P<string>'(?:\\.|[^'\\])*'|"(?:\\.|[^"\\])*")|(?P<word>[A-Za-z_$][\w$]*|\d+(?:\.\d+)?)|(?P<op>===|!==|=>|==|!=|<=|>=|\+\+|--|&&|\|\||\+=|-=)|(?P<punct>[^\s])''')
 tokens=[m.group() for m in pattern.finditer(source) if m.lastgroup not in ('space','comment')]
 out=[]
 for token in tokens:
  if out and (re.search(r'[\w$]$',out[-1]) and re.match(r'[\w$]',token) or out[-1].endswith('+') and token.startswith('+') or out[-1].endswith('-') and token.startswith('-')):out.append(' ')
  out.append(token)
 return ''.join(out)
js=root/'assets/js/lumi-slider.js'
js.with_name('lumi-slider.min.js').write_text(jsmin(js.read_text()))
css=root/'assets/css/lumi-slider.css'
s=re.sub(r'/\*[\s\S]*?\*/','',css.read_text());s=re.sub(r'\s+',' ',s);s=re.sub(r'\s*([{}:;,>])\s*',r'\1',s);s=s.replace(';}', '}').strip()
css.with_name('lumi-slider.min.css').write_text(s)
report={str(p.relative_to(root)):{'bytes':p.stat().st_size,'gzip_bytes':len(gzip.compress(p.read_bytes(),compresslevel=9,mtime=0))} for p in (js,js.with_name('lumi-slider.min.js'),css,css.with_name('lumi-slider.min.css'))}
(root/'tests/sizes.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
