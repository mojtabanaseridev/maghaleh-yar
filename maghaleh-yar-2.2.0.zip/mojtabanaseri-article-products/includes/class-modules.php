<?php
namespace Mojtabanaseri\ArticleProducts;
if (!defined('ABSPATH')) { exit; }
/** Local module registry. Stored data never depends on a module being enabled. */
final class Modules {
    public static function definitions() {
        return array(
            'products'=>array('title'=>'محصولات','description'=>'نمایش و مدیریت باکس محصولات فروشگاه.','locked'=>true,'dependencies'=>array('core'),'files'=>array('includes/class-product-options.php','includes/class-features.php')),
            'cta'=>array('title'=>'دعوت به اقدام','description'=>'نمایش و ویرایش دعوت‌های به اقدام.','locked'=>true,'dependencies'=>array('core'),'files'=>array('modules/cta/class-cta-renderer.php')),
            'table'=>array('title'=>'جدول','description'=>'ساخت، ویرایش و نمایش جدول‌های مقاله.','locked'=>true,'dependencies'=>array('core'),'files'=>array('modules/table/class-table-renderer.php','assets/table.css')),
            'schedule'=>array('title'=>'زمان‌بندی','description'=>'تنظیم تاریخ پایان؛ تاریخ‌های قبلی در حالت خاموش هم رعایت می‌شوند.','locked'=>false,'dependencies'=>array('core'),'files'=>array('modules/schedule/schedule.js','modules/schedule/schedule.css')),
            'transfer'=>array('title'=>'ورود و بکاپ','description'=>'ورود اکسل و CSV، بکاپ JSON و بازیابی؛ حذف باکس مستقل باقی می‌ماند.','locked'=>false,'dependencies'=>array('table'),'files'=>array('includes/class-transfer-module.php','modules/transfer/class-table-import.php','modules/transfer/import.js','assets/transfer.js')),
            'connection'=>array('title'=>'اتصال','description'=>'لایسنس و اخبار اختیاری؛ این ماژول همیشه روشن است.','locked'=>true,'dependencies'=>array('core'),'files'=>array('includes/class-connection.php','assets/connection.js')),
            'elementor'=>array('title'=>'المنتور','description'=>'ویجت‌های مقاله‌یار؛ خاموش‌کردن، ویجت‌های موجود را از المنتور خارج می‌کند.','locked'=>false,'dependencies'=>array('core'),'files'=>array('includes/class-elementor-widget.php')),
            'acf'=>array('title'=>'اتصال ACF','description'=>'خواندن محصولات از فیلد ACF؛ باکس‌های ذخیره‌شده مستقل باقی می‌مانند.','locked'=>false,'dependencies'=>array('products'),'files'=>array('modules/acf/class-acf-integration.php'))
        );
    }
    public static function state() {
        $raw=get_option('mnps_modules',null);
        if (null===$raw) { $raw=array_fill_keys(array_keys(self::definitions()),true); add_option('mnps_modules',$raw,'',true); }
        $out=array();foreach(self::definitions()as$id=>$module)$out[$id]=$module['locked']||!is_array($raw)||!array_key_exists($id,$raw)||!empty($raw[$id]);
        return $out;
    }
    public static function enabled($id) { $state=self::state();return isset($state[$id])&&$state[$id]; }
    public static function require_enabled($id) {
        if (!self::enabled($id)) { wp_send_json_error(array('message'=>'این ماژول خاموش است؛ از صفحه ماژول‌ها روشنش کنید.'),403); }
    }
    public static function class_file($name) {
        $map=array(
            'TableRenderer'=>array('modules/table/class-table-renderer.php','table'),
            'CTARenderer'=>array('modules/cta/class-cta-renderer.php','cta'),
            'TableImport'=>array('modules/transfer/class-table-import.php','transfer'),
            'TransferModule'=>array('includes/class-transfer-module.php','transfer'),
            'ACFIntegration'=>array('modules/acf/class-acf-integration.php','acf'),
            'Elementor_Widget'=>array('includes/class-elementor-widget.php','elementor'),
            'Elementor_CTA_Widget'=>array('includes/class-elementor-widget.php','elementor'),
            'Elementor_Design'=>array('includes/class-elementor-widget.php','elementor')
        );
        if (!isset($map[$name]))return null;
        return self::enabled($map[$name][1])?$map[$name][0]:false;
    }
    public static function boot() {
        self::state();self::connection_hooks();
        self::transfer_hooks();
        if(is_admin())Workflow::boot();
        add_action('wp_ajax_mnps_modules_save',array(__CLASS__,'save'));
    }
    public static function transfer_hooks(){
        foreach(array_merge(array('delete_review','delete_commit'),self::enabled('transfer')?array('export','import_review','import_commit'):array())as$action)add_action('wp_ajax_mnps_'.$action,array(__NAMESPACE__.'\\Transfer',$action.'_api'));
    }
    public static function connection_hooks() {
        $c=__NAMESPACE__.'\\Connection';
        add_action('admin_post_mnps_connection',array($c,'save'));
        add_action('wp_ajax_mnps_connection_check',array($c,'check'));
        add_action('wp_dashboard_setup',array($c,'dashboard'));
        add_filter('default_hidden_meta_boxes',array($c,'hidden'),10,2);
        add_filter('hidden_meta_boxes',array($c,'hide_unselected'),10,2);
        add_action('added_user_meta',array($c,'news_choice'),10,4);
        add_action('updated_user_meta',array($c,'news_choice'),10,4);
        add_action('mnps_service_news_refresh',array($c,'sync'));
        add_action('mnps_service_sync',array($c,'sync'));
        add_action('rest_api_init',array(__CLASS__,'connection_routes'));
        add_action('wp_ajax_mnps_dismiss_notice',array($c,'dismiss'));
        add_action('admin_init',array($c,'privacy'));
    }
    public static function connection_routes() {
        register_rest_route('maghaleh-yar/v1','/challenge',array('methods'=>'GET','permission_callback'=>'__return_true','callback'=>function($request){
            $id=sanitize_key($request->get_param('id'));$value=get_transient('mnps_service_challenge_'.$id);return $value?rest_ensure_response(array('proof'=>$value)):new \WP_Error('not_found','Challenge expired',array('status'=>404));
        }));
    }
    public static function save() {
        check_ajax_referer('mnps_modules','nonce');
        if(!current_user_can('manage_options'))wp_send_json_error(array('message'=>'اجازه تغییر ماژول‌ها را ندارید.'),403);
        $id=sanitize_key(wp_unslash($_POST['module']??''));$defs=self::definitions();
        if(!isset($defs[$id])||$defs[$id]['locked'])wp_send_json_error(array('message'=>'این ماژول همیشه روشن است.'),400);
        $state=self::state();$state[$id]=isset($_POST['enabled'])&&$_POST['enabled']==='1';
        if(!update_option('mnps_modules',$state,true)&&get_option('mnps_modules')!==$state)wp_send_json_error(array('message'=>'ذخیره انجام نشد؛ دوباره تلاش کنید.'),500);
        wp_send_json_success(array('enabled'=>$state[$id],'message'=>'وضعیت ماژول ذخیره شد.'));
    }
}
