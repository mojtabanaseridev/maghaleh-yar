<?php
/** Preserve Elementor documents and user content when uninstalling. @package Lumi */
defined( 'ABSPATH' ) || exit;
defined( 'WP_UNINSTALL_PLUGIN' ) || exit;
// Lumi creates no options or term metadata. Never delete Elementor page data.
