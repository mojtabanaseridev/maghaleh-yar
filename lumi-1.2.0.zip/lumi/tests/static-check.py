from pathlib import Path
import re,json
root=Path(__file__).resolve().parents[1];results=[]
for p in root.rglob('*.php'):
 s=p.read_text()
 assert "defined( 'ABSPATH' ) || exit;" in s,p
 # Lexical structure check only: not a replacement for php -l.
 stripped=re.sub(r"'(?:\\.|[^'\\])*'|\"(?:\\.|[^\"\\])*\"|/\*[\s\S]*?\*/|//[^\n]*",'',s)
 assert not re.search(r'\?->|\b(?:readonly|mixed|never)\b|\bmatch\s*\(',stripped),p
 # Explicit bracket parser (strings and comments already removed).
 stack=[];pairs={')':'(',']':'[','}':'{'}
 for c in stripped:
  if c in '([{':stack.append(c)
  elif c in pairs:assert stack and stack.pop()==pairs[c],(p,c)
 assert not stack,p
 ids=re.findall(r'\$this->(?:add_control|start_controls_section|start_controls_tabs|start_controls_tab)\(\s*\'([^\']+)\'\s*,',s)
 assert len(ids)==len(set(ids)),(p,'duplicate literal control IDs')
 results.append(str(p.relative_to(root)))
js=(root/'assets/js/lumi-slider.js').read_text();assert not re.search(r'\bjQuery\b|\$\(|\bswiper\b|\bslick\b|\bowl\b',js,re.I)
css=(root/'assets/css/lumi-slider.css').read_text();assert '!important' not in css
for block in css.split('}'):
 if '{' in block:
  selector=block.rsplit('{',1)[0]
  if not selector.strip().startswith(('@','from','to')):
   # Keyframe and media nested blocks are handled by their scoped inner selector.
   assert '.lumi-' in selector or selector.strip() in ('from','to'),selector
report={'php_files_lexically_checked':results,'no_php8_only_features_detected':True,'duplicate_literal_ids':False,'js_library_references':False,'css_important':False,'limitation':'This report is lexical checking only. Actual PHP lint and WordPress integration results are documented separately in VALIDATION.md.'}
(root/'tests/static-check.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
