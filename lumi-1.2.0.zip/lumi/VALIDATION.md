# Lumi 1.2.0 — validation

Version number 1.2.0 has no RC suffix, as requested. This number is not a claim that
unexecuted browser/theme tests have passed.

## Executed on this build

| Environment | Assertions passed |
| --- | ---: |
| WordPress 7.1.3 / Elementor 3.5.0 / WooCommerce 11.2.1 / PHP 8.3.6 / SQLite | 71 |
| WordPress 7.1.3 / Elementor 4.3.4 / WooCommerce 11.2.1 / PHP 8.3.6 / SQLite | 71 |
| Readable and minified engine, Node VM simulated DOM/layout | 142 |
| WordPress Backbone models and native-compatible title template, Node VM | 22 |

- PHP lint passed for all six executable plugin PHP files and the PHP integration test.
- JavaScript syntax and static structure checks passed.
- Actual WordPress tests cover registration, inherited controls, conditional UI definitions,
  disabled markup, banner escaping, native URL/icon output, legacy data, empty content,
  deleted categories, placeholder dimensions and Elementor-generated CSS.
- Added custom rows with no category and hash links, no invented counts, image-only rows,
  empty-row skipping, allowed title/subtitle HTML and rejection of scripts/event attributes.
- Added CSS checks for the moved alignment control, hover duration and all four pagination
  presets with start/end alignment. Tests use admin bootstrap for full control metadata;
  Elementor 4 optimizes away editor tab metadata in frontend-only contexts.
- Backbone checks cover row numbering on sort/add/remove/duplicate, stable IDs, teardown
  and idempotence. Title-template checks use Elementor's Mustache-style Underscore rules,
  including safe escaping of ampersands and stripping title HTML in panel labels.
- The banner widget PHP file is byte-identical to 1.1.0-rc.1. Its controls were not redesigned.
  Shared assets contain category-scoped additions; existing banner regression tests pass.

## Actual frontend asset sizes

| File | Minified bytes | Gzip level 9 bytes |
| --- | ---: | ---: |
| assets/js/lumi-slider.min.js | 11531 | 3812 |
| assets/css/lumi-slider.min.css | 7762 | 1987 |

Limits remain <= 4,000 JS and <= 2,000 CSS gzip bytes. Preset/selected styles are generated
by Elementor. Limits exclude that generated CSS, native icon assets and editor-only assets.
Actual compressed HTTP delivery depends on the web server/CDN.

## Not verified

- No interactive browser/editor, real Woodmart, theme PJAX, screen reader or Lighthouse test.
- Roundness, animation smoothness, actual pointer/snap behavior, per-device computed layout
  and visible panel row alignment still require browser tests.
- PHP 7.4, WordPress 6.0, WooCommerce 6.0 and MySQL/MariaDB were not executed.
- Elementor 3.5 emits upstream PHP 8.3 deprecation notices; passing plugin assertions does
  not mean that old Elementor is warning-free on PHP 8.3.
- An initial latest-version fixture upgrade hit an upstream Elementor background-task error
  when its loopback request failed. A clean isolated latest-version database was used for
  the passing run; this is not a test of production Elementor upgrades.
- Do not reuse old version test counts as evidence for later code changes.

## Repeating tests

Use an isolated development WordPress copy with Lumi, Elementor and WooCommerce active.
The PHP test creates/deletes draft/category fixtures and exports a title-template JSON fixture.

    python3 lumi/tools/build.py
    python3 lumi/tests/static-check.py
    node lumi/tests/engine-test.cjs
    find lumi -name '*.php' -exec php -l {} \;
    wp --exec='if(!defined("WP_ADMIN"))define("WP_ADMIN",true);' eval-file /path/to/lumi/tests/wp-integration.php
    node lumi/tests/editor-test.cjs /path/to/wordpress/wp-includes/js /path/to/wordpress/lumi-title-template.json

Delete the title-template fixture afterward. Never run fixture tests on a live site.
Complete the manual checklist in readme.txt and the six category-specific checks before
using the update in production.
