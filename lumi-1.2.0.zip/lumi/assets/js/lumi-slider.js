/* Lumi Slider: native scroll-snap enhanced without any carousel library.
 * Modern browsers: AbortController, Pointer Events; observers are optional.
 * Unsupported engines retain native scrolling and hide enhanced controls.
 * Theme integrations can dispatch new CustomEvent('lumi:refresh') after PJAX.
 * Woodmart's PJAX completion bridge should dispatch that event; the child-list
 * observer also detects replaced widgets without depending on theme scripts.
 */
(function () {
  'use strict';
  const instances = new WeakMap(), roots = new Set();
  let rtlMode, pending = 0, hooked;

  // Normalize the three historical RTL scrollLeft models once per document.
  function rtlType() {
    if (rtlMode) return rtlMode;
    const outer = document.createElement('div'), inner = document.createElement('div');
    outer.dir = 'rtl';
    outer.style.cssText = 'position:absolute;top:-9999px;width:4px;height:1px;overflow:scroll';
    inner.style.width = '8px'; outer.append(inner); document.body.append(outer);
    if (outer.scrollLeft > 0) rtlMode = 'default';
    else { outer.scrollLeft = 1; rtlMode = outer.scrollLeft ? 'reverse' : 'negative'; }
    outer.remove(); return rtlMode;
  }

  class ECCSlider {
    constructor(root) {
      this.root = root; this.v = root.querySelector('.lumi-viewport');
      this.slides = Array.from(root.querySelector('.lumi-track').children);
      this.s = JSON.parse(root.dataset.settings || '{}');
      this.rtl = getComputedStyle(this.v).direction === 'rtl';
      this.mode = this.rtl ? rtlType() : '';
      this.abort = new AbortController(); this.pauses = new Set();
      this.media = matchMedia('(prefers-reduced-motion: reduce)');
      this.dots = root.querySelector('.lumi-dots') || document.createElement('div'); this.nav = root.querySelector('.lumi-navigation'); this.bar = root.querySelector('.lumi-progress > span');
      this.active = -1; this.frame = 0; this.anim = 0; this.timer = 0; this.dotButtons = [];
      if (!this.slides.length) return;
      root.dataset.lumiInit = '1';
      this.on(this.v, 'scroll', () => {
        if (!this.frame) this.frame = requestAnimationFrame(() => { this.frame = 0; this.sync(); });
      }, {passive: true});
      this.on(root, 'click', e => this.click(e));
      this.on(this.v, 'keydown', e => this.key(e));
      this.on(root, 'focusin', () => this.pause('focus', true));
      this.on(root, 'focusout', e => { if (!root.contains(e.relatedTarget)) this.pause('focus', false); });
      if (this.s.hover) {
        this.on(root, 'mouseenter', () => this.pause('hover', true), {passive: true});
        this.on(root, 'mouseleave', () => this.pause('hover', false), {passive: true});
      }
      this.on(document, 'visibilitychange', () => this.pause('hidden', document.hidden));
      this.on(this.v, 'pointerdown', e => this.down(e), {passive: true});
      this.on(this.v, 'pointermove', e => this.move(e));
      this.on(this.v, 'pointerup', () => this.up(), {passive: true});
      this.on(this.v, 'pointercancel', () => this.up(), {passive: true});
      this.on(this.v, 'lostpointercapture', () => this.up(), {passive: true});
      this.on(window, 'pointerup', () => this.up(), {passive: true});
      this.on(this.v, 'dragstart', e => { if (this.s.drag) e.preventDefault(); });
      this.on(root, 'click', e => { if (this.suppress) { this.suppress = false; if (e.target.closest('a')) { e.preventDefault(); e.stopImmediatePropagation(); } } }, {capture: true});
      const reduced = () => {
        if (this.media.matches && this.anim) { cancelAnimationFrame(this.anim); this.anim = 0; this.v.style.scrollSnapType = ''; }
        this.pause('motion', this.media.matches);
      };
      if (this.media.addEventListener) this.on(this.media, 'change', reduced);
      else { this.media.addListener(reduced); this.abort.signal.addEventListener('abort', () => this.media.removeListener(reduced), {once: true}); }
      if (window.ResizeObserver) {
        this.resize = new ResizeObserver(() => { this.measure(); this.sync(); this.schedule(); }); this.resize.observe(this.v);
      }
      if (window.IntersectionObserver) {
        this.pauses.add('view');
        this.intersection = new IntersectionObserver(e => this.pause('view', !e[0].isIntersecting), {threshold: 0.05});
        this.intersection.observe(root);
      }
      if (document.hidden) this.pauses.add('hidden');
      if (this.media.matches) this.pauses.add('motion');
      if (this.s.editor || (window.elementorFrontend && elementorFrontend.isEditMode && elementorFrontend.isEditMode())) this.pauses.add('editor');
      this.measure(); this.sync(); this.schedule();
    }

    // One controller removes every listener, including older browsers without
    // EventTarget's signal option. Only cancellable interactions are nonpassive.
    on(target, event, fn, options) {
      target.addEventListener(event, fn, options);
      this.abort.signal.addEventListener('abort', () => target.removeEventListener(event, fn, options), {once: true});
    }

    position(value) {
      const convert = x => !this.rtl || this.mode === 'reverse' ? x : this.mode === 'negative' ? -x : this.max - x;
      if (value !== undefined) this.v.scrollLeft = convert(value);
      return Math.max(0, Math.min(this.max, convert(this.v.scrollLeft)));
    }

    measure() {
      const gap = parseFloat(getComputedStyle(this.root.querySelector('.lumi-track')).columnGap) || 0;
      this.step = this.slides[0].getBoundingClientRect().width + gap;
      this.max = Math.max(0, this.v.scrollWidth - this.v.clientWidth);
      const pages = this.step && this.v.clientWidth ? Math.ceil(this.max / this.step - 0.001) + 1 : 1;
      if (pages !== this.pages) {
        this.pages = pages; this.active = -1; this.dots.textContent = ''; this.dotButtons = [];
        if (this.s.dots) for (let n = 0; n < pages; n++) {
          const b = document.createElement('button'); b.type = 'button'; b.className = 'lumi-dot'; b.dataset.page = n;
          b.setAttribute('aria-label', (this.s.dotLabel || '%s').replace('%s', this.number(n + 1)));
          if ((this.s.banner && this.s.nav !== 'dots') || (!this.s.banner && this.s.nav === 'numbers')) {
            if (this.s.banner) b.classList.add('lumi-number');
            b.textContent = this.number(n + 1);
            if (this.s.banner && this.s.nav === 'numbers_titles' && this.s.labels[n]) {
              const label = document.createElement('span'); label.textContent = this.s.labels[n]; b.append(label);
            }
          }
          this.dots.append(b); this.dotButtons.push(b);
        }
      }
      this.dots.hidden = !this.s.dots || pages <= 1;
      if (this.nav) this.nav.hidden = pages <= 1 || (!this.s.dots && !this.nav.querySelector('.lumi-pause')); 
      this.root.classList.toggle('lumi-static', this.max < 1);
    }

    number(n) { try { return n.toLocaleString((document.documentElement.lang || 'en').replace('_', '-')); } catch (error) { return String(n); } }

    sync() {
      const pos = this.position();
      const current = this.max - pos < 1 ? this.pages - 1 : Math.min(this.pages - 1, Math.round(pos / (this.step || 1)));
      ['prev', 'next'].forEach((name, i) => {
        const button = this.root.querySelector('[data-action="' + name + '"]');
        if (!button) return;
        const disabled = this.max < 1 || (!this.s.loop && (i ? pos >= this.max - 1 : pos < 1));
        button.setAttribute('aria-disabled', disabled); button.classList.toggle('lumi-disabled', disabled);
      });
      if (current === this.active) return;
      this.active = current;
      this.dotButtons.forEach((b, i) => { b.setAttribute('aria-current', i === current ? 'true' : 'false'); });
      this.slides.forEach((slide, i) => {
        slide.classList.toggle('lumi-active', i === current);
        if (this.s.banner) { slide.inert = i !== current; slide.setAttribute('aria-hidden', i !== current); }
      });
      const live = this.root.querySelector('.lumi-live');
      if (live) live.textContent = (this.s.slideLabel || '%1$s / %2$s').replace('%1$s', this.number(current + 1)).replace('%2$s', this.number(this.pages));
    }

    go(page) {
      cancelAnimationFrame(this.anim); this.stop();
      const from = this.position(), to = Math.min(this.max, Math.max(0, page) * this.step);
      const duration = this.media.matches ? 0 : this.s.speed;
      this.v.style.scrollSnapType = 'none';
      const done = () => { this.anim = 0; this.v.style.scrollSnapType = ''; this.sync(); this.schedule(); };
      if (!duration || Math.abs(to - from) < 0.5) { this.position(to); done(); return; }
      const start = performance.now();
      const frame = time => {
        const t = Math.min(1, (time - start) / duration), ease = 1 - Math.pow(1 - t, 3);
        this.position(from + (to - from) * ease);
        if (t < 1) this.anim = requestAnimationFrame(frame); else done();
      };
      this.anim = requestAnimationFrame(frame);
    }

    advance(direction) {
      let next = this.active + direction;
      // Rewind, not clones: stable DOM, fractional columns and focus order.
      if (this.s.loop) { if (next >= this.pages) next = 0; if (next < 0) next = this.pages - 1; }
      this.go(Math.max(0, Math.min(this.pages - 1, next)));
    }

    click(e) {
      const b = e.target.closest('button'); if (!b || !this.root.contains(b)) return;
      if (b.dataset.page !== undefined) { this.go(Number(b.dataset.page)); return; }
      if (b.getAttribute('aria-disabled') === 'true') return;
      if (b.dataset.action === 'pause') {
        const paused = !this.pauses.has('manual'); this.pause('manual', paused);
        b.setAttribute('aria-pressed', paused); b.setAttribute('aria-label', paused ? this.s.playLabel : this.s.pauseLabel);
        b.firstElementChild.textContent = paused ? '▶' : 'Ⅱ';
      } else if (b.dataset.action) this.advance(b.dataset.action === 'next' ? 1 : -1);
    }

    key(e) {
      if (e.target !== this.v) return;
      const actions = {ArrowLeft: this.rtl ? 1 : -1, ArrowRight: this.rtl ? -1 : 1};
      if (e.key in actions) { e.preventDefault(); this.advance(actions[e.key]); }
      else if (e.key === 'Home' || e.key === 'End') { e.preventDefault(); this.go(e.key === 'Home' ? 0 : this.pages - 1); }
    }

    down(e) {
      this.suppress = false;
      if (e.pointerType !== 'mouse') { this.pause('touch', true); return; }
      if (!this.s.drag || e.button !== 0 || e.target.closest('button')) return;
      cancelAnimationFrame(this.anim); this.anim = 0; this.v.style.scrollSnapType = '';
      this.drag = {x: e.clientX, pos: this.position(), id: e.pointerId, moving: false}; this.pause('drag', true);
    }

    move(e) {
      if (!this.drag) return;
      const delta = e.clientX - this.drag.x;
      if (Math.abs(delta) > 6 && !this.drag.moving) {
        this.drag.moving = true; this.v.setPointerCapture(this.drag.id);
        this.v.style.scrollSnapType = 'none'; this.root.classList.add('lumi-dragging');
      }
      if (this.drag.moving) { e.preventDefault(); this.position(this.drag.pos + (this.rtl ? delta : -delta)); }
    }

    up() {
      if (!this.drag && !this.pauses.has('touch')) return;
      this.pause('touch', false);
      if (!this.drag) return;
      const drag = this.drag; this.drag = null; this.suppress = drag.moving;
      if (this.v.hasPointerCapture(drag.id)) this.v.releasePointerCapture(drag.id);
      this.v.style.scrollSnapType = ''; this.root.classList.remove('lumi-dragging');
      this.sync(); this.pause('drag', false);
    }

    pause(reason, paused) {
      paused ? this.pauses.add(reason) : this.pauses.delete(reason); this.schedule();
    }

    stop() {
      clearTimeout(this.timer); this.timer = 0;
      if (this.progress) this.progress.cancel();
    }

    schedule() {
      this.stop();
      if (!this.s.autoplay || this.pauses.size || this.pages <= 1 || this.anim || (!this.s.loop && this.active >= this.pages - 1)) return;
      if (this.bar && this.bar.animate) this.progress = this.bar.animate([{transform: 'scaleX(0)'}, {transform: 'scaleX(1)'}], {duration: this.s.delay, fill: 'forwards'});
      this.timer = setTimeout(() => this.advance(1), this.s.delay);
    }

    destroy() {
      this.stop(); cancelAnimationFrame(this.frame); cancelAnimationFrame(this.anim); this.abort.abort();
      if (this.resize) this.resize.disconnect(); if (this.intersection) this.intersection.disconnect();
      this.v.style.scrollSnapType = ''; this.root.classList.remove('lumi-dragging'); delete this.root.dataset.lumiInit;
      this.slides.forEach(slide => { slide.inert = false; slide.classList.remove('lumi-active'); slide.removeAttribute('aria-hidden'); });
      this.dots.textContent = ''; if (this.nav) this.nav.hidden = true; roots.delete(this.root); instances.delete(this.root);
    }
  }

  function list(root) {
    const nodes = Array.from((root || document).querySelectorAll('.lumi-slider'));
    if (root && root.matches && root.matches('.lumi-slider')) nodes.unshift(root);
    return nodes;
  }
  function initAll(root) {
    if (!window.AbortController) return;
    list(root).forEach(el => {
      if (instances.has(el)) return;
      try { const instance = new ECCSlider(el); if (el.dataset.lumiInit) { instances.set(el, instance); roots.add(el); } }
      catch (error) { delete el.dataset.lumiInit; }
    });
  }
  function destroyAll(root) { list(root).forEach(el => { const instance = instances.get(el); if (instance) instance.destroy(); }); }
  window.ECC = {initAll: initAll, destroyAll: destroyAll}; window.Lumi = window.ECC;
  function hooks() {
    const frontend = window.elementorFrontend;
    if (!frontend || !frontend.hooks || hooked === frontend.hooks) return;
    hooked = frontend.hooks;
    ['lumi_category_carousel', 'lumi_slider'].forEach(name => {
      hooked.addAction('frontend/element_ready/' + name + '.default', scope => {
        const root = scope.nodeType ? scope : scope[0]; destroyAll(root); initAll(root);
      });
    });
  }
  function refresh() {
    if (pending) return;
    pending = requestAnimationFrame(() => {
      pending = 0; roots.forEach(root => { if (!root.isConnected) instances.get(root).destroy(); }); hooks(); initAll();
    });
  }
  function boot() {
    hooks(); initAll();
    if (window.MutationObserver) new MutationObserver(records => {
      const relevant = records.some(record => Array.from(record.addedNodes).concat(Array.from(record.removedNodes)).some(node => node.nodeType === 1 && (node.matches('.lumi-slider') || node.querySelector('.lumi-slider'))));
      if (relevant) refresh();
    }).observe(document.body, {childList: true, subtree: true});
  }
  window.addEventListener('elementor/frontend/init', refresh);
  window.addEventListener('load', refresh, {once: true});
  document.addEventListener('lumi:refresh', () => { destroyAll(document); refresh(); });
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot, {once: true}); else boot();
})();
