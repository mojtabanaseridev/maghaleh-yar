<?php
/**
 * Plugin Name: لومی | Lumi
 * Description: دو ویجت سبک المنتور: کروسل دسته بندی لومی و اسلایدر لومی.
 * Version: 1.2.0
 * Author: Mojtaba Naseri
 * Author URI: https://t.me/Mojtaba_nsr44
 * Text Domain: lumi
 * Domain Path: /languages
 * Requires at least: 6.0
 * Requires PHP: 7.4
 * WC requires at least: 6.0
 * License: GPL-2.0-or-later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 *
 * Author contact: 09367800550 | mojtabanaseri157@gmail.com
 * @package Lumi
 */
defined( 'ABSPATH' ) || exit;
define( 'LUMI_VERSION', '1.2.0' );
define( 'LUMI_FILE', __FILE__ );
define( 'LUMI_PATH', plugin_dir_path( __FILE__ ) );
define( 'LUMI_URL', plugin_dir_url( __FILE__ ) );
require_once LUMI_PATH . 'includes/class-lumi-plugin.php';
LUMI_Plugin::instance();
