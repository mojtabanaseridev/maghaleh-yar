<?php
namespace Mojtabanaseri\ArticleProducts;
if ( ! defined('ABSPATH') ) {
    exit;
}
/** Indexed aliases and usage. All writes happen in the admin or content save hooks. */
final class Store {
    const HIDDEN = '_mnps_hidden_boxes';
    private static $aliases=array();
    private static $resolved=array();
    public static function install() {
        global $wpdb;
        if ( get_option('mnps_schema') === '3' ) {
            return;
        }
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        $charset = $wpdb->get_charset_collate();
        dbDelta("CREATE TABLE {$wpdb->prefix}mnps_boxes (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            source_post bigint(20) unsigned NOT NULL,
            group_key varchar(64) NOT NULL,
            active tinyint(1) NOT NULL DEFAULT 1,
            display_enabled tinyint(1) NOT NULL DEFAULT 1,
            display_until bigint(20) unsigned NOT NULL DEFAULT 0,
            title varchar(255) NOT NULL DEFAULT '',
            box_type varchar(12) NOT NULL DEFAULT 'products',
            tags varchar(2048) NOT NULL DEFAULT '',
            issues smallint unsigned NOT NULL DEFAULT 0,
            ready tinyint(1) NOT NULL DEFAULT 0,
            PRIMARY KEY  (id),
            UNIQUE KEY source_group (source_post,group_key),
            KEY archive_state (active,ready,box_type)
        ) $charset;");
        dbDelta("CREATE TABLE {$wpdb->prefix}mnps_usage (
            box_id bigint(20) unsigned NOT NULL,
            post_id bigint(20) unsigned NOT NULL,
            enabled tinyint(1) NOT NULL DEFAULT 1,
            PRIMARY KEY  (box_id,post_id),
            KEY destination (post_id),
            KEY box_enabled (box_id,enabled)
        ) $charset;");
        update_option('mnps_schema','3',false);
        update_option('mnps_archive_ready',false,false);
        update_option('mnps_scan',array('phase'=>'boxes','cursor'=>0),false);
    }
    public static function sync($source, $groups) {
        global $wpdb;
        if ( get_option('mnps_schema') !== '3' ) {
            return;
        }
        $table = $wpdb->prefix.'mnps_boxes';
        self::$aliases=array();
        self::$resolved=array();
        $wpdb->update($table,array('active'=>0),array('source_post'=>absint($source)));
        foreach ($groups as $g) {
            $key = $g['key'];
            $wpdb->query($wpdb->prepare("INSERT INTO $table (source_post,group_key,active,display_enabled,display_until,title,box_type,tags,issues,ready) VALUES (%d,%s,1,%d,%d,%s,%s,%s,%d,1) ON DUPLICATE KEY UPDATE active=1,display_enabled=VALUES(display_enabled),display_until=VALUES(display_until),title=VALUES(title),box_type=VALUES(box_type),tags=VALUES(tags),issues=VALUES(issues),ready=1",$source,$key,isset($g['display_enabled'])?(int)$g['display_enabled']:1,!empty($g['schedule']['enabled'])?absint($g['schedule']['end']):0,wp_html_excerpt($g['title']?:get_the_title($source),200,''),$g['type']??'products',wp_json_encode($g['tags']??array(),JSON_UNESCAPED_UNICODE),count(Features::health($g))));
        }
        self::invalidate();
    }
    public static function id($source,$key) {
        global $wpdb;
        if (!in_array(get_option('mnps_schema'),array('1','2','3'),true)) {
            return 0;
        }
        $cache=absint($source).':'.$key;
        if(array_key_exists($cache,self::$aliases)){
            return self::$aliases[$cache];
        }
        self::$aliases[$cache]=(int)$wpdb->get_var($wpdb->prepare("SELECT id FROM {$wpdb->prefix}mnps_boxes WHERE source_post=%d AND group_key=%s AND active=1",$source,$key));
        return self::$aliases[$cache];
    }
    public static function resolve($id) {
        global $wpdb;
        if (!in_array(get_option('mnps_schema'),array('1','2','3'),true)) {
            return null;
        }
        $id=absint($id);
        if(array_key_exists($id,self::$resolved)){
            return self::$resolved[$id];
        }
        $row=$wpdb->get_row($wpdb->prepare("SELECT source_post,group_key FROM {$wpdb->prefix}mnps_boxes WHERE id=%d AND active=1",$id));
        self::$resolved[$id]=$row;
        if($row){
            self::$aliases[$row->source_post.':'.$row->group_key]=$id;
        }
        return $row;
    }
    public static function code($source,$key) {
        $id=self::id($source,$key);
        return $id ? '[my_box id="'.$id.'"]' : '[maghaleh_yar id="'.absint($source).'" group="'.$key.'"]';
    }
    public static function hidden($source,$key) {
        $destination = is_singular() ? get_queried_object_id() : get_the_ID();
        $hidden=get_post_meta($destination,self::HIDDEN,true);
        if (!is_array($hidden) || !$hidden) {
            return false;
        }
        return in_array(self::id($source,$key),array_map('absint',$hidden),true);
    }
    public static function usage($box,$page=1) {
        global $wpdb;
        $rows=$wpdb->get_results($wpdb->prepare("SELECT u.post_id,p.post_title FROM {$wpdb->prefix}mnps_usage u INNER JOIN {$wpdb->posts} p ON p.ID=u.post_id WHERE u.box_id=%d AND p.post_status='publish' ORDER BY p.post_title,p.ID LIMIT 100 OFFSET %d",$box,(max(1,absint($page))-1)*100));
        $out=array();
        foreach($rows as $r) {
            if(!current_user_can('edit_post',$r->post_id)){
                continue;
            }
            $hidden=get_post_meta($r->post_id,self::HIDDEN,true);
            $out[]=array('id'=>(int)$r->post_id,'title'=>$r->post_title ?: __('بدون عنوان', 'mojtabanaseri-article-products'),'url'=>get_permalink($r->post_id),'enabled'=>!is_array($hidden)||!in_array((int)$box,array_map('absint',$hidden),true));
        }
        return $out;
    }
    public static function count($box) {
        global $wpdb;
        return (int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$wpdb->prefix}mnps_usage u INNER JOIN {$wpdb->posts} p ON p.ID=u.post_id WHERE u.box_id=%d AND p.post_status='publish'",$box));
    }
    public static function visibility_summary($box) {
        global $wpdb;
        $rows=$wpdb->get_results($wpdb->prepare("SELECT u.post_id,m.meta_value FROM {$wpdb->prefix}mnps_usage u INNER JOIN {$wpdb->posts} p ON p.ID=u.post_id LEFT JOIN {$wpdb->postmeta} m ON m.post_id=u.post_id AND m.meta_key=%s WHERE u.box_id=%d AND p.post_status='publish'",self::HIDDEN,$box));
        $seen=array();
        $now=time();
        $enabled=0;
        foreach($rows as$row){
            if(isset($seen[$row->post_id])){
                continue;
            }
            $seen[$row->post_id]=true;
            $hidden=maybe_unserialize($row->meta_value);
            if(!is_array($hidden)||!in_array((int)$box,array_map('absint',$hidden),true)){
                $enabled++;
            }
        }
        return array('total'=>count($seen),'enabled'=>$enabled);
    }
    /** Read aliases and usage together; avoids a query for every card. */
    public static function archive_index($ids=null){
        global $wpdb;
        $out=array();
        if(!in_array(get_option('mnps_schema'),array('1','2','3'),true)){
            return $out;
        }
        $limit='';
        if(is_array($ids)){
            if(!$ids)return $out;
            $limit=' AND b.id IN ('.implode(',',array_map('absint',$ids)).')';
        }
        $rows=$wpdb->get_results($wpdb->prepare("SELECT b.id,b.source_post,b.group_key,u.post_id,m.meta_value FROM {$wpdb->prefix}mnps_boxes b LEFT JOIN {$wpdb->prefix}mnps_usage u ON u.box_id=b.id AND EXISTS (SELECT 1 FROM {$wpdb->posts} p WHERE p.ID=u.post_id AND p.post_status='publish') LEFT JOIN {$wpdb->postmeta} m ON m.post_id=u.post_id AND m.meta_key=%s WHERE b.active=1 $limit",self::HIDDEN));
        $seen=array();
        foreach($rows as$r){
            $key=$r->source_post.':'.$r->group_key;
            if(!isset($out[$key])){
                $out[$key]=array('id'=>(int)$r->id,'total'=>0,'enabled'=>0);
                self::$aliases[$key]=(int)$r->id;
            }
            if(!$r->post_id||isset($seen[$key][$r->post_id])){
                continue;
            }
            $seen[$key][$r->post_id]=true;
            $out[$key]['total']++;
            $h=maybe_unserialize($r->meta_value);
            if(!is_array($h)||!in_array((int)$r->id,array_map('absint',$h),true)){
                $out[$key]['enabled']++;
            }
        }
        return $out;
    }
    /** One joined read for archive totals, independent of filters and pagination. */
    public static function invalidate(){
        update_option('mnps_archive_version',wp_generate_uuid4(),false);
    }
    public static function archive_query($search='',$tag='',$state='all',$type='all',$health=false,$page=1){
        global $wpdb;
        $where="b.active=1 AND b.ready=1 AND p.post_type IN ('post','mnps_group') AND p.post_status IN ('publish','draft','pending','private','future')";
        if(!current_user_can('edit_others_posts')){
            $where.=$wpdb->prepare(' AND p.post_author=%d',get_current_user_id());
        }
        if($search!==''){
            $like='%'.$wpdb->esc_like($search).'%';
            $where.=$wpdb->prepare(' AND (b.title LIKE %s OR p.post_title LIKE %s)',$like,$like);
        }
        if($tag!==''){
            $where.=$wpdb->prepare(' AND b.tags LIKE %s','%'.$wpdb->esc_like(wp_json_encode($tag,JSON_UNESCAPED_UNICODE)).'%');
        }
        if($type!=='all'){
            $where.=$wpdb->prepare(' AND b.box_type=%s',$type);
        }
        if($health){
            $where.=' AND b.issues>0';
        }
        $now=time();
        $enabled="(p.post_status='publish' AND b.display_enabled=1 AND (b.display_until=0 OR b.display_until>$now))";
        if($state==='active'){
            $where.=" AND $enabled";
        }
        elseif($state==='expired'){ $where.=$wpdb->prepare(' AND b.display_until>0 AND b.display_until<=%d',time()); }
        elseif($state==='inactive'){
            $where.=" AND NOT $enabled";
        }
        $join="FROM {$wpdb->prefix}mnps_boxes b INNER JOIN {$wpdb->posts} p ON p.ID=b.source_post";
        $total=(int)$wpdb->get_var("SELECT COUNT(*) $join WHERE $where");
        $per=Features::settings()['per_page'];
        $pages=max(1,(int)ceil($total/$per));
        $page=max(1,min($pages,absint($page)));
        $rows=$wpdb->get_results($wpdb->prepare("SELECT b.id,b.source_post,b.group_key,b.title,b.issues $join WHERE $where ORDER BY p.post_modified DESC,b.id DESC LIMIT %d OFFSET %d",$per,($page-1)*$per));
        $sources=array_values(array_unique(array_map(function($r){
            return (int)$r->source_post;
        }
        ,$rows)));
        if($sources){
            _prime_post_caches($sources,false,true);
        }
        return array('rows'=>$rows,'total'=>$total,'pages'=>$pages,'page'=>$page);
    }
    public static function archive_stats(){
        global $wpdb;
        $key='mnps_stats_'.md5(get_current_user_id().':'.wp_json_encode(wp_get_current_user()->allcaps).':'.get_option('mnps_archive_version','0'));
        $cache=get_transient($key);
        if(false!==$cache)return $cache;
        $where="b.active=1 AND b.ready=1 AND p.post_type IN ('post','mnps_group') AND p.post_status IN ('publish','draft','pending','private','future')";
        if(!current_user_can('edit_others_posts')){
            $where.=$wpdb->prepare(' AND p.post_author=%d',get_current_user_id());
        }
        $now=time();
        $enabled="p.post_status='publish' AND b.display_enabled=1 AND (b.display_until=0 OR b.display_until>$now)";
        $r=$wpdb->get_row("SELECT COUNT(*) AS total,SUM(CASE WHEN $enabled THEN 1 ELSE 0 END) AS enabled FROM {$wpdb->prefix}mnps_boxes b INNER JOIN {$wpdb->posts} p ON p.ID=b.source_post WHERE $where");
        $out=array('active'=>(int)$r->enabled,'inactive'=>(int)$r->total-(int)$r->enabled);
        set_transient($key,$out,300);
        return $out;
    }
    public static function archive_tags(){
        global $wpdb;
        $where="b.active=1 AND b.ready=1 AND p.post_type IN ('post','mnps_group') AND p.post_status IN ('publish','draft','pending','private','future')";
        if(!current_user_can('edit_others_posts')){
            $where.=$wpdb->prepare(' AND p.post_author=%d',get_current_user_id());
        }
        $tags=array();
        foreach($wpdb->get_col("SELECT DISTINCT b.tags FROM {$wpdb->prefix}mnps_boxes b INNER JOIN {$wpdb->posts} p ON p.ID=b.source_post WHERE $where")as$json){
            foreach((array)json_decode($json,true)as$t){
                $tags[$t]=$t;
            }
        }
        return $tags;
    }
    public static function referenced($source,$key='') {
        $groups=Plugin::boot()->groups($source);
        foreach($groups as $g) {
            if(!$key || $g['key']===$key) {
                return self::id($source,$g['key']);
            }
        }
        return 0;
    }
    /** Follow supported reusable content with bounded recursion, never arbitrary PHP. */
    public static function detect($post_id,$seen=array()) {
        if(isset($seen[$post_id]) || count($seen)>8) {
            return array();
        }
        $post=get_post($post_id);
        if(!$post) {
            return array();
        }
        $seen[$post_id]=true;
        $found=array();
        $add=function($source,$key='')use(&$found){
            $id=self::referenced(absint($source),sanitize_key($key));
            if($id){
                $found[]=$id;
            }
        }
        ;
        $scan=function($text)use(&$found,$add,$post_id,$seen){
            $names=array('my_box','maghaleh_yar','mn_products','mn_cta','rg_related_products','elementor-template');
            if(!preg_match_all('/'.get_shortcode_regex($names).'/s',$text,$matches,PREG_SET_ORDER)){
                return;
            }
            foreach($matches as$m){
                if('['===$m[1] && ']'===$m[6]){
                    continue;
                }
                $a=shortcode_parse_atts($m[3]);
                if(!is_array($a)){
                    continue;
                }
                if('my_box'===$m[2]){
                    if(self::resolve(absint($a['id']??0))){
                        $found[]=absint($a['id']);
                    }
                }
                elseif('elementor-template'===$m[2]){
                    $found=array_merge($found,self::detect(absint($a['id']??0),$seen));
                }
                elseif(empty($a['ids'])){
                    $add(absint($a['id']??($a['post']??$post_id)) ?: $post_id,$a['group']??'');
                }
            }
        }
        ;
        $scan($post->post_content);
        $walk=function($blocks)use(&$walk,&$found,$add,$post_id,$seen){
            foreach($blocks as$b){
                $a=$b['attrs']??array();
                if('mojtabanaseri/article-products'===($b['blockName']??'')){
                    $add(absint($a['post']??0) ?: $post_id,$a['group']??'');
                }
                if('core/block'===($b['blockName']??'')&&!empty($a['ref'])){
                    $found=array_merge($found,self::detect(absint($a['ref']),$seen));
                }
                if(!empty($b['innerBlocks'])){
                    $walk($b['innerBlocks']);
                }
            }
        }
        ;
        $walk(parse_blocks($post->post_content));
        $raw=get_post_meta($post_id,'_elementor_data',true);
        $elements=is_string($raw)&&strlen($raw)<2000000?json_decode($raw,true):array();
        $nodes=0;
        $element=function($els,$depth=0)use(&$element,&$found,$add,$scan,$post_id,$seen,&$nodes){
            if($depth>20 || !is_array($els)){
                return;
            }
            foreach($els as$el){
                if(++$nodes>3000 || !is_array($el)){
                    break;
                }
                $s=$el['settings']??array();
                if(in_array($el['widgetType']??'',array('mnps-products','mnps-cta'),true)){
                    if(!empty($s['source'])&&is_string($s['source'])){
                        $p=explode(':',$s['source'],2);
                        $add($p[0],$p[1]??'');
                    }
                    elseif('mnps-products'===($el['widgetType']??'')){
                        $add($post_id);
                    }
                }
                if('shortcode'===($el['widgetType']??'')&&isset($s['shortcode'])&&is_string($s['shortcode'])){
                    $scan($s['shortcode']);
                }
                if(!empty($s['template_id'])){
                    $found=array_merge($found,self::detect(absint($s['template_id']),$seen));
                }
                if(!empty($el['elements'])){
                    $element($el['elements'],$depth+1);
                }
            }
        }
        ;
        $element($elements);
        return array_values(array_unique(array_filter(array_map('absint',$found))));
    }
    public static function index($post_id) {
        global $wpdb;
        if(get_option('mnps_schema')!=='3' || wp_is_post_revision($post_id) || wp_is_post_autosave($post_id)){
            return;
        }
        $wpdb->delete($wpdb->prefix.'mnps_usage',array('post_id'=>$post_id));
        self::invalidate();
        $p=get_post($post_id);
        if(!$p || 'publish'!==$p->post_status || !in_array($p->post_type,get_post_types(array('public'=>true)),true) || in_array($p->post_type,array('attachment','product','product_variation'),true)){
            return;
        }
        $hidden=get_post_meta($post_id,self::HIDDEN,true);
        $hidden=is_array($hidden)?array_map('absint',$hidden):array();
        foreach(self::detect($post_id) as$id){
            $wpdb->replace($wpdb->prefix.'mnps_usage',array('box_id'=>$id,'post_id'=>$post_id,'enabled'=>in_array($id,$hidden,true)?0:1),array('%d','%d','%d'));
        }
    }
    public static function on_save($id,$post) {
        if(wp_is_post_revision($id)||wp_is_post_autosave($id)){
            return;
        }
        if(in_array($post->post_type,array('post','mnps_group'),true)){
            self::sync($id,Plugin::boot()->groups($id));
        }
        self::index($id);
        if(in_array($post->post_type,array('wp_block','elementor_library'),true)){
            self::rescan();
        }
    }
    public static function elementor_saved($meta_id,$post_id,$key) {
        if($key===self::HIDDEN){
            self::index($post_id);
            return;
        }
        if('_elementor_data'!==$key){
            return;
        }
        self::index($post_id);
        if(in_array(get_post_type($post_id),array('wp_block','elementor_library'),true)){
            self::rescan();
        }
    }
    public static function rescan($boxes=false) {
        update_option('mnps_scan',array('phase'=>$boxes?'boxes':'content','cursor'=>0),false);
    }
    public static function batch() {
        global $wpdb;
        self::install();
        $state=get_option('mnps_scan',array('phase'=>'done','cursor'=>0));
        if('done'===$state['phase']){
            return $state;
        }
        $boxes='boxes'===$state['phase'];
        $cursor=absint($state['cursor']);
        $condition=$boxes ? "AND p.post_type IN ('post','mnps_group') AND EXISTS (SELECT 1 FROM {$wpdb->postmeta} m WHERE m.post_id=p.ID AND m.meta_key='_mnps_groups')" : "AND p.post_status='publish' AND p.post_type NOT IN ('attachment','product','product_variation','mnps_group','revision')";
        $ids=$wpdb->get_col($wpdb->prepare("SELECT p.ID FROM {$wpdb->posts} p WHERE p.ID>%d $condition ORDER BY p.ID LIMIT 30",$cursor));
        foreach($ids as$id){
            if($boxes){
                self::sync($id,Plugin::boot()->groups($id));
            }
            else{
                self::index($id);
            }
            $state['cursor']=(int)$id;
        }
        if(count($ids)<30){
            $state=array('phase'=>$boxes?'content':'done','cursor'=>0);
        }
        update_option('mnps_scan',$state,false);
        if($state['phase']==='done'){
            update_option('mnps_archive_ready',true,false);
            self::invalidate();
        }
        return $state;
    }
}
