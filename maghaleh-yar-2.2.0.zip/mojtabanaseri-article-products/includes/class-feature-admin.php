<?php
namespace Mojtabanaseri\ArticleProducts;
if (!defined('ABSPATH')) { exit; }
/** Lazy management operations; runtime rules remain in Features. */
final class FeatureAdmin extends Features {

    public static function product_rows($items){
        $out=array();
        foreach($items as$item){
            $p=function_exists('wc_get_product')?wc_get_product($item['id']):false;
            $out[]=array_merge($item,array('name'=>$p?$p->get_name():__('محصول حذف‌شده #', 'mojtabanaseri-article-products').absint($item['id']),'image'=>$p?wp_get_attachment_image_url($p->get_image_id(),'thumbnail')?:'':''));
        }
        return $out;
    }
    public static function snapshot($id,$groups,$current=null){
        $current=$current===null?Plugin::boot()->groups($id):$current;
        if(wp_json_encode($groups)===wp_json_encode($current)){
            return;
        }
        $previous=get_post_meta($id,self::PREVIOUS,true);
        $previous=is_array($previous)?$previous:array();
        $next=array();
        foreach($current as$g){
            $key=$g['key'];
            $new=null;
            foreach($groups as$n){
                if($n['key']===$key){
                    $new=$n;
                    break;
                }
            }
            if($new&&wp_json_encode($g)!==wp_json_encode($new)){
                $next[$key]=array('group'=>$g,'time'=>current_time('mysql'),'user'=>get_current_user_id());
            }
            elseif($new&&isset($previous[$key])){
                $next[$key]=$previous[$key];
            }
        }
        update_post_meta($id,self::PREVIOUS,wp_slash($next));
    }
    public static function write($id,$groups,$before){
        if(!update_post_meta($id,Plugin::META,wp_slash($groups),$before)&&wp_json_encode(get_post_meta($id,Plugin::META,true))!==wp_json_encode($groups)){
            wp_send_json_error(array('message'=>__('باکس هم‌زمان تغییر کرده؛ دوباره بررسی کنید.', 'mojtabanaseri-article-products')),409);
        }
        self::snapshot($id,$groups,is_array($before)?$before:array());
        Plugin::boot()->index($id,$groups);
        Store::index($id);
        Plugin::boot()->purge_all();
    }
    private static function auth($id=0){
        check_ajax_referer('mnps_admin','nonce');
        if(!current_user_can('edit_posts')||($id&&!current_user_can('edit_post',$id))){
            wp_send_json_error(array('message'=>__('اجازه انجام این تغییر را نداری.', 'mojtabanaseri-article-products')),403);
        }
    }
    private static function box($id){
        $r=Store::resolve(absint($id));
        if(!$r){
            wp_send_json_error(array('message'=>__('باکس پیدا نشد.', 'mojtabanaseri-article-products')),404);
        }
        self::auth($r->source_post);
        foreach(Plugin::boot()->groups($r->source_post)as$g){
            if($g['key']===$r->group_key){
                return array($r,$g);
            }
        }
        wp_send_json_error(array('message'=>__('باکس پیدا نشد.', 'mojtabanaseri-article-products')),404);
    }
    public static function health_api(){
        list($r,$g)=self::box($_POST['box']??0);
        wp_send_json_success(array('items'=>self::health($g),'edit'=>Admin::edit_url($r->source_post,$g['key'])));
    }
    public static function candidates_api(){
        self::auth();
        $boxes=array_slice(array_values(array_unique(array_filter(array_map('absint',explode(',',(string)($_POST['boxes']??'')))))),0,48);
        $items=array();
        foreach($boxes as$box){
            list($r,$g)=self::box($box);
            if(($g['type']??'products')==='cta'){
                continue;
            }
            $rows=($g['type']??'products')==='table'?array_map(function($r){return array('id'=>$r['product']);},$g['table']['rows']??array()):self::effective($g);
            if(($g['auto']['mode']??'manual')==='auto'){
                foreach($g['auto']['pinned']??array()as$id){
                    $rows[]=array('id'=>$id);
                }
            }
            foreach(self::product_rows($rows)as$item){
                $items[$item['id']]=$item;
            }
        }
        wp_send_json_success(array('items'=>array_values($items)));
    }
    public static function auto_api(){
        self::auth();
        $json=wp_unslash($_POST['group_data']??'');
        $raw=is_string($json)&&strlen($json)<=200000?json_decode($json,true):null;
        if(!is_array($raw)){
            wp_send_json_error(array('message'=>__('تنظیمات معتبر نیست.', 'mojtabanaseri-article-products')),400);
        }
        $g=Plugin::boot()->normalize(array($raw))[0];
        wp_send_json_success(array('items'=>self::product_rows(self::effective($g))));
    }
    public static function restore_api(){
        list($r,$g)=self::box($_POST['box']??0);
        $previous=get_post_meta($r->source_post,self::PREVIOUS,true);
        $old=is_array($previous)?($previous[$g['key']]??null):null;
        if(!$old){
            wp_send_json_error(array('message'=>__('ذخیره قبلی برای این باکس موجود نیست.', 'mojtabanaseri-article-products')),404);
        }
        $before=get_post_meta($r->source_post,Plugin::META,true);
        $hash=Admin::fingerprint($r->source_post);
        if(empty($_POST['commit'])){
            wp_send_json_success(array('title'=>$g['title']?:get_the_title($r->source_post),'time'=>$old['time'],'hash'=>$hash,'token'=>hash('sha256',wp_json_encode($old))));
        }
        if(!hash_equals($hash,(string)($_POST['hash']??''))||!hash_equals(hash('sha256',wp_json_encode($old)),(string)($_POST['token']??''))){
            wp_send_json_error(array('message'=>__('باکس تغییر کرده؛ دوباره بررسی کنید.', 'mojtabanaseri-article-products')),409);
        }
        $groups=Plugin::boot()->groups($r->source_post);
        foreach($groups as&$item){
            if($item['key']===$g['key']){
                $item=Plugin::boot()->normalize(Plugin::boot()->protect_code(array($old['group']),$r->source_post))[0];
            }
        }
        unset($item);
        self::write($r->source_post,$groups,$before);
        wp_send_json_success(array('restored'=>true));
    }
    public static function replace_api(){
        self::auth();
        $boxes=array_slice(array_values(array_unique(array_filter(array_map('absint',explode(',',(string)($_POST['boxes']??'')))))),0,48);
        $old=absint($_POST['old']??0);
        $new=absint($_POST['new']??0);
        if(!$boxes||!$old||!$new||$old===$new){
            wp_send_json_error(array('message'=>__('باکس‌ها و دو محصول متفاوت را انتخاب کنید.', 'mojtabanaseri-article-products')),400);
        }
        $p=function_exists('wc_get_product')?wc_get_product($new):false;
        if(!$p||$p->get_status()!=='publish'||!$p->is_visible()){
            wp_send_json_error(array('message'=>__('محصول جایگزین باید منتشرشده و قابل نمایش باشد.', 'mojtabanaseri-article-products')),400);
        }
        $sources=array();
        $affected=array();
        $destinations=array();
        foreach($boxes as$box){
            list($r,$g)=self::box($box);
            $source=(int)$r->source_post;
            if(!isset($sources[$source])){
                $sources[$source]=array('hash'=>Admin::fingerprint($source),'before'=>get_post_meta($source,Plugin::META,true),'groups'=>Plugin::boot()->groups($source));
            }
            foreach($sources[$source]['groups']as&$item){
                if($item['key']!==$g['key']||($item['type']??'products')==='cta'){
                    continue;
                }
                $auto=self::clean_auto($item['auto']??array());
                $changed=false;
                if(($item['type']??'products')==='table'){foreach($item['table']['rows']as&$row){if($row['product']===$old){$row['product']=$new;$changed=true;}}unset($row);}
                elseif($auto['mode']==='auto'){
                    if(in_array($old,$auto['pinned'],true)){
                        $auto['pinned']=array_values(array_unique(array_map(function($id)use($old,$new){
                            return $id===$old?$new:$id;
                        }
                        ,$auto['pinned'])));
                        $changed=true;
                    }
                    elseif(in_array($old,array_column(self::effective($item),'id'),true)){
                        $auto['excluded'][]=$old;
                        $auto['pinned'][]=$new;
                        $changed=true;
                    }
                    if($changed){
                        $auto['excluded']=array_values(array_diff($auto['excluded'],array($new)));
                        $item['auto']=self::clean_auto($auto);
                    }
                }
                else{
                    foreach($item['items']as&$product){
                        if($product['id']===$old){
                            $product['id']=$new;
                            $changed=true;
                        }
                    }
                    unset($product);
                    if($changed){
                        $seen=array();
                        $item['items']=array_values(array_filter($item['items'],function($x)use(&$seen){
                            if(isset($seen[$x['id']]))return false;$seen[$x['id']]=true;return true;
                        }
                        ));
                    }
                }
                if($changed){
                    $item=Plugin::boot()->normalize(array($item))[0];
                    $affected[]=array('id'=>$box,'title'=>$g['title']?:get_the_title($source));
                    global $wpdb;
                    $destinations=array_merge($destinations,$wpdb->get_col($wpdb->prepare("SELECT u.post_id FROM {$wpdb->prefix}mnps_usage u INNER JOIN {$wpdb->posts} p ON p.ID=u.post_id WHERE u.box_id=%d AND p.post_status='publish'",$box)));
                }
            }
            unset($item);
        }
        if(!$affected){
            wp_send_json_error(array('message'=>__('محصول قبلی در باکس‌های انتخاب‌شده پیدا نشد.', 'mojtabanaseri-article-products')),400);
        }
        $signature=hash('sha256',wp_json_encode(array($sources,$affected,$old,$new)));
        if(empty($_POST['commit'])){
            wp_send_json_success(array('items'=>$affected,'articles'=>count(array_unique($destinations)),'token'=>$signature,'new_name'=>$p->get_name()));
        }
        if(!hash_equals($signature,(string)($_POST['token']??''))){
            wp_send_json_error(array('message'=>__('اطلاعات تغییر کرده؛ جایگزینی را دوباره بررسی کنید.', 'mojtabanaseri-article-products')),409);
        }
        // Validate all sources before the first write, then use per-source compare-and-swap.
        $written=array();
        foreach($sources as$id=>$data){
            if(!hash_equals($data['hash'],Admin::fingerprint($id))){
                wp_send_json_error(array('message'=>__('باکس تغییر کرده؛ دوباره بررسی کنید.', 'mojtabanaseri-article-products')),409);
            }
        }
        foreach($sources as$id=>$data){
            $before=$data['before'];
            $groups=$data['groups'];
            if(!update_post_meta($id,Plugin::META,wp_slash($groups),$before)&&wp_json_encode(get_post_meta($id,Plugin::META,true))!==wp_json_encode($groups)){
                wp_send_json_error(array('message'=>__('ذخیره همه باکس‌ها کامل نشد. صفحه را تازه کنید و موارد باقی‌مانده را بررسی کنید.', 'mojtabanaseri-article-products'),'updated'=>$written),409);
            }
            self::snapshot($id,$groups,is_array($before)?$before:array());
            Plugin::boot()->index($id,$groups);
            Store::index($id);
            $written[]=$id;
        }
        Plugin::boot()->purge_all();
        wp_send_json_success(array('updated'=>$written));
    }
}
