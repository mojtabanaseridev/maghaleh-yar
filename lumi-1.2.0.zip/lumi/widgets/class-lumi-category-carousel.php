<?php
/** WooCommerce term carousel. @package Lumi */
defined( 'ABSPATH' ) || exit;

/** Displays manual categories or contextual child categories. */
final class LUMI_Category_Carousel extends LUMI_Widget {
	/** Widget identifier. */
	public function get_name() { return 'lumi_category_carousel'; }
	/** Panel title. */
	public function get_title() { return esc_html__( 'کروسل دسته بندی لومی', 'lumi' ); }
	/** Panel icon. */
	public function get_icon() { return 'eicon-carousel'; }

	/** Hierarchical labels with stable numeric term IDs. @return array */
	private function category_options() {
		$terms = get_terms( array( 'taxonomy' => 'product_cat', 'hide_empty' => false ) );
		if ( is_wp_error( $terms ) ) { return array(); }
		$parents = array();
		foreach ( $terms as $term ) { $parents[ (int) $term->parent ][] = $term; }
		$options = array();
		$walk = function ( $parent, $depth ) use ( &$walk, &$options, $parents ) {
			if ( empty( $parents[ $parent ] ) ) { return; }
			foreach ( $parents[ $parent ] as $term ) {
				$options[ $term->term_id ] = str_repeat( '— ', $depth ) . $term->name;
				$walk( (int) $term->term_id, $depth + 1 );
			}
		};
		$walk( 0, 0 );
		return $options;
	}

	/** Register all native Elementor controls. */
	protected function register_controls() {
		$this->start_controls_section( 'items', array( 'label' => esc_html__( 'دسته‌بندی‌ها', 'lumi' ) ) );
		$this->add_control( 'source', array( 'label' => esc_html__( 'منبع', 'lumi' ), 'type' => \Elementor\Controls_Manager::SELECT, 'default' => 'manual', 'options' => array( 'manual' => esc_html__( 'انتخاب دستی', 'lumi' ), 'auto' => esc_html__( 'خودکار بر اساس صفحه', 'lumi' ) ) ) );
		$rep = new \Elementor\Repeater();
		$options = $this->category_options();
		$rep->add_control( 'category', array( 'label' => esc_html__( 'دسته‌بندی', 'lumi' ), 'type' => \Elementor\Controls_Manager::SELECT2, 'placeholder' => esc_html__( 'اختیاری؛ دسته یا آیتم سفارشی', 'lumi' ), 'options' => $options, 'label_block' => true ) );
		$rep->add_control( 'image', array( 'label' => esc_html__( 'تصویر دلخواه', 'lumi' ), 'type' => \Elementor\Controls_Manager::MEDIA ) );
		foreach ( array( 'title' => esc_html__( 'عنوان دلخواه', 'lumi' ), 'subtitle' => esc_html__( 'زیرعنوان دلخواه', 'lumi' ) ) as $id => $label ) {
			$rep->add_control( $id, array( 'label' => $label, 'type' => \Elementor\Controls_Manager::TEXT, 'placeholder' => 'title' === $id ? esc_html__( 'خالی = نام دسته', 'lumi' ) : esc_html__( 'مثلاً Women’s Bags', 'lumi' ), 'label_block' => true ) );
		}
		$rep->add_control( '_lumi_order', array( 'type' => \Elementor\Controls_Manager::HIDDEN, 'default' => 1 ) );
		$rep->add_control( 'link', array( 'label' => esc_html__( 'لینک دلخواه', 'lumi' ), 'placeholder' => esc_html__( 'خالی = لینک دسته', 'lumi' ), 'type' => \Elementor\Controls_Manager::URL, 'options' => array( 'url', 'is_external', 'nofollow', 'custom_attributes' ) ) );
		$this->add_control( 'category_items', array( 'type' => \Elementor\Controls_Manager::REPEATER, 'fields' => $rep->get_controls(), 'title_field' => '<span class="lumi-row-heading"><span class="lumi-row-label">{{{ _.escape(String(title || (' . wp_json_encode( $options, JSON_FORCE_OBJECT ) . ')[category] || ' . wp_json_encode( __( 'آیتم سفارشی', 'lumi' ) ) . ' ).replace(/<[^>]*>/g, "")) }}}</span><span class="lumi-row-index">{{ _lumi_order }}</span></span>', 'condition' => array( 'source' => 'manual' ) ) );
		$this->add_control( 'auto_note', array( 'type' => \Elementor\Controls_Manager::RAW_HTML, 'raw' => esc_html__( 'در فروشگاه و صفحات عمومی: دسته‌های اصلی. در صفحه دسته‌بندی: زیردسته‌های همان دسته.', 'lumi' ), 'condition' => array( 'source' => 'auto' ) ) );
		$this->toggle( $this, 'hide_empty', esc_html__( 'مخفی‌کردن دسته‌های خالی', 'lumi' ), false, array( 'source' => 'auto' ) );
		$this->add_control( 'fallback', array( 'label' => esc_html__( 'اگر زیردسته وجود نداشت', 'lumi' ), 'type' => \Elementor\Controls_Manager::SELECT, 'default' => 'none', 'options' => array( 'none' => esc_html__( 'نمایش ندادن', 'lumi' ), 'siblings' => esc_html__( 'دسته‌های هم‌سطح', 'lumi' ), 'root' => esc_html__( 'دسته‌های اصلی', 'lumi' ) ), 'condition' => array( 'source' => 'auto' ) ) );
		$this->add_control( 'order_by', array( 'label' => esc_html__( 'مرتب‌سازی خودکار', 'lumi' ), 'type' => \Elementor\Controls_Manager::SELECT, 'default' => 'name', 'options' => array( 'name' => esc_html__( 'نام', 'lumi' ), 'count' => esc_html__( 'تعداد محصولات', 'lumi' ), 'id' => esc_html__( 'شناسه', 'lumi' ), 'menu_order' => esc_html__( 'ترتیب ووکامرس', 'lumi' ) ), 'condition' => array( 'source' => 'auto' ) ) );
		$this->add_control( 'limit', array( 'label' => esc_html__( 'تعداد کل (۰ = همه)', 'lumi' ), 'type' => \Elementor\Controls_Manager::NUMBER, 'default' => 0, 'min' => 0, 'condition' => array( 'source' => 'auto' ) ) );
		$this->end_controls_section();
		$this->start_controls_section( 'display', array( 'label' => esc_html__( 'نمایش و چیدمان', 'lumi' ) ) );
		$this->toggle( $this, 'show_title', esc_html__( 'عنوان اصلی', 'lumi' ) );
		$this->toggle( $this, 'show_subtitle', esc_html__( 'زیرعنوان', 'lumi' ) );
		$this->toggle( $this, 'show_count', esc_html__( 'تعداد محصولات', 'lumi' ), false );
		$this->add_control( 'count_format', array( 'label' => esc_html__( 'قالب تعداد', 'lumi' ), 'type' => \Elementor\Controls_Manager::TEXT, 'default' => __( '%s محصول', 'lumi' ), 'placeholder' => esc_html__( '%s محصول', 'lumi' ), 'condition' => array( 'show_count' => 'yes' ) ) );
		$this->add_control( 'title_tag', array( 'label' => esc_html__( 'تگ عنوان', 'lumi' ), 'type' => \Elementor\Controls_Manager::SELECT, 'default' => 'div', 'condition' => array( 'show_title' => 'yes' ), 'options' => array( 'h2' => 'H2', 'h3' => 'H3', 'h4' => 'H4', 'p' => 'P', 'div' => 'DIV', 'span' => 'SPAN' ) ) );
		$this->add_control( 'shape', array( 'label' => esc_html__( 'شکل تصویر', 'lumi' ), 'type' => \Elementor\Controls_Manager::SELECT, 'default' => 'circle', 'options' => array( 'circle' => esc_html__( 'دایره', 'lumi' ), 'square' => esc_html__( 'مربع', 'lumi' ), 'rounded' => esc_html__( 'گوشه‌گرد', 'lumi' ) ), 'prefix_class' => 'lumi-shape-' ) );
		$this->responsive( 'columns', array( 'label' => esc_html__( 'تعداد کارت قابل مشاهده', 'lumi' ), 'type' => \Elementor\Controls_Manager::NUMBER, 'min' => 1, 'max' => 20, 'step' => 0.1, 'default' => 7, 'tablet_default' => 4, 'mobile_default' => 2.3, 'selectors' => array( '{{WRAPPER}} .lumi-slider' => '--lumi-cols: {{VALUE}};' ) ) );
		$this->responsive( 'gap', array( 'label' => esc_html__( 'فاصله کارت‌ها', 'lumi' ), 'type' => \Elementor\Controls_Manager::SLIDER, 'size_units' => array( 'px' ), 'range' => array( 'px' => array( 'min' => 0, 'max' => 100 ) ), 'default' => array( 'size' => 16, 'unit' => 'px' ), 'mobile_default' => array( 'size' => 12, 'unit' => 'px' ), 'selectors' => array( '{{WRAPPER}} .lumi-slider' => '--lumi-gap: {{SIZE}}px;' ) ) );

		$this->toggle( $this, 'above_fold', esc_html__( 'این کروسل بالای صفحه است', 'lumi' ), false );
		$this->end_controls_section();
		$this->motion_controls();
		$this->start_controls_section( 'content_style', array( 'label' => esc_html__( 'محتوا', 'lumi' ), 'tab' => \Elementor\Controls_Manager::TAB_STYLE ) );
		$this->responsive( 'align', array( 'label' => esc_html__( 'تراز محتوا', 'lumi' ), 'type' => \Elementor\Controls_Manager::SELECT, 'default' => 'center', 'options' => array( 'start' => esc_html__( 'ابتدا', 'lumi' ), 'center' => esc_html__( 'وسط', 'lumi' ), 'end' => esc_html__( 'انتها', 'lumi' ) ), 'selectors' => array( '{{WRAPPER}} .lumi-category-card, {{WRAPPER}} .lumi-primary, {{WRAPPER}} .lumi-secondary, {{WRAPPER}} .lumi-count' => 'text-align: {{VALUE}};' ) ) );
		$this->add_control( 'hover_duration', array( 'label' => esc_html__( 'مدت تغییر هاور (میلی‌ثانیه)', 'lumi' ), 'type' => \Elementor\Controls_Manager::NUMBER, 'default' => 280, 'min' => 0, 'max' => 3000, 'step' => 50, 'placeholder' => '280', 'selectors' => array( '{{WRAPPER}} .lumi-categories' => '--lumi-hover: {{VALUE}}ms;' ) ) );
		$this->end_controls_section();
		$this->image_styles( 'category_image', '.lumi-category-media' );
		$this->text_styles( 'primary', esc_html__( 'عنوان اصلی', 'lumi' ), '.lumi-primary', array( 'show_title' => 'yes' ) );
		$this->text_styles( 'secondary', esc_html__( 'زیرعنوان', 'lumi' ), '.lumi-secondary', array( 'show_subtitle' => 'yes' ) );
		$this->text_styles( 'count', esc_html__( 'تعداد محصولات', 'lumi' ), '.lumi-count', array( 'show_count' => 'yes' ) );
		$this->nav_styles();
	}

	/** Dedicated fallback resolver; invalid/deleted terms are always skipped. @param object $term Term. @param array $item Overrides. @return array|null */
	private function resolve_item( $term, $item = array() ) {
		if ( ! $term instanceof \WP_Term || 'product_cat' !== $term->taxonomy ) {
			// Explicitly invalid category IDs still skip safely; an unbound manual row is valid.
			if ( ! empty( $item['category'] ) ) { return null; }
			$title = isset( $item['title'] ) ? $item['title'] : '';
			$subtitle = isset( $item['subtitle'] ) ? $item['subtitle'] : '';
			$image = ! empty( $item['image']['id'] ) ? absint( $item['image']['id'] ) : 0;
			if ( ! $image && '' === trim( wp_strip_all_tags( $title . $subtitle ) ) ) { return null; }
			return array( 'title' => $title, 'subtitle' => $subtitle, 'image' => $image, 'link' => ! empty( $item['link']['url'] ) ? $item['link'] : array( 'url' => '#' ), 'count' => null );
		}
		$link = get_term_link( $term );
		if ( is_wp_error( $link ) ) { return null; }
		return array( 'title' => ! empty( $item['title'] ) ? $item['title'] : $term->name, 'subtitle' => ! empty( $item['subtitle'] ) ? $item['subtitle'] : rawurldecode( $term->slug ), 'image' => ! empty( $item['image']['id'] ) ? absint( $item['image']['id'] ) : absint( get_term_meta( $term->term_id, 'thumbnail_id', true ) ), 'link' => ! empty( $item['link']['url'] ) ? $item['link'] : array( 'url' => $link ), 'count' => $term->count );
	}

	/** Render limited inline HTML only in category titles; banner titles retain escaping. @param string $tag Outer tag. @param string $class Class. @param string $text Title HTML. */
	private function category_title( $tag, $class, $text ) {
		$allowed = array( 'br' => array(), 'strong' => array(), 'b' => array(), 'em' => array(), 'i' => array(), 'small' => array(), 'sup' => array(), 'sub' => array(), 'mark' => array(), 'span' => array( 'class' => true, 'style' => true, 'dir' => true ) );
		$html = wp_kses( $text, $allowed );
		if ( '' === trim( $html ) ) { return; }
		$tag = $this->tag( $tag );
		echo '<' . esc_html( $tag ) . ' class="' . esc_attr( $class ) . '">' . $html . '</' . esc_html( $tag ) . '>';
	}

	/** Fetch terms efficiently and render escaped cards. */
	protected function render() {
		$s = $this->get_settings_for_display();
		$rows = array();
		if ( 'auto' === $s['source'] ) {
			$parent = is_tax( 'product_cat' ) ? get_queried_object_id() : 0;
			$args = array( 'taxonomy' => 'product_cat', 'parent' => $parent, 'hide_empty' => 'yes' === $s['hide_empty'], 'number' => max( 0, (int) $s['limit'] ), 'orderby' => in_array( $s['order_by'], array( 'name', 'count', 'id', 'menu_order' ), true ) ? $s['order_by'] : 'name' );
			$terms = get_terms( $args );
			if ( ! is_wp_error( $terms ) && empty( $terms ) && $parent && 'none' !== $s['fallback'] ) {
				$current = get_term( $parent, 'product_cat' );
				$args['parent'] = 'siblings' === $s['fallback'] && $current instanceof \WP_Term ? $current->parent : 0;
				$terms = get_terms( $args );
			}
			if ( ! is_wp_error( $terms ) ) {
				foreach ( $terms as $term ) { $row = $this->resolve_item( $term ); if ( $row ) { $rows[] = $row; } }
			}
		} else {
			$items = ! empty( $s['category_items'] ) && is_array( $s['category_items'] ) ? array_values( array_filter( $s['category_items'], 'is_array' ) ) : array();
			$ids = array();
			foreach ( $items as $item ) { $ids[] = absint( strtok( isset( $item['category'] ) ? $item['category'] : '', '|' ) ); }
			if ( array_filter( $ids ) ) {
				// Prime both term objects and metadata in one batch, without persistent custom caches.
				get_terms( array( 'taxonomy' => 'product_cat', 'include' => array_filter( $ids ), 'hide_empty' => false, 'update_term_meta_cache' => true ) );
				update_termmeta_cache( array_filter( $ids ) );
			}
			foreach ( $items as $i => $item ) {
				$term = $ids[ $i ] ? get_term( $ids[ $i ], 'product_cat' ) : null;
				$row = $this->resolve_item( $term, $item );
				if ( $row ) { $rows[] = $row; }
			}
		}
		if ( ! $rows ) {
			if ( \Elementor\Plugin::$instance->editor->is_edit_mode() ) { echo '<p>' . esc_html__( 'دسته‌بندی معتبری برای نمایش انتخاب نشده است.', 'lumi' ) . '</p>'; }
			return;
		}
		$this->open_slider( $s );
		$total = count( $rows );
		foreach ( $rows as $i => $row ) {
			echo '<div class="lumi-slide" role="group" aria-roledescription="' . esc_attr__( 'اسلاید', 'lumi' ) . '" aria-label="' . esc_attr( sprintf( __( '%1$s از %2$s', 'lumi' ), number_format_i18n( $i + 1 ), number_format_i18n( $total ) ) ) . '"><a ';
			$this->link_attrs( 'category_' . $i, $row['link'], 'lumi-card lumi-category-card' );
			echo '><span class="lumi-category-media">';
			$this->image( $row['image'], $s['image_size'], wp_strip_all_tags( $row['title'] ), 'lumi-category-image', 0 === $i && 'yes' === $s['above_fold'] );
			echo '</span>';
			if ( 'yes' === $s['show_title'] ) { $this->category_title( $s['title_tag'], 'lumi-primary', $row['title'] ); }
			if ( 'yes' === $s['show_subtitle'] ) { $this->category_title( 'div', 'lumi-secondary', $row['subtitle'] ); }
			if ( 'yes' === $s['show_count'] && null !== $row['count'] ) { echo '<div class="lumi-count">' . esc_html( str_replace( '%s', number_format_i18n( $row['count'] ), $s['count_format'] ) ) . '</div>'; }
			echo '</a></div>';
		}
		$this->close_slider( false, $s );
	}
}
