<?php
/** Plugin bootstrap and dependency validation. @package Lumi */
defined( 'ABSPATH' ) || exit;

/** Owns hooks without loading widget classes before Elementor. */
final class LUMI_Plugin {

	/** @var LUMI_Plugin|null Singleton. */
	private static $instance;

	/** Return the sole loader. */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/** Attach early compatibility and late bootstrap hooks. */
	private function __construct() {
		add_action( 'before_woocommerce_init', array( $this, 'hpos' ) );
		add_action( 'plugins_loaded', array( $this, 'boot' ), 30 );
		add_action( 'init', array( $this, 'translations' ) );
	}

	/** Load bundled translations. */
	public function translations() {
		load_plugin_textdomain( 'lumi', false, dirname( plugin_basename( LUMI_FILE ) ) . '/languages' );
	}

	/** Declare HPOS compatibility: no direct order-table access. */
	public function hpos() {
		if ( class_exists( '\Automattic\WooCommerce\Utilities\FeaturesUtil' ) ) {
			\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'custom_order_tables', LUMI_FILE, true );
		}
	}

	/** Validate versions and register only relevant Elementor hooks. */
	public function boot() {
		if ( ! did_action( 'elementor/loaded' ) || ! class_exists( 'WooCommerce' ) || ! defined( 'ELEMENTOR_VERSION' ) || version_compare( ELEMENTOR_VERSION, '3.5.0', '<' ) || ! defined( 'WC_VERSION' ) || version_compare( WC_VERSION, '6.0', '<' ) ) {
			add_action( 'admin_notices', array( $this, 'notice' ) );
			return;
		}
		add_action( 'elementor/elements/categories_registered', array( $this, 'category' ) );
		add_action( 'elementor/widgets/register', array( $this, 'widgets' ) );
		add_action( 'elementor/frontend/after_register_scripts', array( $this, 'scripts' ) );
		add_action( 'elementor/frontend/after_register_styles', array( $this, 'styles' ) );
		add_action( 'elementor/editor/after_enqueue_scripts', array( $this, 'editor_script' ) );
	}

	/** Display a dismissible dependency notice to administrators. */
	public function notice() {
		if ( current_user_can( 'activate_plugins' ) ) {
			echo '<div class="notice notice-warning is-dismissible"><p>' . esc_html__( 'لومی به المنتور ۳٫۵ یا جدیدتر و ووکامرس ۶ یا جدیدتر نیاز دارد.', 'lumi' ) . '</p></div>';
		}
	}

	/** Add the named widget category. @param object $manager Elementor manager. */
	public function category( $manager ) {
		$manager->add_category( 'lumi', array( 'title' => esc_html__( 'لومی', 'lumi' ), 'icon' => 'eicon-slider-album' ) );
	}

	/** Register both widgets. @param object $manager Widget manager. */
	public function widgets( $manager ) {
		require_once LUMI_PATH . 'includes/class-lumi-widget.php';
		require_once LUMI_PATH . 'widgets/class-lumi-category-carousel.php';
		require_once LUMI_PATH . 'widgets/class-lumi-slider.php';
		$manager->register( new LUMI_Category_Carousel() );
		$manager->register( new LUMI_Slider() );
	}

	/** Register, never globally enqueue, the vanilla slider engine. */
	public function scripts() {
		wp_register_script( 'lumi-slider', LUMI_URL . 'assets/js/lumi-slider.min.js', array(), LUMI_VERSION, true );
	}

	/** Register the shared base stylesheet. */
	public function styles() {
		wp_register_style( 'lumi-slider', LUMI_URL . 'assets/css/lumi-slider.min.css', array(), LUMI_VERSION );
	}

	/** Synchronize native style visibility from repeater values in the editor only. */
	public function editor_script() {
		wp_enqueue_style( 'lumi-editor', LUMI_URL . 'assets/css/lumi-editor.css', array(), LUMI_VERSION );
		wp_enqueue_script( 'lumi-editor', LUMI_URL . 'assets/js/lumi-editor.js', array( 'elementor-editor' ), LUMI_VERSION, true );
	}
}
