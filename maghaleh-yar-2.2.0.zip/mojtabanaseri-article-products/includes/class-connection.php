<?php
namespace Mojtabanaseri\ArticleProducts;
if(!defined('ABSPATH')){
    exit;
}
/** Optional, consent-based service client. All free features work offline. */
final class Connection {
    const EVENT='mnps_service_sync';
    const WIDGET='mnps_news';
    public static function boot() { Modules::connection_hooks(); }
    public static function options(){
        $o=array_merge(array('enabled'=>false,'marketing'=>false,'endpoint'=>'','license'=>'','token'=>'','identity'=>'','status'=>'disconnected','last_sync'=>0,'last_error'=>''),get_option('mnps_connection',array()));
        // A publisher setting, never a customer-domain field. Keep existing configured installs.
        $url=defined('MNPS_SERVICE_URL')?MNPS_SERVICE_URL:$o['endpoint'];
        $o['endpoint']=self::endpoint(apply_filters('maghaleh_yar_service_url',$url));
        $o['marketing']=(bool)get_option('mnps_news_enabled',false);
        $o['enabled']=!empty($o['license'])||$o['marketing'];
        return $o;
    }
    public static function hidden($hidden,$screen){
        if($screen&&$screen->id==='dashboard'&&!in_array(self::WIDGET,$hidden,true)){$hidden[]=self::WIDGET;}
        return $hidden;
    }
    public static function hide_unselected($hidden,$screen){
        return $screen&&$screen->id==='dashboard'&&!self::news_visible()?self::hidden($hidden,$screen):$hidden;
    }
    public static function news_visible($user=0){
        $user=$user?:get_current_user_id();
        $hidden=get_user_option('metaboxhidden_dashboard',$user);
        return is_array($hidden)&&!in_array(self::WIDGET,$hidden,true)&&get_user_meta($user,'_mnps_news_optin',true)==='1';
    }
    public static function news_choice($meta_id,$user,$key,$value){
        if($key!=='metaboxhidden_dashboard'||!is_array($value)||!user_can($user,'manage_options')){return;}
        $on=!in_array(self::WIDGET,$value,true);
        update_user_meta($user,'_mnps_news_optin',$on?'1':'0');
        $users=get_users(array('meta_key'=>'_mnps_news_optin','meta_value'=>'1','fields'=>'ID'));
        $enabled=false;
        foreach($users as$id){if(user_can($id,'manage_options')){$enabled=true;break;}}
        update_option('mnps_news_enabled',$enabled,false);
        if(!$enabled){delete_option('mnps_service_notices');}
        self::schedule();
        if($enabled&&!wp_next_scheduled('mnps_service_news_refresh')){
            wp_schedule_single_event(time()+1,'mnps_service_news_refresh');
        }
    }
    private static function schedule(){
        if(self::options()['enabled']){
            if(!wp_next_scheduled(self::EVENT)){wp_schedule_event(time()+12*HOUR_IN_SECONDS,'twicedaily',self::EVENT);}
        }else{
            wp_clear_scheduled_hook(self::EVENT);
            wp_clear_scheduled_hook('mnps_service_news_refresh');
            delete_option('mnps_service_notices');
        }
    }
    public static function dashboard(){
        if(!current_user_can('manage_options')){return;}
        wp_add_dashboard_widget(self::WIDGET,__('اخبار مقاله‌یار','mojtabanaseri-article-products'),array(__CLASS__,'news'));
    }
    public static function news(){
        if(!self::news_visible()){
            echo '<p>'.esc_html__('برای دریافت اخبار، تیک «اخبار مقاله‌یار» را در تنظیمات صفحه روشن کنید. این انتخاب اجازه اتصال به سرویس مرکزی برای دریافت اخبار را می‌دهد.','mojtabanaseri-article-products').'</p>';
            return;
        }
        $o=self::options();
        if(!$o['endpoint']){
            echo '<p>'.esc_html__('سرویس اخبار هنوز توسط سازنده تنظیم نشده است.','mojtabanaseri-article-products').'</p>';return;
        }
        $found=false;
        foreach(get_option('mnps_service_notices',array())as$n){
            if($n['start']>time()||$n['end']<time()){continue;}
            $found=true;
            echo '<article class="mnps-news-item"><h3>'.esc_html($n['title']).'</h3><p>'.nl2br(esc_html($n['text'])).'</p>';
            // Avoid third-party image requests merely by opening the dashboard.
            if($n['url']&&$n['label']){echo '<p><a href="'.esc_url($n['url']).'" target="_blank" rel="noopener noreferrer">'.esc_html($n['label']).'</a></p>';}
            echo '</article>';
        }
        if(!$found){echo '<p>'.esc_html__('هنوز خبری دریافت نشده است؛ اخبار در بررسی زمان‌بندی‌شده بعدی به‌روز می‌شوند.','mojtabanaseri-article-products').'</p>';}
        echo '<p class="description">'.esc_html__('با برداشتن تیک اخبار در تنظیمات صفحه، دریافت برای شما متوقف می‌شود. باکس‌های سایت به این سرویس وابسته نیستند.','mojtabanaseri-article-products').'</p>';
    }
    public static function routes() { Modules::connection_routes(); }
    public static function privacy(){
        if(function_exists('wp_add_privacy_policy_content')){
            wp_add_privacy_policy_content(__('مقاله‌یار', 'mojtabanaseri-article-products'),('<p>'.esc_html__('مقاله‌یار به‌صورت پیش‌فرض هیچ اطلاعاتی به سرور بیرونی ارسال نمی‌کند. با واردکردن کلید و بررسی لایسنس یا فعال‌سازی اختیاری اخبار، آدرس سایت، شناسه نصب، نسخه افزونه و کلید لایسنس واردشده به سرور انتخابی مدیر ارسال می‌شود. اخبار تنها پس از انتخاب تیک «اخبار مقاله‌یار» در تنظیمات صفحه پیشخوان دریافت و در همان ویجت نمایش داده می‌شود. اطلاعات محصولات، مشتریان و سفارش‌ها ارسال نمی‌شود. ویجت اخبار تصویر خارجی را بارگذاری نمی‌کند. پاک‌کردن کلید و خاموش‌کردن اخبار برای همه مدیران، زمان‌بندی و کش را پاک می‌کند؛ برای حذف سابقه ثبت سایت از سرور مرکزی با مدیر سرویس تماس بگیرید.', 'mojtabanaseri-article-products').'</p>'));
        }
    }
    private static function endpoint($url){
        $url=esc_url_raw(is_string($url)?$url:'');
        $parts=wp_parse_url($url);
        if(!$parts||($parts['scheme']??'')!=='https'||!empty($parts['user'])||!empty($parts['pass'])||!empty($parts['query'])||!empty($parts['fragment'])){
            return '';
        }
        return untrailingslashit($url);
    }
    public static function apply_key($key){
        $old=self::options();
        $key=sanitize_text_field(is_string($key)?$key:'');
        $new=array_merge($old,array('license'=>$key,'status'=>'disconnected','last_error'=>''));
        if($key!==$old['license']){$new['token']='';}
        update_option('mnps_connection',$new,false);
        self::schedule();
        if($key===''){
            return array('ok'=>false,'state'=>'idle','message'=>__('کلید پاک شد؛ امکانات رایگان فعال هستند.','mojtabanaseri-article-products'));
        }
        if(!$new['endpoint']){
            $new['last_error']=__('سرویس لایسنس هنوز توسط سازنده تنظیم نشده است.','mojtabanaseri-article-products');
            update_option('mnps_connection',$new,false);
        }else{self::sync();}
        return self::result();
    }
    public static function result(){
        $o=self::options();
        if(!$o['license']&&!$o['last_error']){return array('ok'=>false,'state'=>'idle','message'=>__('هنوز بررسی نشده است.','mojtabanaseri-article-products'));}
        $messages=array('expired'=>__('لایسنس منقضی شده است.','mojtabanaseri-article-products'),'inactive'=>__('کلید لایسنس معتبر یا فعال نیست.','mojtabanaseri-article-products'),'free'=>__('این کلید به‌عنوان لایسنس فعال تأیید نشد.','mojtabanaseri-article-products'));
        $ok=$o['status']==='active'&&!$o['last_error'];
        return array('ok'=>$ok,'state'=>$ok?'success':'error','message'=>$ok?__('اتصال موفق؛ لایسنس فعال است.','mojtabanaseri-article-products'):($o['last_error']?:($messages[$o['status']]??__('اتصال تأیید نشد؛ دوباره بررسی کنید.','mojtabanaseri-article-products'))));
    }
    public static function check(){
        if(!current_user_can('manage_options')){wp_send_json_error(array('message'=>__('دسترسی مجاز نیست.','mojtabanaseri-article-products')),403);}
        check_ajax_referer('mnps_connection','nonce');
        wp_send_json_success(self::apply_key(wp_unslash($_POST['license']??'')));
    }
    public static function save(){
        if(!current_user_can('manage_options')){wp_die(esc_html__('دسترسی مجاز نیست.','mojtabanaseri-article-products'));}
        check_admin_referer('mnps_connection');
        self::apply_key(wp_unslash($_POST['license']??''));
        wp_safe_redirect(admin_url('admin.php?page=mnps-connection&saved=1'));exit;
    }
    public static function sync(){
        $o=self::options();
        if(!$o['enabled']||!self::endpoint($o['endpoint'])){
            return;
        }
        $site=home_url('/');
        $identity=$o['identity']?:wp_generate_uuid4();
        $o['identity']=$identity;
        $data=array('site'=>$site,'identity'=>$identity,'version'=>MNPS_VERSION,'marketing'=>(bool)$o['marketing']);
        $route='sync';
        if(!$o['token']){
            $route='register';
            $id=strtolower(wp_generate_password(24,false,false));
            $proof=wp_generate_password(48,false,false);
            set_transient('mnps_service_challenge_'.$id,$proof,5*MINUTE_IN_SECONDS);
            $data['challenge']=$id;
            $data['proof']=$proof;
            $data['license']=$o['license'];
        }
        else{
            $data['token']=$o['token'];
        }
        $response=wp_safe_remote_post(add_query_arg('rest_route','/maghaleh-yar-central/v1/'.$route,trailingslashit($o['endpoint'])),array('timeout'=>12,'redirection'=>0,'limit_response_size'=>131072,'headers'=>array('Content-Type'=>'application/json'),'body'=>wp_json_encode($data)));
        if(isset($id)){
            delete_transient('mnps_service_challenge_'.$id);
        }
        $o['last_sync']=time();
        $body=!is_wp_error($response)?json_decode(wp_remote_retrieve_body($response),true):null;
        if(is_wp_error($response)||wp_remote_retrieve_response_code($response)!==200||!is_array($body)||!isset($body['status'])){
            $o['last_error']=__('ارتباط برقرار نشد؛ دسترسی سرور و اینترنت را بررسی کنید. باکس‌ها مستقل از سرور کار می‌کنند.', 'mojtabanaseri-article-products');
            $o['status']='unverified';
            if(!is_wp_error($response)&&in_array(wp_remote_retrieve_response_code($response),array(401,403),true)){
                $o['token']='';
                $o['status']='unverified';
            }
            update_option('mnps_connection',$o,false);
            return;
        }
        if($route==='register'){
            if(!is_string($body['token']??null)||strlen($body['token'])<24||strlen($body['token'])>128){
                $o['last_error']=__('پاسخ سرویس معتبر نیست.', 'mojtabanaseri-article-products');
                update_option('mnps_connection',$o,false);
                return;
            }
            $o['token']=$body['token'];
        }
        $o['status']=in_array($body['status'],array('active','expired','inactive','free'),true)?$body['status']:'unverified';
        $o['last_error']='';
        update_option('mnps_connection',$o,false);
        $notices=array();
        if($o['marketing']){
            foreach(array_slice(is_array($body['notices']??null)?$body['notices']:array(),0,5)as$n){
                if(!is_array($n)){
                    continue;
                }
                $start=absint($n['start']??0);
                $end=absint($n['end']??0);
                if(!$end||$end<=time()||$start>time()){
                    continue;
                }
                $notices[]=array('id'=>sanitize_key(is_scalar($n['id']??null)?(string)$n['id']:''),'title'=>sanitize_text_field(is_scalar($n['title']??null)?(string)$n['title']:''),'text'=>sanitize_textarea_field(is_scalar($n['text']??null)?(string)$n['text']:''),'image'=>self::endpoint($n['image']??''),'label'=>sanitize_text_field(is_scalar($n['label']??null)?(string)$n['label']:''),'url'=>self::endpoint($n['url']??''),'start'=>$start,'end'=>$end);
            }
        }
        update_option('mnps_service_notices',$notices,false);
        do_action('maghaleh_yar_service_status',$o['status']);
    }
    /** News belongs exclusively in the optional dashboard widget. */
    public static function banner(){}
    public static function dismiss(){
        check_ajax_referer('mnps_admin','nonce');
        if(!current_user_can('edit_posts')){
            wp_send_json_error(array('message'=>__('دسترسی مجاز نیست.', 'mojtabanaseri-article-products')),403);
        }
        $id=sanitize_key($_POST['notice']??'');
        $valid=false;
        foreach(get_option('mnps_service_notices',array())as$n){
            if($n['id']===$id){
                $valid=true;
                break;
            }
        }
        if(!$valid){
            wp_send_json_error(array('message'=>__('اعلان پیدا نشد.', 'mojtabanaseri-article-products')),404);
        }
        $ids=get_user_meta(get_current_user_id(),'_mnps_dismissed_notices',true);
        $ids=is_array($ids)?$ids:array();
        $ids[]=$id;
        update_user_meta(get_current_user_id(),'_mnps_dismissed_notices',array_slice(array_unique($ids),-100));
        wp_send_json_success();
    }
    public static function deactivate(){
        wp_clear_scheduled_hook(self::EVENT);
        wp_clear_scheduled_hook('mnps_service_news_refresh');
        delete_option('mnps_service_notices');
    }
    public static function page(){
        if(!current_user_can('manage_options')){return;}
        $o=self::options();$result=self::result();
        $paths=array('success'=>'M5 12l4 4L19 6','error'=>'M6 6l12 12M18 6L6 18','idle'=>'M5 12h14');
        echo '<form class="mnps-settings-panel mnps-connection-form" method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="mnps_connection">';
        wp_nonce_field('mnps_connection');
        echo '<label class="mnps-field"><span>'.esc_html__('کلید لایسنس را وارد کنید','mojtabanaseri-article-products').'</span><input type="password" name="license" autocomplete="off" maxlength="200" dir="ltr" value="'.esc_attr($o['license']).'"></label>';
        echo '<p class="mnps-help">'.esc_html__('با بررسی کلید، آدرس همین سایت، شناسه نصب، نسخه افزونه و کلید به سرویس مرکزی ارسال می‌شود. امکانات رایگان به لایسنس وابسته نیستند.','mojtabanaseri-article-products').'</p>';
        echo '<div class="mnps-license-actions"><button type="submit" class="mnps-primary">'.esc_html__('ذخیره و بررسی ارتباط','mojtabanaseri-article-products').'</button><span class="mnps-license-status" data-license-status="'.esc_attr($result['state']).'" role="status" aria-live="polite"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="'.esc_attr($paths[$result['state']]).'"></path></svg><span>'.esc_html($result['message']).'</span></span></div></form>';
    }
}
