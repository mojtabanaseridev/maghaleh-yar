=== لومی | Lumi ===
Contributors: mojtabanaseri
Tags: elementor, woocommerce, slider, carousel, rtl
Requires at least: 6.0
Requires PHP: 7.4
Stable tag: 1.2.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Two compact native Elementor widgets: WooCommerce category carousel and banner slider.
Read VALIDATION.md for executed tests and remaining visual/theme checks.

== Description ==

Author: Mojtaba Naseri / مجتبی ناصری
Username: mojtabanaseri
Phone: 09367800550
Email: mojtabanaseri157@gmail.com
Telegram: https://t.me/Mojtaba_nsr44

Requires Elementor 3.5+ and WooCommerce 6.0+. Elementor Pro is not required.
No separate settings page, frontend carousel library, tracking or external requests.
Contact information is not printed on website cards or slides.

Widgets in the لومی Elementor category:
* کروسل دسته بندی لومی
* اسلایدر لومی

Category carousel:
* Manual category selection and ordering in Elementor Repeater.
* Automatic root categories on general/shop pages and children on category archives.
* Optional fallback, empty-category filtering, sorting and item limit in automatic mode.
* Local image, title, subtitle and URL overrides. No taxonomy admin fields are added.
* Optional product count, title tag and image shape.
* Fractional columns such as 2.3 and gaps using Elementor's responsive CSS.
* Compact image settings: resolution, ratio for non-circle images, radius for non-circle
  images, background, border, shadow and optional hover zoom.
* Compact text settings: typography, colors and distance.
* No duplicate container/card padding, margin or radius sections.

Banner slider:
* Four native repeater tabs: image, text, buttons and product card.
* Four independently enabled texts, HTML tags and optional native icons.
* Two independently enabled buttons with native URL attributes and optional icons.
* Optional separate mobile image.
* Optional WooCommerce product card or manual card.
* Product card uses product name, image, SKU, short description, price and permalink.
* Responsive card layout and independent mobile hide switches.
* Common styles live outside the repeater and appear when relevant features are enabled.
* Banner and product-image resolutions are in their respective style sections.

Shared navigation:
* Arrows and pagination are independently enabled. Disabled markup is not emitted.
* Arrow icon selection, independent button/icon sizes, normal/hover colors and backgrounds.
* Arrow layouts: opposite sides, grouped at start, center or end.
* Round arrow buttons and dots have equal width/height with theme minimum dimensions reset.
* Pagination: dots, or banner numbers with/without titles; size, spacing and two colors.
* Autoplay settings appear only when enabled; banner includes pause/resume and progress.
* Rewind without cloning slides, transition duration and optional mouse dragging.
* Native touch scrolling, RTL coordinates and keyboard navigation.
* Reduced motion stops autoplay. Focus, visibility, hover and dragging pause it.
* CSS scroll-snap remains usable without JavaScript; enhanced controls start hidden.
* Elementor hooks and observers support reinitialization and layout changes.
* Theme PJAX integrations may dispatch document CustomEvent('lumi:refresh').

== Installation ==

1. Use an isolated test copy first; Woodmart/browser visual checks remain pending.
2. Plugins > Add New > Upload Plugin: select lumi-1.2.0.zip.
3. Ensure Elementor 3.5+ and WooCommerce 6.0+ are active.
4. Edit a page with Elementor and select either widget in the لومی category.
5. Configure native Content and Style controls; use Elementor's own Advanced tab for
   whole-widget spacing, background and other advanced settings.
6. After upgrading, regenerate Elementor CSS and clear the site/CDN cache.

Widget identifiers are unchanged from Lumi 1.0.0. Existing Lumi row content is retained;
new switches are seeded from legacy values. Removed redundant style controls no longer
produce styling. Reapply any required whole-widget styles in Advanced.
Existing Raman widgets are independent and are not automatically converted to Lumi.

== How fallback works ==

Image: local Elementor override -> WooCommerce category thumbnail -> WooCommerce placeholder.
Title: local override -> current category name.
Subtitle: local override -> category slug.
Link: local override -> category archive.
Deleted/invalid categories are skipped. Empty results output no slider on the frontend.

== Custom CSS ==

Stable frontend classes: .lumi-slider, .lumi-viewport, .lumi-track, .lumi-slide,
.lumi-category-media, .lumi-primary, .lumi-secondary, .lumi-content,
.lumi-title-1 through .lumi-title-4, .lumi-button-1, .lumi-button-2,
.lumi-product-card, .lumi-product-media, .lumi-product-body,
.lumi-arrows, .lumi-arrow, .lumi-navigation and .lumi-dot.
Use your site's existing CSS workflow; Lumi does not add a redundant CSS editor.

== Manual test checklist ==

* Both native Content/Style/Advanced panels; repeater's four tabs and placeholders.
* Every optional feature off/on: fields hide, values remain and no empty space appears.
* Existing Lumi documents retain text, buttons, mobile images and card visibility.
* Selected arrow icons, independent sizes, 24px/36px/40px round buttons and 6px/8px dots.
* Every arrow layout and per-device visibility; pagination off leaves no reserved height.
* Native typography/colors and generated CSS after save, reload and CSS regeneration.
* RTL/LTR arrows, dots, drag, keyboard Left/Right/Home/End and focus indicators.
* 2.3 columns on desktop, tablet, mobile and enabled custom breakpoints.
* Slider initially inside a hidden tab, accordion or popup.
* Editor live preview after changing each slider setting; no repeated listeners/timers.
* One slide, zero slides, invalid/deleted category, missing image and placeholder sizing.
* WooCommerce/manual cards; separate mobile image and every mobile hide switch.
* Autoplay, rewind, pause/resume, hover/focus pause, off-screen and hidden browser tab.
* Reduced-motion preference and keyboard-only use.
* JS-delay plugin enabled, native scrolling without JS, and Woodmart PJAX navigation.
* Woodmart-specific button/image styles, no console or Lumi PHP errors.
* Lighthouse CLS/LCP and real image source selection.

== Category carousel changes in 1.2.0 ==

* Manual cards may have no category; meaningful image/title/subtitle content is required.
* A hash URL (#) works; completely empty rows are skipped. Unbound cards have no product count.
* Safe inline title HTML: br, strong, b, em, i, small, sup, sub, mark and span.
* Span class, direction and WordPress-filtered safe inline style are supported.
* Scripts, event handlers and nested links are not allowed. Image alt text remains plain text.
* Repeater titles include row numbers only in Elementor; sorting/add/remove/duplicate renumber them.
* The existing align control is moved to Style, retaining saved responsive values.
* One hover-duration control governs category components; reduced motion disables transitions.
* Pagination presets: dots, lines, capsules and numbers, with responsive start/center/end alignment.
* Preset styles are generated by Elementor. Banner controls and its PHP file are unchanged.

== Changelog ==

= 1.2.0 =
* Implemented the six category carousel revisions above.
* Added category render/CSS, row-number and numbered-pagination regression checks.



= 1.2.0 =
* Removed New badge and redundant container/card controls.
* Added conditional controls and compact native repeater tabs.
* Removed disabled navigation, overlay, card/image and empty content markup.
* Separated arrow button size from icon size and reset theme minimum dimensions.
* Preserved legacy content using per-document switch migration.
* Fixed recursion caused by reading Elementor settings during control registration.
* Added real WordPress/Elementor rendering and CSS integration checks.

== Uninstall ==

Nothing destructive is removed. Elementor document settings remain available if reinstalled.
