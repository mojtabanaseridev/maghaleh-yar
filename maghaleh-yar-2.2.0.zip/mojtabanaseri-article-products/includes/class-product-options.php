<?php
namespace Mojtabanaseri\ArticleProducts;
if (!defined('ABSPATH')) {
    exit;
}
/** Scoped theme rendering and product overrides; no front-end network calls. */
final class ProductOptions {
    public static function clean_item($item) {
        $out = array('price_text'=>Suite::text($item['price_text']??'',120),'button_label'=>Suite::text($item['button_label']??'',100),'url'=>esc_url_raw(is_string($item['url']??null)?$item['url']:''));
        foreach (array('show_price','show_button','show_description','show_badge') as $key) {
            $value=$item[$key]??'inherit';
            $out[$key]=in_array($value,array('on','off'),true)?$value:'inherit';
        }
        return $out;
    }
    public static function clean_overrides($raw){
        $out=array();
        $seen=array();
        foreach(array_slice(is_array($raw)?$raw:array(),0,100)as$item){
            if(!is_array($item)||!is_scalar($item['id']??null)){
                continue;
            }
            $id=absint($item['id']);
            if(!$id||isset($seen[$id])){
                continue;
            }
            $seen[$id]=true;
            $out[]=array_merge(array('id'=>$id,'description'=>sanitize_textarea_field(is_string($item['description']??null)?wp_html_excerpt($item['description'],1500,''):''),'badge'=>sanitize_text_field(is_string($item['badge']??null)?wp_html_excerpt($item['badge'],80,''):''),'hide_description'=>!empty($item['hide_description'])),self::clean_item($item));
        }
        return $out;
    }
    public static function visible($item,$key,$group) {
        $value=$item[$key]??'inherit';
        if ($value==='on') {
            return true;
        }
        if ($value==='off') {
            return false;
        }
        if ($key==='show_description') {
            return !empty($group['description'])&&empty($item['hide_description']);
        }
        return !isset($group[$key])||!empty($group[$key]);
    }
    public static function clean_archive($raw) {
        $raw=is_array($raw)?$raw:array();
        $out=array('show'=>!empty($raw['show']), 'label'=>sanitize_text_field(is_scalar($raw['label']??null)?(string)$raw['label']:'')?:__('مشاهده همه محصولات', 'mojtabanaseri-article-products'), 'url'=>esc_url_raw(is_string($raw['url']??null)?$raw['url']:''), 'new_tab'=>!empty($raw['new_tab']), 'icon'=>Appearance::attachment($raw['icon']??0));
        foreach(array('background'=>'#086779','hover'=>'#064d5a','text'=>'#ffffff') as $key=>$default){
            $out[$key]=sanitize_hex_color(is_string($raw[$key]??null)?$raw[$key]:'')?:$default;
        }
        foreach(array('padding_y'=>array(0,28,8),'mobile_padding_y'=>array(0,24,7),'size'=>array(11,24,13),'mobile_size'=>array(11,24,12),'padding'=>array(4,28,12),'mobile_padding'=>array(4,24,10),'radius'=>array(0,36,8),'icon_size'=>array(8,32,16)) as$key=>$bounds){
            $out[$key]=isset($raw[$key])&&is_scalar($raw[$key])?max($bounds[0],min($bounds[1],absint($raw[$key]))):$bounds[2];
        }
        return $out;
    }
    public static function archive_html($group) {
        $a=self::clean_archive($group['archive']??array());
        if (!$a['show']) {
            return '';
        }
        $url=$a['url'];
        if (!$url && ($group['auto']['mode']??'manual')==='auto' && !empty($group['auto']['category'])) {
            $term=get_term_link((int)$group['auto']['category'],'product_cat');
            if(!is_wp_error($term)){
                $url=$term;
            }
        }
        if(!$url&&function_exists('wc_get_page_permalink')){
            $url=function_exists('wc_get_page_id')&&wc_get_page_id('shop')>0?wc_get_page_permalink('shop'):(get_post_type_archive_link('product')?:add_query_arg('post_type','product',home_url('/')));
        }
        if(!$url){
            return '';
        }
        $style='';
        if(!isset($group['customize'])||$group['customize']){
            foreach(array('background','hover','text','size','mobile_size','padding','mobile_padding','padding_y','mobile_padding_y','radius','icon_size')as$key){
                $style.='--mnps-archive-'.str_replace('_','-',$key).':'.$a[$key].(is_int($a[$key])?'px':'').';';
            }
        }
        return '<a class="mnps-archive-button button" href="'.esc_url($url).'"'.($a['new_tab']?' target="_blank" rel="noopener noreferrer"':'').' style="'.esc_attr($style).'">'.esc_html($a['label']).($a['icon']?Appearance::media_icon($a['icon'],'arrow'):'').'</a>';
    }
    public static function theme_html($group,$preview=false) {
        if(!function_exists('wc_get_template_part')){
            return '';
        }
        $cards='';if(function_exists('_prime_post_caches')){_prime_post_caches(array_column($group['items'],'id'),true,true);}
        $old_product=$GLOBALS['product']??null;
        $old_post=$GLOBALS['post']??null;
        $old_loop=$GLOBALS['woocommerce_loop']??null;
        try {
            wc_set_loop_prop('columns',max(1,min(4,(int)$group['desktop'])));
            foreach($group['items'] as$item){
                $p=wc_get_product($item['id']);
                if(!$p||$p->get_status()!=='publish'||!$p->is_visible()||(!empty($group['hide_stock'])&&!$p->is_in_stock())){
                    continue;
                }
                $GLOBALS['product']=$p;
                $GLOBALS['post']=get_post($p->get_id());
                $url=!empty($item['url'])?$item['url']:$p->get_permalink();
                $link=function()use($url){
                    return $url;
                }
                ;
                $classes=function($classes)use($item,$group){
                    $classes[]='mnps-card';
                    foreach(array('price','button','badge','description')as$key){
                        if(!self::visible($item,'show_'.$key,$group)){
                            $classes[]='mnps-hide-'.$key;
                        }
                    }
                    return $classes;
                }
                ;
                $button=function($html)use($item,$group,$url,$p){
                    return self::visible($item,'show_button',$group)?'<a class="button mnps-theme-product-button" href="'.esc_url($url).'">'.esc_html(!empty($item['button_label'])?$item['button_label']:($group['button_label']??__('مشاهده محصول', 'mojtabanaseri-article-products'))).'<span class="screen-reader-text">: '.esc_html($p->get_name()).'</span></a>':'';
                }
                ;
                $extra=function()use($item,$group,$p){
                    if(self::visible($item,'show_badge',$group)&&!empty($item['badge'])){
                        echo '<span class="mnps-theme-badge">'.esc_html($item['badge']).'</span>';
                    }
                    if(self::visible($item,'show_description',$group)){
                        $desc=$item['description']??'';
                        if(!$desc){
                            $desc=wp_strip_all_tags(strip_shortcodes($p->get_short_description()));
                        }
                        if($desc){
                            echo '<p class="mnps-theme-description">'.esc_html(wp_trim_words($desc,$group['words']??30,'…')).'</p>';
                        }
                    }
                }
                ;
                $removed=array();
                foreach(array('woocommerce_template_loop_price'=>'show_price','woocommerce_template_loop_add_to_cart'=>'show_button','woocommerce_show_product_loop_sale_flash'=>'show_badge')as$callback=>$key){
                    if(!self::visible($item,$key,$group)){
                        foreach(array('woocommerce_after_shop_loop_item_title','woocommerce_after_shop_loop_item','woocommerce_before_shop_loop_item_title')as$hook){
                            $priority=has_action($hook,$callback);
                            if($priority!==false){
                                remove_action($hook,$callback,$priority);
                                $removed[]=array($hook,$callback,$priority);
                            }
                        }
                    }
                }
                $price=function($html,$product)use($item,$p){return $product->get_id()===$p->get_id()&&!empty($item['price_text'])?esc_html($item['price_text']):$html;};
                add_filter('woocommerce_get_price_html',$price,999,2);
                add_filter('woocommerce_loop_product_link',$link,999);
                add_filter('post_class',$classes,999);
                add_filter('woocommerce_loop_add_to_cart_link',$button,999);
                add_action('woocommerce_after_shop_loop_item_title',$extra,15);
                $level=ob_get_level();
                ob_start();
                try{
                    wc_get_template_part('content','product');
                    $cards.=ob_get_clean();
                }
                finally{
                    while(ob_get_level()>$level){
                        ob_end_clean();
                    }
                    remove_filter('woocommerce_get_price_html',$price,999);
                    remove_filter('woocommerce_loop_product_link',$link,999);
                    remove_filter('post_class',$classes,999);
                    remove_filter('woocommerce_loop_add_to_cart_link',$button,999);
                    remove_action('woocommerce_after_shop_loop_item_title',$extra,15);
                    foreach($removed as$entry){
                        add_action($entry[0],$entry[1],$entry[2]);
                    }
                }
            }
        }
        finally {
            $GLOBALS['product']=$old_product;
            $GLOBALS['post']=$old_post;
            if($old_loop===null){
                unset($GLOBALS['woocommerce_loop']);
            }
            else{
                $GLOBALS['woocommerce_loop']=$old_loop;
            }
        }
        if(!$cards){
            return ($group['empty']??'hide')==='text'?'<p>'.esc_html($group['empty_text']??'').'</p>':($preview?('<p>'.esc_html__('محصول قابل نمایش وجود ندارد.', 'mojtabanaseri-article-products').'</p>'):'');
        }
        if(!$preview){
            wp_enqueue_style('mnps-theme-layout',MNPS_URL.'assets/theme-layout.css',array(),MNPS_VERSION);
            wp_enqueue_script('mnps-front');
        }
        $id=wp_unique_id('mnps-theme-');
        $label=$group['title']?:__('محصولات پیشنهادی', 'mojtabanaseri-article-products');
        $out='<section class="mnps-section mnps-theme-cards woocommerce mnps-'.esc_attr($group['layout']).'" dir="rtl" aria-label="'.esc_attr($label).'" style="--mnps-columns:'.absint($group['desktop']).'"><div class="mnps-heading">'.Appearance::title($group,$id.'-title').'<div class="mnps-heading-actions">'.self::archive_html($group);
        if($group['layout']==='slider'){
            $out.=('<div class="mnps-arrows">'.'<button type="button" class="mnps-arrow" data-mnps-direction="previous" aria-label="'.esc_attr__('محصولات قبلی', 'mojtabanaseri-article-products').'" aria-controls="').esc_attr($id).'">'.Appearance::icon('right').('</button>'.'<button type="button" class="mnps-arrow" data-mnps-direction="next" aria-label="'.esc_attr__('محصولات بعدی', 'mojtabanaseri-article-products').'" aria-controls="').esc_attr($id).'">'.Appearance::media_icon($group['left_icon']??0,'left').'</button></div>';
        }
        $styles='';
        if(!$preview&&did_action('wp_head')&&!wp_style_is('mnps-theme-layout','done')){
            ob_start();
            wp_print_styles('mnps-theme-layout');
            $styles=ob_get_clean();
        }
        return $styles.$out.'</div></div><ul class="products mnps-track" id="'.esc_attr($id).'" tabindex="0" aria-label="'.esc_attr($label).'">'.$cards.'</ul></section>';
    }
}
