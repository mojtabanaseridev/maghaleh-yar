<?php
namespace Mojtabanaseri\ArticleProducts;
if (!defined('ABSPATH')) { exit; }
/** Optional import and backup implementations. */
final class TransferModule extends Transfer {

    public static function backup($records,$include_settings=true){
        $products=array();
        $media=array();
        $categories=array();
        $media_ids=array();
        $visibility=array();
        global $wpdb;
        $box_ids=array_filter(array_map('absint',array_column($records,'box')));
        if($box_ids){
            $rows=$wpdb->get_results('SELECT box_id,post_id,enabled FROM '.$wpdb->prefix.'mnps_usage WHERE box_id IN ('.implode(',',$box_ids).') ORDER BY box_id,post_id LIMIT 20001');
            if(count($rows)>20000){
                wp_send_json_error(array('message'=>__('بکاپ را به چند بخش انتخاب‌شده تقسیم کنید؛ بیش از ۲۰۰۰۰ محل استفاده وجود دارد.','mojtabanaseri-article-products')),400);
            }
            foreach($rows as$row){
                $visibility[]=array('box'=>absint($row->box_id),'post'=>absint($row->post_id),'enabled'=>(bool)$row->enabled);
            }
        }
        foreach($records as$record){
            $g=$record['group'];
            $ids=array_merge(array_column($g['items']??array(),'id'),array_column($g['product_overrides']??array(),'id'),$g['auto']['pinned']??array(),$g['auto']['excluded']??array());
            foreach($g['table']['rows']??array() as$row){if(!empty($row['product']))$ids[]=$row['product'];foreach($row['cells']??array()as$cell)$media_ids[]=absint($cell['image']??0);}
            foreach($ids as$id){
                if(isset($products[$id])){
                    continue;
                }
                $p=function_exists('wc_get_product')?wc_get_product($id):false;
                $products[$id]=array('id'=>absint($id),'sku'=>$p?$p->get_sku():'','name'=>$p?$p->get_name():__('محصول حذف‌شده', 'mojtabanaseri-article-products'));
            }
            $cat=absint($g['auto']['category']??0);
            if($cat){
                $term=get_term($cat,'product_cat');
                $categories[$cat]=array('id'=>$cat,'slug'=>$term&&!is_wp_error($term)?$term->slug:'','name'=>$term&&!is_wp_error($term)?$term->name:'');
            }
            foreach(array('title_icon','button_icon','left_icon','right_icon')as$key){
                $media_ids[]=absint($g[$key]??0);
            }
            foreach(array('image','icon_media')as$key){
                $media_ids[]=absint($g['cta'][$key]??0);
            }
            $media_ids[]=absint($g['archive']['icon']??0);
        }
        foreach(array_unique(array_filter($media_ids))as$id){
            $media[$id]=array('id'=>$id,'url'=>wp_get_attachment_url($id)?:'','name'=>get_the_title($id));
        }
        $designs=array();
        if($include_settings){
            foreach(get_posts(array('post_type'=>'mnps_design','post_status'=>array('publish','draft'),'numberposts'=>101))as$p){
                if(count($designs)>=100){
                    wp_send_json_error(array('message'=>__('بیش از ۱۰۰ طرح شخصی؛ ابتدا تعداد طرح‌ها را کاهش دهید.', 'mojtabanaseri-article-products')),400);
                }
                $designs[]=array('id'=>$p->ID,'name'=>$p->post_title,'paint'=>Suite::paint(get_post_meta($p->ID,'_mnps_paint',true)),'style'=>Appearance::clean(get_post_meta($p->ID,'_mnps_style',true)));
            }
        }
        return array('format'=>self::FORMAT,'schema'=>1,'version'=>MNPS_VERSION,'created'=>gmdate('c'),'site'=>self::site(),'boxes'=>$records,'visibility'=>$visibility,'products'=>array_values($products),'media'=>array_values($media),'categories'=>array_values($categories),'settings'=>$include_settings?array('behavior'=>Features::settings(),'appearance'=>Appearance::current(),'paint'=>Suite::paint(get_option('mnps_paint',array()))):null,'designs'=>$designs);
    }
    public static function export_api(){
        self::auth();
        $ids=self::selected();
        $backup=self::backup(self::records($ids?:null),!$ids);
        if(strlen(wp_json_encode($backup))>5*1024*1024){
            wp_send_json_error(array('message'=>__('بکاپ بزرگ‌تر از ۵ مگابایت است؛ خروجی را در چند بخش انتخاب‌شده بگیرید.','mojtabanaseri-article-products')),400);
        }
        wp_send_json_success(array('backup'=>$backup,'filename'=>'maghaleh-yar-'.gmdate('Ymd-His').'.json'));
    }
    private static function hash_settings(){
        return hash('sha256',wp_json_encode(array(get_option('mnps_behavior'),get_option('mnps_appearance'),get_option('mnps_paint'))));
    }
    public static function import_review_api(){
        self::auth();
        $raw=wp_unslash($_POST['backup']??'');
        if(!is_string($raw)||strlen($raw)>5*1024*1024){
            wp_send_json_error(array('message'=>__('فایل JSON باید حداکثر ۵ مگابایت باشد.', 'mojtabanaseri-article-products')),400);
        }
        $b=json_decode($raw,true);
        if(!is_array($b)||($b['format']??'')!==self::FORMAT||($b['schema']??0)!==1||!is_array($b['boxes']??null)||count($b['boxes'])>1000){
            wp_send_json_error(array('message'=>__('ساختار یا نسخه بکاپ پشتیبانی نمی‌شود.', 'mojtabanaseri-article-products')),400);
        }
        foreach(array('products','media','categories','designs')as$key){
            if(!is_array($b[$key]??null)||count($b[$key])>50000){
                wp_send_json_error(array('message'=>__('ساختار فهرست‌های بکاپ معتبر نیست.', 'mojtabanaseri-article-products')),400);
            }
        }
        $site=self::site();
        $same=isset($b['site']['identity'],$b['site']['url'])&&$b['site']['identity']===$site['identity']&&$b['site']['url']===$site['url'];
        $maps=array('products'=>array(),'media'=>array(),'categories'=>array());
        $missing=array();
        foreach($maps as$type=>$unused){
            foreach($b[$type]as$ref){
                if(!is_array($ref)||empty($ref['id'])||!is_scalar($ref['id'])){
                    wp_send_json_error(array('message'=>__('شناسه مرجع بکاپ معتبر نیست.', 'mojtabanaseri-article-products')),400);
                }
                $id=absint($ref['id']);
                $target=0;
                if($type==='products'){
                    $target=$same&&function_exists('wc_get_product')&&wc_get_product($id)?$id:(!empty($ref['sku'])&&is_string($ref['sku'])&&function_exists('wc_get_product_id_by_sku')?wc_get_product_id_by_sku($ref['sku']):0);
                }
                elseif($type==='media'){
                    $target=$same?Appearance::attachment($id):(is_string($ref['url']??null)?attachment_url_to_postid(esc_url_raw($ref['url'])):0);
                    $target=Appearance::attachment($target);
                }
                else{
                    $term=$same?get_term($id,'product_cat'):(is_string($ref['slug']??null)?get_term_by('slug',sanitize_title($ref['slug']),'product_cat'):false);
                    $target=$term&&!is_wp_error($term)?(int)$term->term_id:0;
                }
                $maps[$type][$id]=$target;
                if(!$target){
                    $missing[]=array('type'=>$type,'id'=>$id,'name'=>sanitize_text_field(is_scalar($ref['name']??null)?(string)$ref['name']:__('مرجع ', 'mojtabanaseri-article-products').$id));
                }
            }
        }
        $records=array();
        $hashes=array();
        $seen=array();
        foreach($b['boxes']as$record){
            if(!is_array($record)||!is_array($record['group']??null)||empty($record['group']['key'])){
                wp_send_json_error(array('message'=>__('اطلاعات باکس ناقص است.', 'mojtabanaseri-article-products')),400);
            }
            $g=Plugin::boot()->normalize(array($record['group']))[0];
            foreach(array('title_icon','button_icon','left_icon','right_icon')as$mk){
                $g[$mk]=is_scalar($record['group'][$mk]??null)?absint($record['group'][$mk]):0;
            }
            foreach(array('image','icon_media')as$mk){
                $g['cta'][$mk]=is_scalar($record['group']['cta'][$mk]??null)?absint($record['group']['cta'][$mk]):0;
            }
            $g['archive']['icon']=is_scalar($record['group']['archive']['icon']??null)?absint($record['group']['archive']['icon']):0;
            $source=$same?absint($record['source']??0):0;
            if($source&&(!in_array(get_post_type($source),array('post','mnps_group'),true)||!current_user_can('edit_post',$source))){
                $source=0;
            }
            $identity=$source.':'.$g['key'];
            if(isset($seen[$identity])&&$source){
                wp_send_json_error(array('message'=>__('باکس تکراری در بکاپ وجود دارد.', 'mojtabanaseri-article-products')),400);
            }
            $seen[$identity]=true;
            $records[]=array('box'=>is_scalar($record['box']??null)?absint($record['box']):0,'source'=>$source,'name'=>sanitize_text_field(is_scalar($record['name']??null)?(string)$record['name']:$g['title']),'group'=>$g);
            if($source){
                $hashes[$source]=Admin::fingerprint($source);
            }
            // Every referenced ID must have a mapping record, even in hand-edited backups.
            foreach(array_merge(array_column($g['items'],'id'),array_column($g['product_overrides'],'id'),$g['auto']['pinned'],$g['auto']['excluded'])as$id){
                if(!array_key_exists($id,$maps['products'])){
                    $maps['products'][$id]=0;
                    $missing[]=array('type'=>'products','id'=>$id,'name'=>__('محصول #', 'mojtabanaseri-article-products').$id);
                }
            }
            $refs=array_merge(array_map(function($k)use($g){
                return $g[$k]??0;
            }
            ,array('title_icon','button_icon','left_icon','right_icon')),array($g['cta']['image']??0,$g['cta']['icon_media']??0,$g['archive']['icon']??0));
            foreach(array_unique(array_filter($refs))as$id){
                if(!array_key_exists($id,$maps['media'])){
                    $maps['media'][$id]=0;
                    $missing[]=array('type'=>'media','id'=>$id,'name'=>__('رسانه #', 'mojtabanaseri-article-products').$id);
                }
            }
            $cat=$g['auto']['category'];
            if($cat&&!array_key_exists($cat,$maps['categories'])){
                $maps['categories'][$cat]=0;
                $missing[]=array('type'=>'categories','id'=>$cat,'name'=>__('دسته #', 'mojtabanaseri-article-products').$cat);
            }
        }
        $settings=is_array($b['settings']??null)?array('behavior'=>Features::clean_settings($b['settings']['behavior']??array()),'appearance'=>Appearance::clean($b['settings']['appearance']??array()),'paint'=>Suite::paint($b['settings']['paint']??array())):null;
        $designs=array();
        foreach(array_slice($b['designs'],0,100)as$d){
            if(!is_array($d)){
                continue;
            }
            $id=$same?absint($d['id']??0):0;
            if($id&&('mnps_design'!==get_post_type($id)||!current_user_can('edit_post',$id))){
                $id=0;
            }
            $designs[]=array('id'=>$id,'name'=>sanitize_text_field(is_scalar($d['name']??null)?(string)$d['name']:__('طرح', 'mojtabanaseri-article-products')),'paint'=>Suite::paint($d['paint']??array()),'style'=>Appearance::clean($d['style']??array()),'hash'=>$id?hash('sha256',wp_json_encode(array(get_post_meta($id,'_mnps_style',true),get_post_meta($id,'_mnps_paint',true)))):'');
        }
        $visibility=array();
        $visibility_hashes=array();
        if($same){
            $allowed=array_column($records,null,'box');
            foreach(array_slice(is_array($b['visibility']??null)?$b['visibility']:array(),0,20000)as$v){
                if(!is_array($v)){
                    continue;
                }
                $box=is_scalar($v['box']??null)?absint($v['box']):0;
                $post=is_scalar($v['post']??null)?absint($v['post']):0;
                if(!isset($allowed[$box])||!$allowed[$box]['source']||!$post||!current_user_can('edit_post',$post)){
                    continue;
                }
                $visibility[]=array('box'=>$box,'post'=>$post,'enabled'=>!empty($v['enabled']));
                $visibility_hashes[$post]=hash('sha256',wp_json_encode(get_post_meta($post,Store::HIDDEN,true)));
            }
        }
        $data=array('same'=>$same,'records'=>$records,'visibility'=>$visibility,'visibility_hashes'=>$visibility_hashes,'maps'=>$maps,'missing'=>$missing,'hashes'=>$hashes,'settings'=>$settings,'settings_hash'=>self::hash_settings(),'designs'=>$designs);
        $token=self::put_review('import',$data);
        wp_send_json_success(array('token'=>$token,'same'=>$same,'count'=>count($records),'names'=>array_column($records,'name'),'missing'=>$missing,'settings'=>(bool)$settings,'designs'=>count($designs),'visibility'=>count($visibility)));
    }
    private static function mapped_group($g,$maps){
        $items=array();
        foreach($g['items']as$item){
            $item['id']=$maps['products'][$item['id']]??0;
            if($item['id']){
                $items[]=$item;
            }
        }
        $g['items']=$items;
        foreach($g['table']['rows']??array()as$i=>$row){$g['table']['rows'][$i]['product']=$maps['products'][$row['product']??0]??0;foreach($row['cells']as$j=>$c)$g['table']['rows'][$i]['cells'][$j]['image']=$maps['media'][$c['image']??0]??0;}
        $overrides=array();
        foreach($g['product_overrides']??array()as$item){
            $item['id']=$maps['products'][$item['id']]??0;
            if($item['id']){
                $overrides[]=$item;
            }
        }
        $g['product_overrides']=$overrides;
        foreach(array('pinned','excluded')as$key){
            $g['auto'][$key]=array_values(array_filter(array_map(function($id)use($maps){
                return $maps['products'][$id]??0;
            }
            ,$g['auto'][$key])));
        }
        $g['auto']['category']=$maps['categories'][$g['auto']['category']]??0;
        foreach(array('title_icon','button_icon','left_icon','right_icon')as$key){
            $g[$key]=$maps['media'][$g[$key]??0]??0;
        }
        foreach(array('image','icon_media')as$key){
            $g['cta'][$key]=$maps['media'][$g['cta'][$key]??0]??0;
        }
        $g['archive']['icon']=$maps['media'][$g['archive']['icon']??0]??0;
        return $g;
    }
    public static function import_commit_api(){
        self::auth();
        list($key,$d)=self::review('import');
        $mode=($_POST['mode']??'copy')==='update'&&$d['same']?'update':'copy';
        $supplied=json_decode(wp_unslash($_POST['mapping']??'{}'),true);
        $supplied=is_array($supplied)?$supplied:array();
        foreach($d['missing']as$ref){
            $value=$supplied[$ref['type'].':'.$ref['id']]??null;
            if($value===null||(!is_scalar($value))||!preg_match('/^[0-9]+$/D',(string)$value)){
                wp_send_json_error(array('message'=>__('برای همه موارد پیدا‌نشده، شناسه جایگزین یا حذف از بکاپ (۰) را انتخاب کنید.', 'mojtabanaseri-article-products')),400);
            }
            $id=absint($value);
            if($id){
                $valid=$ref['type']==='products'?function_exists('wc_get_product')&&wc_get_product($id):($ref['type']==='media'?Appearance::attachment($id):term_exists($id,'product_cat'));
                if(!$valid){
                    wp_send_json_error(array('message'=>__('شناسه جایگزین معتبر نیست: ', 'mojtabanaseri-article-products').$ref['name']),400);
                }
            }
            $d['maps'][$ref['type']][$ref['id']]=$id;
        }
        if($mode==='update'){
            foreach($d['hashes']as$id=>$hash){
                if(!hash_equals($hash,Admin::fingerprint($id))){
                    wp_send_json_error(array('message'=>__('یکی از باکس‌ها پس از بررسی تغییر کرده؛ دوباره بررسی کنید.', 'mojtabanaseri-article-products')),409);
                }
            }
        }
        $apply_visibility=$mode==='update'&&!empty($_POST['visibility']);
        if($apply_visibility){
            foreach($d['visibility_hashes']as$post=>$hash){
                if(!hash_equals($hash,hash('sha256',wp_json_encode(get_post_meta($post,Store::HIDDEN,true))))){
                    wp_send_json_error(array('message'=>__('وضعیت نمایش مقاله پس از بررسی تغییر کرده است.','mojtabanaseri-article-products')),409);
                }
            }
        }
        $apply_settings=!empty($_POST['settings'])&&$d['settings'];
        if($apply_settings&&!hash_equals($d['settings_hash'],self::hash_settings())){
            wp_send_json_error(array('message'=>__('تنظیمات پس از بررسی تغییر کرده است.', 'mojtabanaseri-article-products')),409);
        }
        foreach(!empty($_POST['designs'])?$d['designs']:array()as$design){
            if($mode==='update'&&$design['id']&&!hash_equals($design['hash'],hash('sha256',wp_json_encode(array(get_post_meta($design['id'],'_mnps_style',true),get_post_meta($design['id'],'_mnps_paint',true)))))){
                wp_send_json_error(array('message'=>__('طرح شخصی پس از بررسی تغییر کرده است.', 'mojtabanaseri-article-products')),409);
            }
        }
        // Consume before mutation: a double click cannot apply the import twice.
        delete_transient($key);
        $sources=array();
        $codes=array();
        $errors=array();
        $box_map=array();
        foreach($d['records']as$record){
            $g=self::mapped_group($record['group'],$d['maps']);
            $id=$mode==='update'?$record['source']:0;
            if(!$id){
                $id=wp_insert_post(array('post_type'=>'mnps_group','post_status'=>current_user_can('publish_posts')?'publish':'draft','post_author'=>get_current_user_id(),'post_title'=>$record['name']),true);
                if(is_wp_error($id)){
                    $errors[]=$record['name'];
                    continue;
                }
                $g['key']='g'.str_replace('-','',wp_generate_uuid4());
            }
            if($mode==='update'&&$record['box']){
                $box_map[$record['box']]=array('source'=>$id,'key'=>$g['key']);
            }
            if(!isset($sources[$id])){
                $before=get_post_meta($id,Plugin::META,true);
                if($mode==='update'&&isset($d['hashes'][$id])&&!hash_equals($d['hashes'][$id],Admin::fingerprint($id))){
                    $errors[]=$record['name'];
                    unset($box_map[$record['box']]);
                    continue;
                }
                $sources[$id]=array('before'=>$before,'groups'=>is_array($before)?$before:array());
            }
            $g=Plugin::boot()->normalize(Plugin::boot()->protect_code(array($g),$id))[0];
            $found=false;
            foreach($sources[$id]['groups']as&$old){
                if($old['key']===$g['key']){
                    $old=$g;
                    $found=true;
                    break;
                }
            }
            unset($old);
            if(!$found){
                $sources[$id]['groups'][]=$g;
            }
        }
        foreach($sources as$id=>$change){
            if(!update_post_meta($id,Plugin::META,wp_slash($change['groups']),$change['before'])&&wp_json_encode(get_post_meta($id,Plugin::META,true))!==wp_json_encode($change['groups'])){
                $errors[]=get_the_title($id);
                foreach($box_map as$origin=>$entry){
                    if($entry['source']==$id){
                        unset($box_map[$origin]);
                    }
                }
                continue;
            }
            Features::snapshot($id,$change['groups'],is_array($change['before'])?$change['before']:array());
            Plugin::boot()->index($id,$change['groups']);
            Store::index($id);
            foreach($change['groups']as$g){
                $codes[]=array('name'=>$g['title'],'code'=>Store::code($id,$g['key']));
            }
        }
        if($apply_visibility){
            $posts=array();
            foreach($d['visibility']as$v){
                if(!isset($box_map[$v['box']])){
                    continue;
                }
                $entry=$box_map[$v['box']];
                $alias=Store::id($entry['source'],$entry['key']);
                if(!$alias){
                    continue;
                }
                $post=$v['post'];
                if(!isset($posts[$post])){
                    $before=get_post_meta($post,Store::HIDDEN,true);
                    $posts[$post]=array('before'=>$before,'hidden'=>is_array($before)?array_map('absint',$before):array());
                }
                $hidden=$posts[$post]['hidden'];
                $hidden=array_values(array_diff($hidden,array($alias)));
                if(!$v['enabled']){
                    $hidden[]=$alias;
                }
                $posts[$post]['hidden']=$hidden;
            }
            foreach($posts as$post=>$change){
                if(!update_post_meta($post,Store::HIDDEN,$change['hidden'],$change['before'])&&get_post_meta($post,Store::HIDDEN,true)!==$change['hidden']){
                    $errors[]=get_the_title($post);
                    continue;
                }
                Store::index($post);
            }
        }
        if($apply_settings){
            update_option('mnps_behavior',$d['settings']['behavior'],false);
            update_option('mnps_appearance',$d['settings']['appearance'],false);
            update_option('mnps_paint',$d['settings']['paint']??array(),false);
        }
        if(!empty($_POST['designs'])){
            foreach($d['designs']as$design){
                $id=$mode==='update'?$design['id']:0;
                $params=array('post_type'=>'mnps_design','post_status'=>'draft','post_title'=>$design['name'],'post_author'=>get_current_user_id());
                if($id){
                    $params['ID']=$id;
                }
                $id=$id?wp_update_post($params,true):wp_insert_post($params,true);
                if(is_wp_error($id)){
                    $errors[]=$design['name'];
                    continue;
                }
                update_post_meta($id,'_mnps_style',$design['style']);
                update_post_meta($id,'_mnps_paint',$design['paint']??array());
            }
        }
        Store::rescan();
        Plugin::boot()->purge_all();
        wp_send_json_success(array('codes'=>$codes,'errors'=>$errors,'message'=>$errors?__('بازیابی بخشی از موارد انجام نشد؛ گزارش را بررسی کنید.', 'mojtabanaseri-article-products'):__('بازیابی انجام شد.', 'mojtabanaseri-article-products')));
    }
    public static function page(){
        if(!current_user_can('manage_options')){
            return;
        }
        echo ('<section class="mnps-settings-panel">'.'<h2>'.esc_html__('خروجی JSON', 'mojtabanaseri-article-products').'</h2>'.'<p>'.esc_html__('همه باکس‌ها، تنظیمات و طرح‌های شخصی را دریافت کنید. برای خروجی انتخابی، در مدیریت باکس‌ها کارت‌ها را انتخاب کنید.', 'mojtabanaseri-article-products').'</p>'.'<button type="button" class="mnps-primary" data-export-all>'.esc_html__('دریافت بکاپ کامل مقاله‌یار', 'mojtabanaseri-article-products').'</button>'.'<p class="mnps-help">'.esc_html__('این فایل بکاپ کل سایت نیست و فایل تصاویر، محصولات، مقاله‌ها، لایسنس و اطلاعات ارتباطی را شامل نمی‌شود.', 'mojtabanaseri-article-products').'</p>'.'</section>'.'<section class="mnps-settings-panel">'.'<h2>'.esc_html__('ورود اطلاعات', 'mojtabanaseri-article-products').'</h2>'.'<label class="mnps-field">'.'<span>'.esc_html__('فایل بکاپ JSON (حداکثر ۵ مگابایت)', 'mojtabanaseri-article-products').'</span>'.'<input type="file" accept=".json,application/json" data-import-file>'.'</label>'.'<button type="button" class="mnps-secondary" data-import-review>'.esc_html__('بررسی پیش از بازیابی', 'mojtabanaseri-article-products').'</button>'.'<p data-transfer-status role="status" aria-live="polite">'.'</p>'.'</section>');
    }
}
