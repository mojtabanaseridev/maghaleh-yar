/* Uses WordPress's real Backbone models; does not substitute for editor UI tests. */
const fs=require('fs'),vm=require('vm'),assert=require('assert'),path=require('path');
const wp=process.argv[2];if(!wp)throw Error('Pass WordPress wp-includes/js directory');
let n=0,next=1,frames=new Map(),callback;const hooks={};
const ctx={console,setTimeout,clearTimeout,requestAnimationFrame:f=>{let id=next++;frames.set(id,f);return id},cancelAnimationFrame:id=>frames.delete(id)};ctx.window=ctx;ctx.self=ctx;ctx.global=ctx;ctx.elementor={hooks:{addAction:(name,fn)=>{hooks[name]=fn; if(name==='panel/open_editor/widget/lumi_slider')callback=fn}}};
vm.createContext(ctx);for(const name of ['underscore.min.js','backbone.min.js'])vm.runInContext(fs.readFileSync(path.join(wp,name),'utf8'),ctx);
vm.runInContext(fs.readFileSync(path.join(__dirname,'../assets/js/lumi-editor.js'),'utf8'),ctx);
const row=new ctx.Backbone.Model({_id:'a',show_text_2:'yes',show_card:'',show_button_1:'',card_title:'Keep my title'});
const rows=new ctx.Backbone.Collection([row]);const settings=new ctx.Backbone.Model({slides:rows,lumi_legacy_map:'[]'});const model=new ctx.Backbone.Model({settings});
const flush=()=>{const jobs=[...frames.values()];frames.clear();jobs.forEach(fn=>fn())};const ok=(x,label)=>{assert.ok(x,label);n++};
callback(null,model);flush();ok(settings.get('lumi_has_text_2')==='yes','title section enabled');ok(settings.get('lumi_has_card')==='','card section hidden');
row.set({show_card:'yes',show_button_1:'yes',show_icon_2:'yes'});flush();ok(settings.get('lumi_has_card')==='yes','card section revealed');ok(settings.get('lumi_has_button_1')==='yes','button section revealed');ok(settings.get('lumi_has_icon_2')==='yes','icon options revealed');
row.set({show_card:'',show_button_1:'',show_text_2:''});flush();ok(settings.get('lumi_has_card')==='','card section hidden again');ok(settings.get('lumi_has_icon_2')==='','dependent icon hidden');ok(row.get('card_title')==='Keep my title','disabled content retained');
callback(null,model);ok(!frames.size,'reopening does not bind twice');
const replacement=new ctx.Backbone.Collection([new ctx.Backbone.Model({show_text_3:'yes'})]);settings.set('slides',replacement);flush();ok(settings.get('lumi_has_text_3')==='yes','collection replacement reflected');row.set('show_card','yes');flush();ok(settings.get('lumi_has_card')==='','old collection detached');
replacement.reset([]);flush();ok(settings.get('lumi_has_text_3')==='','empty repeater clears style flags');
model.trigger('destroy');replacement.add({show_card:'yes'});ok(!frames.size,'destroy removes listeners');
const catRow1=new ctx.Backbone.Model({_id:'catA',title:'Shoes'}),catRow2=new ctx.Backbone.Model({_id:'catB',title:'Bags'});
const cats=new ctx.Backbone.Collection([catRow1,catRow2]),catSettings=new ctx.Backbone.Model({category_items:cats}),catModel=new ctx.Backbone.Model({settings:catSettings});
const openCat=hooks['panel/open_editor/widget/lumi_category_carousel'];openCat(null,catModel);flush();
ok(catRow1.get('_lumi_order')===1&&catRow2.get('_lumi_order')===2,'initial row numbers');
cats.models.reverse();cats.trigger('sort');flush();ok(catRow2.get('_lumi_order')===1&&catRow1.get('_lumi_order')===2,'reorder updates numbers');
const duplicate=new ctx.Backbone.Model({...catRow2.toJSON(),_id:'catC'});cats.add(duplicate);flush();ok(duplicate.get('_lumi_order')===3,'duplicate numbered');
cats.remove(catRow2);flush();ok(catRow1.get('_lumi_order')===1&&duplicate.get('_lumi_order')===2,'remove renumbers');
ok(catRow1.get('_id')==='catA'&&catRow1.get('title')==='Shoes','row identity and title retained');
openCat(null,catModel);flush();ok(!frames.size,'category reopening idempotent');
catModel.trigger('destroy');cats.add({title:'New'});ok(!frames.size,'category listeners disposed');
if(process.argv[3]){
 const template=JSON.parse(fs.readFileSync(process.argv[3],'utf8'));
 ctx.titleTemplate=template;
 vm.runInContext('titleOutput=_.template(titleTemplate,{evaluate:/<#([\\s\\S]+?)#>/g,interpolate:/{{{([\\s\\S]+?)}}}/g,escape:/{{([^}]+?)}}(?!})/g})({title:"<strong>Shoes</strong> & Bags",category:"",_lumi_order:2});',ctx);
 ok(ctx.titleOutput.includes('Shoes &amp; Bags')&&!ctx.titleOutput.includes('<strong>'),'native title template safely strips HTML');
 ok(ctx.titleOutput.includes('>2</span>'),'native title template shows row index');
}
console.log(JSON.stringify({passed_assertions:n,environment:'WordPress Backbone models in Node VM; no visual Elementor editor'},null,2));
