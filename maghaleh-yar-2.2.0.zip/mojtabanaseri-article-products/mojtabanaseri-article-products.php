<?php
/**
 * Plugin Name: مقاله‌یار
 * Description: باکس محصولات، دعوت به اقدام و جدول با پنل فارسی، پیش‌نمایش، بکاپ JSON، شورت‌کد و ویجت المنتور.
 * Version: 2.2.0
 * Author: mojtabanaseri
 * Author URI: https://t.me/Mojtaba_nsr44
 * Requires at least: 6.3
 * Requires PHP: 7.4
 * Text Domain: mojtabanaseri-article-products
 * License: GPL-2.0-or-later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Domain Path: /languages
 */
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
define( 'MNPS_VERSION', '2.2.0' );
define( 'MNPS_FILE', __FILE__ );
define( 'MNPS_URL', plugin_dir_url( __FILE__ ) );
// Namespace autoloading with adapters for the existing class filenames.
spl_autoload_register(function($class) {
    $prefix='Mojtabanaseri\\ArticleProducts\\';
    if(strpos($class,$prefix)!==0)return;
    $name=substr($class,strlen($prefix));
    foreach(explode('\\',$name)as$segment){if(!preg_match('/^[A-Za-z][A-Za-z0-9_]*$/',$segment))return;}
    $relative=$name==='Modules'?null:\Mojtabanaseri\ArticleProducts\Modules::class_file($name);
    if(false===$relative)return;
    if(null===$relative){$psr4=__DIR__.'/includes/'.str_replace('\\','/',$name).'.php';if(is_file($psr4)){require_once $psr4;return;}}
    if(null===$relative&&strpos($name,'\\')!==false)return;
    if(null===$relative)$relative='includes/class-'.strtolower(preg_replace('/(?<!^)[A-Z]/','-$0',$name)).'.php';
    $path=__DIR__.'/'.$relative;
    if(is_file($path))require_once $path;
});
\Mojtabanaseri\ArticleProducts\Modules::boot();
\Mojtabanaseri\ArticleProducts\Plugin::boot();
register_activation_hook(__FILE__, array('Mojtabanaseri\\ArticleProducts\\Store','install'));
register_deactivation_hook(__FILE__, array('Mojtabanaseri\\ArticleProducts\\Connection','deactivate'));
