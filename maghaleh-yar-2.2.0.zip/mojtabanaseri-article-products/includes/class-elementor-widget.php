<?php
namespace Mojtabanaseri\ArticleProducts;
if ( ! defined('ABSPATH') ) {
    exit;
}
trait Elementor_Design {
    protected function sources($kind) {
        $options=array(''=>'products'===$kind?__('از مقاله جاری / ACF خوانده شود', 'mojtabanaseri-article-products'):__('ساخت مستقیم در المنتور', 'mojtabanaseri-article-products'));
        $ids=get_posts(array('post_type'=>array('post','mnps_group'),'post_status'=>array('publish','draft','private'),'meta_key'=>Plugin::META,'numberposts'=>100,'fields'=>'ids','orderby'=>'modified','order'=>'DESC'));
        foreach($ids as$id){
            if(!current_user_can('edit_post',$id))continue;
            foreach(Plugin::boot()->groups($id)as$group){
                if($kind!==($group['type']??'products'))continue;
                $options[$id.':'.$group['key']]=get_the_title($id).' — '.($group['title']?:__('بدون عنوان', 'mojtabanaseri-article-products'));
            }
        }
        return $options;
    }
    protected function design_controls($kind) {
        $this->start_controls_section('mnps_style',array('label'=>__('ظاهر باکس', 'mojtabanaseri-article-products'),'tab'=>\Elementor\Controls_Manager::TAB_STYLE));
        foreach(array('accent'=>__('رنگ اصلی و دکمه', 'mojtabanaseri-article-products'),'background'=>__('پس‌زمینه باکس', 'mojtabanaseri-article-products'),'card_background'=>__('پس‌زمینه کارت', 'mojtabanaseri-article-products'),'title_color'=>__('رنگ عنوان', 'mojtabanaseri-article-products'),'text_color'=>__('رنگ توضیح', 'mojtabanaseri-article-products'),'button_text'=>__('رنگ متن دکمه', 'mojtabanaseri-article-products'),'border_color'=>__('رنگ حاشیه', 'mojtabanaseri-article-products'),'line_color'=>__('رنگ خط کنار عنوان', 'mojtabanaseri-article-products'))as$key=>$label){
            $this->add_control('my_'.$key,array('label'=>$label,'type'=>\Elementor\Controls_Manager::COLOR,'alpha'=>false,'default'=>''));
        }
        foreach(array('radius'=>array(__('گردی باکس', 'mojtabanaseri-article-products'),0,48),'card_radius'=>array(__('گردی کارت', 'mojtabanaseri-article-products'),0,40),'button_radius'=>array(__('گردی دکمه', 'mojtabanaseri-article-products'),0,40),'padding'=>array(__('فاصله داخلی', 'mojtabanaseri-article-products'),8,64),'gap'=>array(__('فاصله کارت‌ها', 'mojtabanaseri-article-products'),8,40),'title_size'=>array(__('اندازه عنوان', 'mojtabanaseri-article-products'),16,42),'text_size'=>array(__('اندازه توضیح', 'mojtabanaseri-article-products'),11,24),'button_size'=>array(__('اندازه متن دکمه', 'mojtabanaseri-article-products'),11,22))as$key=>$data){
            $this->add_control('my_'.$key,array('label'=>$data[0].__(' (پیکسل)', 'mojtabanaseri-article-products'),'type'=>\Elementor\Controls_Manager::NUMBER,'min'=>$data[1],'max'=>$data[2],'step'=>1,'default'=>''));
        }
        $this->add_control('my_shadow',array('label'=>__('سایه', 'mojtabanaseri-article-products'),'type'=>\Elementor\Controls_Manager::SELECT,'options'=>array(''=>__('از تنظیمات باکس', 'mojtabanaseri-article-products'),'none'=>__('بدون سایه', 'mojtabanaseri-article-products'),'soft'=>__('ملایم و حرفه‌ای', 'mojtabanaseri-article-products'),'strong'=>__('برجسته', 'mojtabanaseri-article-products')),'default'=>''));
        $this->add_control('save_design',array('label'=>__('استفاده دوباره از همین طراحی', 'mojtabanaseri-article-products'),'type'=>\Elementor\Controls_Manager::BUTTON,'button_type'=>'success','text'=>__('ذخیره طراحی و دریافت شورت‌کد', 'mojtabanaseri-article-products'),'event'=>'mnps:save_design','description'=>__('یک باکس مستقل از محتوا و استایل این ویجت ذخیره می‌شود. فقط تنظیمات داخل ویجت مقاله‌یار منتقل می‌شوند؛ تب پیشرفته المنتور و CSS سفارشی منتقل نمی‌شوند.', 'mojtabanaseri-article-products')));
        $this->end_controls_section();
    }
    public function design_values($settings) {
        $raw=array();
        foreach(Appearance::defaults()as$key=>$value){
            if(isset($settings['my_'.$key])&&''!==$settings['my_'.$key]){
                $raw[$key]=$settings['my_'.$key];
            }
        }
        return Appearance::clean($raw);
    }
    protected function content_controls($kind){
        foreach(array('hide_title'=>__('مخفی‌کردن عنوان', 'mojtabanaseri-article-products'),'title_line'=>__('نمایش خط کنار عنوان', 'mojtabanaseri-article-products'))+('products'===$kind?array('show_price'=>__('نمایش قیمت', 'mojtabanaseri-article-products'),'show_badge'=>__('نمایش نشان', 'mojtabanaseri-article-products'),'show_button'=>__('نمایش دکمه', 'mojtabanaseri-article-products')):array())as$k=>$label){
            $this->add_control('box_'.$k,array('label'=>$label,'type'=>\Elementor\Controls_Manager::SELECT,'options'=>array(''=>__('از تنظیمات باکس', 'mojtabanaseri-article-products'),'yes'=>__('فعال', 'mojtabanaseri-article-products'),'no'=>__('خاموش', 'mojtabanaseri-article-products')),'default'=>''));
        }
        $this->add_control('box_title_tag',array('label'=>__('تگ عنوان', 'mojtabanaseri-article-products'),'type'=>\Elementor\Controls_Manager::SELECT,'options'=>array(''=>__('از باکس؛ پیش‌فرض پاراگراف', 'mojtabanaseri-article-products'),'p'=>__('پاراگراف (p)', 'mojtabanaseri-article-products'),'div'=>__('بخش (div)', 'mojtabanaseri-article-products'),'span'=>__('متن (span)', 'mojtabanaseri-article-products'),'h1'=>__('تیتر ۱ (h1)', 'mojtabanaseri-article-products'),'h2'=>__('تیتر ۲ (h2)', 'mojtabanaseri-article-products'),'h3'=>__('تیتر ۳ (h3)', 'mojtabanaseri-article-products'),'h4'=>__('تیتر ۴ (h4)', 'mojtabanaseri-article-products'),'h5'=>__('تیتر ۵ (h5)', 'mojtabanaseri-article-products'),'h6'=>__('تیتر ۶ (h6)', 'mojtabanaseri-article-products')),'default'=>''));
        if('products'===$kind){
            $this->add_control('box_button_label',array('label'=>__('متن دلخواه دکمه', 'mojtabanaseri-article-products'),'type'=>\Elementor\Controls_Manager::TEXT,'default'=>''));
            foreach(array('button_icon'=>__('آیکن دکمه', 'mojtabanaseri-article-products'),'left_icon'=>__('آیکن چپ', 'mojtabanaseri-article-products'),'right_icon'=>__('آیکن راست', 'mojtabanaseri-article-products'))as$k=>$label){
                $this->add_control('box_'.$k,array('label'=>$label.__(' از رسانه', 'mojtabanaseri-article-products'),'type'=>\Elementor\Controls_Manager::MEDIA));
            }
        }
    }
    public function get_style_depends(){
        return array('mnps-front');
    }
    public function get_script_depends(){
        return array('mnps-front');
    }
    public function get_categories(){
        return array('general');
    }
    protected function is_dynamic_content(): bool{
        return true;
    }
}
class Elementor_Widget extends \Elementor\Widget_Base {
    use Elementor_Design;
    public function get_name(){
        return 'mnps-products';
    }
    public function get_title(){
        return __('مقاله‌یار — محصولات', 'mojtabanaseri-article-products');
    }
    public function get_icon(){
        return 'eicon-products';
    }
    public function get_keywords(){
        return array('product','article',__('محصول', 'mojtabanaseri-article-products'),__('مقاله', 'mojtabanaseri-article-products'),__('مقاله‌یار', 'mojtabanaseri-article-products'));
    }
    protected function register_controls(){
        $this->start_controls_section('content',array('label'=>__('محتوای باکس محصولات', 'mojtabanaseri-article-products')));
        $this->add_control('source',array('label'=>__('باکس ذخیره‌شده', 'mojtabanaseri-article-products'),'type'=>\Elementor\Controls_Manager::SELECT2,'options'=>$this->sources('products'),'default'=>'','description'=>__('ابتدا باکس را ذخیره کن، سپس المنتور را تازه کن.', 'mojtabanaseri-article-products')));
        $this->add_control('override_title',array('label'=>__('عنوان متفاوت در این محل', 'mojtabanaseri-article-products'),'type'=>\Elementor\Controls_Manager::SWITCHER,'return_value'=>'yes'));
        $this->add_control('title',array('label'=>__('عنوان دلخواه', 'mojtabanaseri-article-products'),'type'=>\Elementor\Controls_Manager::TEXT,'condition'=>array('override_title'=>'yes')));
        $this->content_controls('products');
        $this->end_controls_section();
        $this->design_controls('products');
    }
    protected function render(){
        $settings=$this->get_settings_for_display();
        $atts=array('style'=>$this->design_values($settings),'controls'=>Appearance::widget_controls($settings));
        if(!empty($settings['source'])){
            $parts=explode(':',$settings['source'],2);
            $atts['post']=absint($parts[0]);
            $atts['group']=$parts[1]??'';
        }
        else{
            $atts['post']=get_the_ID() ?: get_queried_object_id();
        }
        if(isset($settings['override_title'])&&'yes'===$settings['override_title']){
            $atts['title']=$settings['title'];
        }
        echo Plugin::boot()->render($atts);
    }
}
class Elementor_CTA_Widget extends \Elementor\Widget_Base {
    use Elementor_Design;
    public function get_name(){
        return 'mnps-cta';
    }
    public function get_title(){
        return __('مقاله‌یار — دعوت به اقدام', 'mojtabanaseri-article-products');
    }
    public function get_icon(){
        return 'eicon-call-to-action';
    }
    public function get_keywords(){
        return array('cta','button',__('دعوت', 'mojtabanaseri-article-products'),__('دکمه', 'mojtabanaseri-article-products'),__('مقاله‌یار', 'mojtabanaseri-article-products'));
    }
    protected function register_controls(){
        $this->start_controls_section('content',array('label'=>__('محتوای دعوت به اقدام', 'mojtabanaseri-article-products')));
        $this->add_control('source',array('label'=>__('روش ساخت', 'mojtabanaseri-article-products'),'type'=>\Elementor\Controls_Manager::SELECT2,'options'=>$this->sources('cta'),'default'=>'','description'=>__('باکس ذخیره‌شده را انتخاب کن یا مستقیم در المنتور بساز.', 'mojtabanaseri-article-products')));
        $condition=array('source'=>'');
        $this->add_control('title',array('label'=>__('عنوان', 'mojtabanaseri-article-products'),'type'=>\Elementor\Controls_Manager::TEXT,'default'=>__('قدم بعدی را بردار', 'mojtabanaseri-article-products'),'condition'=>$condition));
        $this->add_control('description',array('label'=>__('توضیح کوتاه', 'mojtabanaseri-article-products'),'type'=>\Elementor\Controls_Manager::TEXTAREA,'default'=>__('یک پیشنهاد کاربردی برای مخاطب مقاله‌ات.', 'mojtabanaseri-article-products'),'condition'=>$condition));
        $this->add_control('button_label',array('label'=>__('متن دکمه', 'mojtabanaseri-article-products'),'type'=>\Elementor\Controls_Manager::TEXT,'default'=>__('بیشتر بدانید', 'mojtabanaseri-article-products'),'condition'=>$condition));
        $this->add_control('link',array('label'=>__('لینک مقصد', 'mojtabanaseri-article-products'),'type'=>\Elementor\Controls_Manager::URL,'condition'=>$condition));
        $this->add_control('image',array('label'=>__('تصویر از رسانه', 'mojtabanaseri-article-products'),'type'=>\Elementor\Controls_Manager::MEDIA,'condition'=>$condition));
        $this->add_control('icon',array('label'=>__('آیکن آماده', 'mojtabanaseri-article-products'),'type'=>\Elementor\Controls_Manager::SELECT,'options'=>array('arrow'=>__('پیکان', 'mojtabanaseri-article-products'),'bag'=>__('خرید', 'mojtabanaseri-article-products'),'phone'=>__('تماس', 'mojtabanaseri-article-products'),'check'=>__('تأیید', 'mojtabanaseri-article-products'),'none'=>__('بدون آیکن', 'mojtabanaseri-article-products')),'default'=>'arrow','condition'=>$condition));
        $this->add_control('icon_media',array('label'=>__('آیکن تصویری از رسانه — اختیاری', 'mojtabanaseri-article-products'),'type'=>\Elementor\Controls_Manager::MEDIA,'description'=>__('اگر انتخاب شود، جای آیکن آماده نمایش داده می‌شود.', 'mojtabanaseri-article-products'),'condition'=>$condition));
        $this->add_control('layout',array('label'=>__('چیدمان', 'mojtabanaseri-article-products'),'type'=>\Elementor\Controls_Manager::SELECT,'options'=>array('horizontal'=>__('تصویر کنار متن', 'mojtabanaseri-article-products'),'vertical'=>__('تصویر بالای متن', 'mojtabanaseri-article-products')),'default'=>'horizontal','condition'=>$condition));
        $this->content_controls('cta');
        $this->end_controls_section();
        $this->design_controls('cta');
    }
    protected function render(){
        $settings=$this->get_settings_for_display();
        $settings['design']=$this->design_values($settings);
        echo Plugin::boot()->elementor_cta($settings);
    }
}
