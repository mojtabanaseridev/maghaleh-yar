/* Native Elementor models/hooks only; no private panel selectors or custom UI.
 * Synchronize aggregate style conditions with row switches. Repeater inner
 * conditions remain local, as required by Elementor's documented level rule. */
(function () {
  'use strict';
  const bound = new WeakMap();
  function value(row, key) { return row && typeof row.get === 'function' ? row.get(key) : row && row[key]; }
  function rows(settings) {
    const list = settings.get('slides');
    return Array.isArray(list) ? list : list && list.models ? list.models : [];
  }
  function register() {
    if (!window.elementor || !elementor.hooks) return;
    elementor.hooks.addAction('panel/open_editor/widget/lumi_category_carousel', function (panel, model) {
      const settings = model.get('settings');
      if (!settings || bound.has(settings)) return;
      let collection, queued = 0, disposed = false;
      function sync() {
        queued = 0;
        if (disposed) return;
        const list = settings.get('category_items');
        const items = Array.isArray(list) ? list : list && list.models ? list.models : [];
        items.forEach((row, index) => {
          if (value(row, '_lumi_order') === index + 1) return;
          if (row.set) row.set('_lumi_order', index + 1);
          else row._lumi_order = index + 1;
        });
      }
      function schedule() { if (!queued && !disposed) queued = requestAnimationFrame(sync); }
      function watch() {
        if (collection && collection.off) collection.off('change add remove reset sort update', schedule);
        collection = settings.get('category_items');
        if (collection && collection.on) collection.on('change add remove reset sort update', schedule);
        sync();
      }
      function dispose() {
        disposed = true; cancelAnimationFrame(queued);
        if (collection && collection.off) collection.off('change add remove reset sort update', schedule);
        settings.off('change:category_items', watch); model.off('destroy', dispose); bound.delete(settings);
      }
      bound.set(settings, dispose);
      settings.on('change:category_items', watch); model.on('destroy', dispose); watch();
    });
    elementor.hooks.addAction('panel/open_editor/widget/lumi_slider', function (panel, model) {
      const settings = model.get('settings');
      if (!settings || bound.has(settings)) return;
      let collection, queued = 0, disposed = false, migrating = false;
      function sync() {
        queued = 0;
        if (disposed || migrating) return;
        const list = rows(settings), flags = {lumi_has_card: ''};
        for (let n = 1; n <= 4; n++) { flags['lumi_has_text_' + n] = ''; flags['lumi_has_icon_' + n] = ''; }
        for (let n = 1; n <= 2; n++) flags['lumi_has_button_' + n] = '';
        list.forEach(row => {
          for (let n = 1; n <= 4; n++) if (value(row, 'show_text_' + n) === 'yes') {
            flags['lumi_has_text_' + n] = 'yes';
            if (value(row, 'show_icon_' + n) === 'yes') flags['lumi_has_icon_' + n] = 'yes';
          }
          for (let n = 1; n <= 2; n++) if (value(row, 'show_button_' + n) === 'yes') flags['lumi_has_button_' + n] = 'yes';
          if (value(row, 'show_card') === 'yes') flags.lumi_has_card = 'yes';
        });
        Object.keys(flags).forEach(key => { if (settings.get(key) !== flags[key]) settings.set(key, flags[key]); });
      }
      function schedule() { if (!queued && !disposed) queued = requestAnimationFrame(sync); }
      function watch() {
        if (collection && collection.off) collection.off('change add remove reset', schedule);
        collection = settings.get('slides');
        if (collection && collection.on) collection.on('change add remove reset', schedule);
        schedule();
      }
      function dispose() {
        disposed = true; cancelAnimationFrame(queued);
        if (collection && collection.off) collection.off('change add remove reset', schedule);
        settings.off('change:slides', watch); model.off('destroy', dispose);
        bound.delete(settings);
      }
      bound.set(settings, dispose);
      settings.on('change:slides', watch); model.on('destroy', dispose);
      // Older documents receive explicit new switches once; old field values stay intact.
      const savedMap = settings.get('lumi_legacy_map');
      if (savedMap) {
        migrating = true;
        try {
          const list = rows(settings);
          JSON.parse(savedMap).forEach(entry => {
            const row = (entry.id && list.find(r => value(r, '_id') === entry.id)) || list[entry.index];
            if (row && row.set) row.set(entry.values);
            else if (row) Object.assign(row, entry.values);
          });
          settings.set('lumi_legacy_map', '');
        } catch (error) { /* Invalid migration metadata cannot break the editor. */ }
        migrating = false;
      }
      watch(); sync();
    });
  }
  if (window.elementor && elementor.hooks) register();
  else window.addEventListener('load', register, {once: true});
})();
