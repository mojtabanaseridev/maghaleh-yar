<?php
namespace Mojtabanaseri\ArticleProducts;
if(!defined('ABSPATH')){
    exit;
}
/** Product rules and reversible, permission-checked administration. */
class Features {
    const PREVIOUS='_mnps_previous_groups';
    public static function settings(){
        return array_merge(array('per_page'=>12,'hide_stock'=>false,'empty'=>'hide','empty_text'=>__('فعلاً محصولی برای نمایش وجود ندارد.', 'mojtabanaseri-article-products'),'auto_count'=>4,'auto_order'=>'sales','auto_stock'=>true,'font'=>'plugin'),(array)get_option('mnps_behavior',array()));
    }
    public static function new_font(){return get_option('mnps_new_font','theme')==='plugin'?'plugin':'theme';}
    public static function clean_settings($raw){
        $raw=is_array($raw)?$raw:array();
        return array('per_page'=>in_array(absint($raw['per_page']??12),array(12,24,48),true)?absint($raw['per_page']??12):12,'hide_stock'=>!empty($raw['hide_stock']),'empty'=>($raw['empty']??'hide')==='text'?'text':'hide','empty_text'=>sanitize_text_field($raw['empty_text']??''),'auto_count'=>max(1,min(12,absint($raw['auto_count']??4))),'auto_order'=>in_array($raw['auto_order']??'',array('sales','date','rating','price'),true)?$raw['auto_order']:'sales','auto_stock'=>!empty($raw['auto_stock']),'font'=>($raw['font']??'plugin')==='theme'?'theme':'plugin');
    }
    public static function clean_auto($raw){
        $raw=is_array($raw)?$raw:array();
        $ids=function($v){
            return array_slice(array_values(array_unique(array_filter(array_map('absint',is_array($v)?$v:array())))),0,100);
        }
        ;
        $excluded=$ids($raw['excluded']??array());
        return array('mode'=>($raw['mode']??'manual')==='auto'?'auto':'manual','category'=>absint($raw['category']??0),'count'=>max(1,min(12,absint($raw['count']??4))),'order'=>in_array($raw['order']??'',array('sales','date','rating','price'),true)?$raw['order']:'sales','stock'=>!isset($raw['stock'])||!empty($raw['stock']),'pinned'=>array_slice(array_values(array_diff($ids($raw['pinned']??array()),$excluded)),0,12),'excluded'=>$excluded);
    }
    public static function effective($group){
        $auto=self::clean_auto($group['auto']??array());
        if($auto['mode']!=='auto'||($group['type']??'products')!=='products'){
            return $group['items']??array();
        }
        if(!function_exists('wc_get_products')){
            return array();
        }
        $ids=array();
        foreach($auto['pinned']as$id){
            $p=wc_get_product($id);
            if($p&&$p->get_status()==='publish'&&$p->is_visible()&&(!$auto['stock']||$p->is_in_stock())){
                $ids[]=$id;
            }
        }
        if(count($ids)<$auto['count']&&$auto['category']){
            $term=get_term($auto['category'],'product_cat');
            if($term&&!is_wp_error($term)){
                $key='mnps_auto_'.md5(wp_json_encode($auto).':'.get_option('mnps_catalog_version','0'));
                $found=get_transient($key);
                if(false===$found){
                    $args=array('status'=>'publish','visibility'=>'catalog','limit'=>12,'return'=>'ids','category'=>array($term->slug),'exclude'=>array_merge($auto['excluded'],$auto['pinned']),'orderby'=>'date','mnps_order'=>$auto['order'],'order'=>$auto['order']==='price'?'ASC':'DESC');
                    if($auto['stock']){
                        $args['stock_status']='instock';
                    }
                    $found=wc_get_products($args);
                    set_transient($key,$found,300);
                }
                foreach($found as$id){
                    $p=wc_get_product($id);
                    if($p&&$p->is_visible()&&$p->get_status()==='publish'&&(!$auto['stock']||$p->is_in_stock())){
                        $ids[]=(int)$id;
                    }
                }
            }
        }
        $existing=array();
        foreach($group['items']??array()as$item){
            $existing[$item['id']]=$item;
        }
        foreach($group['product_overrides']??array()as$item){
            $existing[$item['id']]=$item;
        }
        return array_map(function($id)use($existing){
            return $existing[$id]??array('id'=>$id,'description'=>'','badge'=>'','hide_description'=>false);
        }
        ,array_slice(array_values(array_unique($ids)),0,$auto['count']));
    }
    public static function product_rows($items) { return FeatureAdmin::product_rows($items); }
    public static function health($g){
        if(($g['type']??'products')==='cta'){
            $notes=array();if(empty($g['hide_title'])&&empty($g['title']))$notes[]=array('id'=>0,'name'=>'عنوان باکس','reason'=>'عنوان خالی است');return $notes;
        }
        $auto=self::clean_auto($g['auto']??array());
        $items=$auto['mode']==='auto'?array_map(function($id){
            return array('id'=>$id);
        }
        ,$auto['pinned']):($g['items']??array());
        if(($g['type']??'products')==='table')$items=($g['table']['mode']??'manual')==='products'?array_map(function($r){return array('id'=>$r['product']);},$g['table']['rows']??array()):array();
        $out=array();
        foreach($items as$item){
            $p=function_exists('wc_get_product')?wc_get_product($item['id']):false;
            $reason=!$p&&empty($item['id'])?__('محصول انتخاب نشده', 'mojtabanaseri-article-products'):(!$p?__('حذف‌شده', 'mojtabanaseri-article-products'):($p->get_status()!=='publish'?__('منتشرنشده', 'mojtabanaseri-article-products'):(!$p->is_visible()?__('پنهان از فروشگاه', 'mojtabanaseri-article-products'):(!$p->is_in_stock()?__('ناموجود', 'mojtabanaseri-article-products'):''))));
            if($reason){
                $out[]=array('id'=>absint($item['id']),'name'=>$p?$p->get_name():__('محصول #', 'mojtabanaseri-article-products').absint($item['id']),'reason'=>$reason);
            }
        }
        return $out;
    }
    public static function snapshot($id,$groups,$current=null) { return FeatureAdmin::snapshot($id,$groups,$current); }
    public static function write($id,$groups,$before) { return FeatureAdmin::write($id,$groups,$before); }
    
    
    public static function health_api() { return FeatureAdmin::health_api(); }
    public static function candidates_api() { return FeatureAdmin::candidates_api(); }
    public static function auto_api() { return FeatureAdmin::auto_api(); }
    public static function restore_api() { return FeatureAdmin::restore_api(); }
    public static function replace_api() { return FeatureAdmin::replace_api(); }
    public static function order_query($args,$vars){
        $mode=$vars['mnps_order']??'';
        $keys=array('sales'=>'total_sales','rating'=>'_wc_average_rating','price'=>'_price');
        if(isset($keys[$mode])){
            $args['meta_key']=$keys[$mode];
            $args['orderby']=array('meta_value_num'=>$mode==='price'?'ASC':'DESC','ID'=>'DESC');
        }
        return $args;
    }
    public static function health_batch($id,$cursor=0){
        global $wpdb;
        if(get_option('mnps_schema')!=='3'){
            return;
        }
        $id=absint($id);
        $cursor=absint($cursor);
        $sources=$wpdb->get_col($wpdb->prepare("SELECT DISTINCT post_id FROM {$wpdb->postmeta} WHERE meta_key=%s AND meta_value=%s AND post_id>%d ORDER BY post_id LIMIT 30",Plugin::REF,(string)$id,$cursor));
        foreach($sources as$source){
            Store::sync($source,Plugin::boot()->groups($source));
        }
        if(count($sources)===30){
            $args=array($id,(int)end($sources));
            if(!wp_next_scheduled('mnps_health_batch',$args)){
                wp_schedule_single_event(time()+5,'mnps_health_batch',$args);
            }
        }
    }
    public static function product_changed($id){
        if(get_post_type($id)==='product_variation'){
            $id=wp_get_post_parent_id($id);
        }
        update_option('mnps_catalog_version',wp_generate_uuid4(),false);
        self::health_batch($id);
    }
}
