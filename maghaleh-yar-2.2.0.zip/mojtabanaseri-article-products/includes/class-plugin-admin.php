<?php
namespace Mojtabanaseri\ArticleProducts;
if (!defined('ABSPATH')) { exit; }
/** Admin implementation behind the existing Plugin method names. */
final class PluginAdmin {
    const META=Plugin::META;
    const REF=Plugin::REF;
    const LIMIT=Plugin::LIMIT;
    private $plugin;
    public function __construct($plugin) { $this->plugin=$plugin; }
    public function __call($name,$args) { return call_user_func_array(array($this->plugin,$name),$args); }

    public function boxes() {
        foreach ( array( 'post' ) as $type ) {
            add_meta_box( 'mnps-editor', __('مقاله‌یار — طراحی باکس', 'mojtabanaseri-article-products') , array( $this, 'box' ), $type, 'normal', 'high' );
        }
    }
    public function box( $post ) {
        wp_nonce_field( 'mnps_save_' . $post->ID, 'mnps_save_nonce' );
        Admin::manager($post->ID,false);
    }
    public function save( $id, $post ) {
        if ( ! in_array( $post->post_type, array( 'post', 'mnps_group' ), true ) || wp_is_post_revision( $id ) || wp_is_post_autosave( $id ) || ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) ) {
            return;
        }
        if ( ! isset( $_POST['mnps_save_nonce'], $_POST['mnps_data'] ) || ! is_string( $_POST['mnps_save_nonce'] ) || ! is_string( $_POST['mnps_data'] ) || ! current_user_can( 'edit_post', $id ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['mnps_save_nonce'] ) ), 'mnps_save_' . $id ) ) {
            return;
        }
        $raw = wp_unslash( $_POST['mnps_data'] );
        if ( strlen( $raw ) > 1000000 ) {
            set_transient( 'mnps_error_' . get_current_user_id(), __('حجم داده بخش‌های محصولات بیش از حد مجاز است.', 'mojtabanaseri-article-products'), 60 );
            return;
        }
        $decoded = json_decode( $raw, true );
        if ( ! is_array( $decoded ) || ( $decoded && array_keys( $decoded ) !== range( 0, count( $decoded ) - 1 ) ) ) {
            set_transient( 'mnps_error_' . get_current_user_id(), __('داده بخش‌های محصولات معتبر نیست؛ تغییرات ذخیره نشد.', 'mojtabanaseri-article-products'), 60 );
            return;
        }
        $groups = $this->normalize( $this->protect_code($decoded,$id) );
        Features::snapshot($id,$groups);
        update_post_meta( $id, self::META, wp_slash($groups) );
        $this->index( $id, $groups );
        $this->purge_post( $id );
        if ( 'mnps_group' === $post->post_type ) {
            $this->purge_all();
        }
    }
    public function admin_assets( $hook ) {
        $screen = get_current_screen();
        $app = isset($_GET['page']) && is_string($_GET['page']) && 0 === strpos($_GET['page'],'mnps-');
        $editor = $screen && in_array($screen->post_type,array('post','mnps_group'),true) && in_array($hook,array('post.php','post-new.php'),true);
        if ( ! $app && ! $editor ) {
            return;
        }
        $this->register_assets();
        wp_enqueue_style('mnps-admin',MNPS_URL.'assets/admin.css',array('mnps-font'),MNPS_VERSION);
        if(current_user_can('upload_files')&&($editor||in_array($_GET['page']??'',array('mnps-editor','mnps-new'),true))){
            wp_enqueue_media();
        }
        $post_id = isset($_GET['post']) && is_scalar($_GET['post']) ? absint($_GET['post']) : get_the_ID();
        $page=$_GET['page']??'';
        $builder=$editor||in_array($page,array('mnps-editor','mnps-new'),true);

        if($app&&$page==='mnps-connection'){
            wp_enqueue_script('mnps-connection-ui',MNPS_URL.'assets/connection.js',array('wp-i18n'),MNPS_VERSION,true);
            wp_set_script_translations('mnps-connection-ui','mojtabanaseri-article-products',dirname(MNPS_FILE).'/languages');
            wp_localize_script('mnps-connection-ui','MNPSConnection',array('url'=>admin_url('admin-ajax.php'),'nonce'=>wp_create_nonce('mnps_admin')));
        }
        wp_enqueue_style('mnps-v2',MNPS_URL.'assets/v2.css',array('mnps-admin'),MNPS_VERSION);
        wp_enqueue_script('mnps-v2',MNPS_URL.'assets/v2.js',array('wp-i18n'),MNPS_VERSION,true);
        wp_localize_script('mnps-v2','MNPSV2Config',array('timezone'=>wp_timezone_string(),'defaultPaint'=>Suite::paint(get_option('mnps_paint',array())),'modules'=>Modules::state(),'counts'=>Admin::is_page()&&($_GET['page']??'')==='mnps-home'?Workflow::counts():array()));
        if($app&&$page==='mnps-modules'){
            wp_enqueue_style('mnps-modules',MNPS_URL.'assets/modules.css',array('mnps-v2'),MNPS_VERSION);
            wp_enqueue_script('mnps-modules',MNPS_URL.'assets/modules.js',array('mnps-v2'),MNPS_VERSION,true);
            wp_localize_script('mnps-modules','MNPSModules',array('url'=>admin_url('admin-ajax.php'),'nonce'=>wp_create_nonce('mnps_modules')));
        }
        if($app&&in_array($page,array('mnps-help','mnps-connection','mnps-modules'),true)){
            return;
        }
        $config = array('modules'=>Modules::state(),'newFont'=>Features::new_font(),'behavior'=>Features::settings(),'url'=>admin_url('admin-ajax.php'),'nonce'=>wp_create_nonce('mnps_admin'),'post'=>absint($post_id),'defaults'=>Appearance::current(),'limits'=>Appearance::limits(),'font'=>MNPS_URL.'assets/font.css?ver='.MNPS_VERSION,'themeCss'=>MNPS_URL.'assets/theme-layout.css?ver='.MNPS_VERSION,'css'=>MNPS_URL.'assets/front.css?ver='.MNPS_VERSION,'canUpload'=>current_user_can('upload_files'),'canCode'=>current_user_can('manage_options')&&current_user_can('unfiltered_html'),'js'=>MNPS_URL.'assets/front.js?ver='.MNPS_VERSION,'templates'=>($builder||$page==='mnps-templates')?Admin::templates():array(),'categories'=>$builder?Admin::categories():array(),'archiveReady'=>(bool)get_option('mnps_archive_ready',true),'scan'=>get_option('mnps_scan',array('phase'=>'done')));
        wp_enqueue_script('mnps-studio',MNPS_URL.'assets/studio.js',array('wp-i18n'),MNPS_VERSION,true);
        wp_localize_script('mnps-studio','MNPS',$config);
        if($builder){
            $v2_deps=array('mnps-v2','mnps-studio');
            if(Modules::enabled('schedule')){
                wp_enqueue_style('mnps-schedule',MNPS_URL.'modules/schedule/schedule.css',array('mnps-v2'),MNPS_VERSION);
                wp_enqueue_script('mnps-schedule',MNPS_URL.'modules/schedule/schedule.js',array('mnps-studio'),MNPS_VERSION,true);
                $v2_deps[]='mnps-schedule';
            }
            if(Modules::enabled('transfer')){
                wp_enqueue_script('mnps-table-import',MNPS_URL.'modules/transfer/import.js',array('mnps-studio'),MNPS_VERSION,true);
                $v2_deps[]='mnps-table-import';
            }
            wp_enqueue_script('mnps-v2-editor' ,MNPS_URL.'assets/v2-editor.js',$v2_deps,MNPS_VERSION,true);
            wp_enqueue_script('mnps-admin',MNPS_URL.'assets/admin.js',array('wp-i18n','mnps-studio','mnps-v2-editor'),MNPS_VERSION,true);
        }
        if(!$builder&&in_array($page,array('mnps-home','mnps-templates','mnps-settings'),true)){
            wp_enqueue_script('mnps-app',MNPS_URL.'assets/app.js',array('wp-i18n','mnps-studio'),MNPS_VERSION,true);
            wp_localize_script('mnps-app','MNPSApp',$config);
        }
        if($app&&in_array($page,array('mnps-home','mnps-backup'),true)&&current_user_can('manage_options')){
            wp_enqueue_script('mnps-deletion',MNPS_URL.'assets/deletion.js',array('wp-i18n','mnps-studio'),MNPS_VERSION,true);
        }
        if(Modules::enabled('transfer')&&$app&&in_array($page,array('mnps-home','mnps-backup'),true)&&current_user_can('manage_options')){
            wp_enqueue_script('mnps-transfer',MNPS_URL.'assets/transfer.js',array('wp-i18n','mnps-studio','mnps-deletion'),MNPS_VERSION,true);
        }
        if($app&&in_array($page,array('mnps-home','mnps-settings'),true)){
            wp_enqueue_script('mnps-features',MNPS_URL.'assets/features.js',array('wp-i18n','mnps-app'),MNPS_VERSION,true);
        }
        foreach(array('mnps-studio','mnps-admin','mnps-app','mnps-deletion','mnps-transfer','mnps-features','mnps-insert','mnps-block')as$handle){
            if(wp_script_is($handle,'registered')){
                wp_set_script_translations($handle,'mojtabanaseri-article-products',dirname(MNPS_FILE).'/languages');
            }
        }
        if($editor){
            wp_enqueue_script('mnps-insert',MNPS_URL.'assets/insert.js',array('wp-i18n'),MNPS_VERSION,true);
            wp_localize_script('mnps-insert','MNPSInsert',$config);
        }
    }
    public function editor_assets() {
        wp_enqueue_style('mnps-font');
        wp_enqueue_style( 'mnps-front', MNPS_URL . 'assets/front.css', array('mnps-font'), MNPS_VERSION );
        wp_enqueue_script('mnps-front');
        wp_localize_script( 'mnps-block', 'MNPSBlock', array( 'url' => admin_url( 'admin-ajax.php' ), 'nonce' => wp_create_nonce( 'mnps_admin' ) ) );
    }
    private function authorize( $post_required = false ) {
        check_ajax_referer( 'mnps_admin', 'nonce' );
        if ( ! current_user_can( 'edit_posts' ) ) {
            wp_send_json_error( array( 'message' => __('دسترسی مجاز نیست.', 'mojtabanaseri-article-products') ), 403 );
        }
        $post_id = isset( $_POST['post'] ) && is_scalar( $_POST['post'] ) ? absint( $_POST['post'] ) : 0;
        if ( $post_required && ( ! $post_id || ! current_user_can( 'edit_post', $post_id ) ) ) {
            wp_send_json_error( array( 'message' => __('اجازه ویرایش این صفحه را نداری.', 'mojtabanaseri-article-products') ), 403 );
        }
        return $post_id;
    }
    private function product_row( $id ) {
        $p = function_exists( 'wc_get_product' ) ? wc_get_product( $id ) : false;
        return $p ? array( 'id' => $p->get_id(), 'name' => $p->get_name(), 'image' => esc_url_raw( wp_get_attachment_image_url( $p->get_image_id(), 'thumbnail' ) ?: '' ), 'stock' => $p->is_in_stock() ) : null;
    }
    public function search() {
        $this->authorize();
        if(!function_exists('wc_get_products')){
            wp_send_json_error(array('message'=>__('ووکامرس فعال نیست.', 'mojtabanaseri-article-products')),400);
        }
        $term=isset($_POST['term'])&&is_string($_POST['term'])?self::clip(sanitize_text_field(wp_unslash($_POST['term'])),0,100):'';
        $page=max(1,min(1000000,absint($_POST['page_number']??1)));
        $args=array('post_type'=>'product','post_status'=>'publish','s'=>$term,'posts_per_page'=>21,'offset'=>($page-1)*20,'fields'=>'ids','no_found_rows'=>true,'orderby'=>'title','order'=>'ASC');
        if(!empty($_POST['category'])){
            $args['tax_query']=array(array('taxonomy'=>'product_cat','field'=>'term_id','terms'=>absint($_POST['category'])));
        }
        if(!empty($_POST['in_stock'])){
            $args['meta_query']=array(array('key'=>'_stock_status','value'=>'instock'));
        }
        $query=new \WP_Query($args);
        $ids=$query->posts;
        if(1===$page&&empty($_POST['category'])&&empty($_POST['in_stock'])&&preg_match('/^[0-9]+$/D',$term)&&'product'===get_post_type(absint($term))&&'publish'===get_post_status(absint($term))){
            array_unshift($ids,absint($term));
        }
        $out=array();
        foreach(array_slice(array_unique($ids),0,20)as$id){
            $row=$this->product_row($id);
            if($row){
                $out[]=$row;
            }
        }
        wp_send_json_success(array('items'=>$out,'more'=>$page<1000000&&count($query->posts)>20));
    }
    public function links() {
        $this->authorize(true);
        $term=isset($_POST['term'])&&is_string($_POST['term'])?self::clip(sanitize_text_field(wp_unslash($_POST['term'])),0,100):'';
        if(self::length($term)<2){
            wp_send_json_success(array());
        }
        $query=new \WP_Query(array('post_type'=>array('page','product'),'post_status'=>'publish','s'=>$term,'posts_per_page'=>20,'no_found_rows'=>true));
        $out=array();
        foreach($query->posts as$post){
            if(post_password_required($post)){
                continue;
            }
            if('product'===$post->post_type&&function_exists('wc_get_product')){
                $product=wc_get_product($post->ID);
                if(!$product||!$product->is_visible()){
                    continue;
                }
            }
            $out[]=array('name'=>get_the_title($post->ID),'url'=>get_permalink($post->ID));
        }
        wp_send_json_success($out);
    }
    public function catalog() {
        $this->authorize();
        $ids = get_posts( array( 'post_type' => array( 'post', 'mnps_group' ), 'post_status' => array( 'publish', 'draft', 'pending', 'private', 'future' ), 'meta_key' => self::META, 'numberposts' => 100, 'fields' => 'ids', 'orderby' => 'modified', 'order' => 'DESC' ) );
        $out = array();
        foreach ( $ids as $id ) {
            if ( ! current_user_can( 'edit_post', $id ) ) {
                continue;
            }
            foreach ( $this->groups( $id ) as $group ) {
                $out[] = array( 'post' => $id, 'group' => $group['key'], 'code'=>Store::code($id,$group['key']), 'type' => $group['type'] ?? 'products', 'label' => get_the_title( $id ) . ' — ' . ( $group['title'] ?: __('بدون عنوان', 'mojtabanaseri-article-products') ) );
            }
        }
        wp_send_json_success( $out );
    }
    public function preview() {
        $post_id = $this->authorize();
        $raw = isset( $_POST['group_data'] ) && is_string( $_POST['group_data'] ) ? wp_unslash( $_POST['group_data'] ) : '';
        if ( strlen( $raw ) > 1000000 ) {
            wp_send_json_error( array( 'message' => __('حجم پیش‌نمایش بیش از حد مجاز است.', 'mojtabanaseri-article-products') ), 400 );
        }
        $group = json_decode( $raw, true );
        $normalized = $this->normalize( $this->protect_code(array($group),$post_id) );
        if ( ! $normalized ) {
            wp_send_json_error( array( 'message' => __('داده پیش‌نمایش معتبر نیست.', 'mojtabanaseri-article-products') ), 400 );
        }
        wp_send_json_success( array( 'html' => $this->html( $normalized[0], 0, true ) ) );
    }
    public function saved_preview() {
        $id=$this->authorize(true);
        $key=isset($_POST['group'])&&is_string($_POST['group'])?sanitize_key(wp_unslash($_POST['group'])):'';
        foreach($this->groups($id)as$group){
            if($group['key']===$key){
                wp_send_json_success(array('html'=>$this->html($group,0,true)));
            }
        }
        wp_send_json_error(array('message'=>__('باکس پیدا نشد.', 'mojtabanaseri-article-products')),404);
    }
    public function elementor_editor_assets() {
        $this->register_assets();
        wp_enqueue_script('mnps-elementor-editor',MNPS_URL.'assets/elementor-editor.js',array('jquery','wp-i18n'),MNPS_VERSION,true);wp_set_script_translations('mnps-elementor-editor','mojtabanaseri-article-products',dirname(MNPS_FILE).'/languages');
        wp_localize_script('mnps-elementor-editor','MNPSElementor',array('url'=>admin_url('admin-ajax.php'),'nonce'=>wp_create_nonce('mnps_admin')));
    }
    public function export_design() {
        $document_id=$this->authorize(true);
        $raw=isset($_POST['settings'])&&is_string($_POST['settings'])?wp_unslash($_POST['settings']):'';
        if(strlen($raw)>30000){
            wp_send_json_error(array('message'=>__('حجم طراحی بیش از حد مجاز است.', 'mojtabanaseri-article-products')),400);
        }
        $settings=json_decode($raw,true);
        if(!is_array($settings)){
            wp_send_json_error(array('message'=>__('طراحی معتبر نیست.', 'mojtabanaseri-article-products')),400);
        }
        $kind=isset($_POST['kind'])&&'cta'===$_POST['kind']?'cta':'products';
        $group=array('title'=>'','type'=>$kind,'items'=>array(),'style'=>Appearance::clean($settings['design']??array()));
        if('products'===$kind){
            $parts=isset($settings['source'])&&is_string($settings['source'])?explode(':',$settings['source'],2):array();
            $source_id=!empty($parts[0])?absint($parts[0]):$document_id;
            if(!current_user_can('edit_post',$source_id)){
                wp_send_json_error(array('message'=>__('اجازه استفاده از منبع انتخاب‌شده را نداری.', 'mojtabanaseri-article-products')),403);
            }
            foreach($this->groups($source_id)as$source){
                if((!isset($parts[1])||$source['key']===$parts[1])&&'products'===($source['type']??'products')){
                    $group=array_merge($source,$group,array('title'=>$source['title'],'items'=>$source['items'],'style'=>array_merge($source['style']??array(),$group['style'])));
                    break;
                }
            }
            if(!$group['items']&&!isset($parts[1])&&Modules::enabled('acf')&&function_exists('get_field')){
                $selected=get_field('rg_related_products',$source_id);
                if(is_array($selected)){
                    foreach(array_slice($selected,0,12)as$p){
                        $group['items'][]=array('id'=>is_object($p)&&isset($p->ID)?absint($p->ID):(is_scalar($p)?absint($p):0));
                    }
                }
            }
            if(!$group['items']){
                wp_send_json_error(array('message'=>__('ابتدا یک باکس محصولات دارای محصول را انتخاب کن.', 'mojtabanaseri-article-products')),400);
            }
            if(isset($settings['override_title'])&&'yes'===$settings['override_title']){
                $group['title']=isset($settings['title'])&&is_scalar($settings['title'])?$settings['title']:'';
            }
        }
        else{
            if(!empty($settings['source'])&&is_string($settings['source'])){
                $parts=explode(':',$settings['source'],2);
                $source_id=absint($parts[0]);
                if(!current_user_can('edit_post',$source_id)){
                    wp_send_json_error(array('message'=>__('دسترسی به باکس انتخاب‌شده مجاز نیست.', 'mojtabanaseri-article-products')),403);
                }
                $found=false;
                foreach($this->groups($source_id)as$source){
                    if(isset($parts[1])&&$source['key']===$parts[1]&&'cta'===($source['type']??'')){
                        $group=array_merge($source,array('style'=>array_merge($source['style']??array(),$group['style'])));
                        $found=true;
                        break;
                    }
                }
                if(!$found){
                    wp_send_json_error(array('message'=>__('باکس دعوت به اقدام پیدا نشد.', 'mojtabanaseri-article-products')),404);
                }
            }
            else{
                $group['title']=isset($settings['title'])&&is_scalar($settings['title'])?$settings['title']:'';
                $group['cta']=array('description'=>$settings['description']??'','button_label'=>$settings['button_label']??'','url'=>$settings['link']['url']??'','new_tab'=>!empty($settings['link']['is_external']),'image'=>$settings['image']['id']??0,'icon_media'=>$settings['icon_media']['id']??0,'icon'=>$settings['icon']??'arrow','layout'=>$settings['layout']??'horizontal');
            }
        }
        $group=array_merge($group,Appearance::widget_controls($settings));
        $group['key']='g'.str_replace('-','',wp_generate_uuid4());
        $normalized=$this->normalize(array($group));
        $name=isset($_POST['name'])&&is_string($_POST['name'])?sanitize_text_field(wp_unslash($_POST['name'])):'';
        $id=wp_insert_post(array('post_type'=>'mnps_group','post_status'=>current_user_can('publish_posts')?'publish':'draft','post_title'=>$name?:($normalized[0]['title']?:__('طراحی ذخیره‌شده', 'mojtabanaseri-article-products')),'post_author'=>get_current_user_id()),true);
        if(is_wp_error($id)){
            wp_send_json_error(array('message'=>__('ذخیره طراحی انجام نشد.', 'mojtabanaseri-article-products')),500);
        }
        Features::snapshot($id,$normalized);
        update_post_meta($id,self::META,wp_slash($normalized));
        $this->index($id,$normalized);
        wp_send_json_success(array('shortcode'=>Store::code($id,$normalized[0]['key']),'edit'=>Admin::edit_url($id),'published'=>'publish'===get_post_status($id)));
    }
    public function mce_plugin( $plugins ) {
        if ( current_user_can( 'edit_posts' ) ) {
            $plugins['mnps_insert'] = MNPS_URL . 'assets/tinymce.js';
        }
        return $plugins;
    }
    public function mce_buttons( $buttons ) {
        if ( current_user_can( 'edit_posts' ) ) {
            $buttons[] = 'mnps_insert';
        }
        return $buttons;
    }
    public function notices($inside=false) {
        if(!current_user_can('edit_posts')||(Admin::is_page()&&!$inside))return;
        $messages=array();
        if(!function_exists('wc_get_product')&&Admin::is_page())$messages['woocommerce']='برای ساخت باکس محصولات، ووکامرس را فعال کنید. دعوت به اقدام و جدول دستی مستقل هستند.';
        if(function_exists('rg_related_products_carousel_shortcode'))$messages['legacy-products']='کد قدیمی محصولات هنوز در قالب فعال است. افزونه شورت‌کد را مدیریت می‌کند؛ پس از بکاپ فقط بخش قدیمی محصولات را از functions.php حذف کنید.';
        $error=get_transient('mnps_error_'.get_current_user_id());if($error){$messages['error-'.md5($error)]=$error;delete_transient('mnps_error_'.get_current_user_id());}
        foreach($messages as$key=>$message){if(get_user_meta(get_current_user_id(),'_mnps_notice_'.sanitize_key($key),true))continue;
            echo '<section class="mnps-owned-notice" data-owned-notice="'.esc_attr($key).'" role="status"><p>'.esc_html($message).'</p><div><button type="button" class="mnps-secondary" data-notice-close>بستن</button><button type="button" class="mnps-secondary" data-notice-forever>دیگر نمایش نده</button></div></section>';
        }
    }
    
    

    private static function clip( $text, $start, $length ) {
        if ( function_exists( 'mb_substr' ) ) {
            return mb_substr( $text, $start, $length, 'UTF-8' );
        }
        $chars = preg_split( '//u', $text, -1, PREG_SPLIT_NO_EMPTY );
        return is_array( $chars ) ? implode( '', array_slice( $chars, $start, $length ) ) : substr( $text, $start, $length );
    }
    private static function length( $text ) {
        if ( function_exists( 'mb_strlen' ) ) {
            return mb_strlen( $text, 'UTF-8' );
        }
        return preg_match_all( '/./us', $text );
    }
}
