<?php
namespace Mojtabanaseri\ArticleProducts;
if(!defined('ABSPATH'))exit;
final class ACFIntegration { public static function saved($id) { if(is_numeric($id)&&'post'===get_post_type($id))Plugin::boot()->purge_post(absint($id)); } }
