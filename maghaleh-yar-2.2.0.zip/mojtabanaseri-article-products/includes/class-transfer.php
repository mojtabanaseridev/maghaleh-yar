<?php
namespace Mojtabanaseri\ArticleProducts;
if (!defined('ABSPATH')) {
    exit;
}
/** On-demand JSON transfers. Never exports credentials or other plugins' data. */
class Transfer {
    const FORMAT='maghaleh-yar-backup';
    public static function boot(){Modules::transfer_hooks();}
    protected static function auth(){
        check_ajax_referer('mnps_admin','nonce');
        if(!current_user_can('manage_options')){
            wp_send_json_error(array('message'=>__('بکاپ و حذف گروهی فقط برای مدیر سایت مجاز است.', 'mojtabanaseri-article-products')),403);
        }
    }
    protected static function site(){
        $id=get_option('mnps_site_identity');
        if(!$id){
            $id=wp_generate_uuid4();
            add_option('mnps_site_identity',$id,'',false);
        }
        return array('identity'=>$id,'url'=>home_url('/'));
    }
    protected static function selected(){
        $ids=array_values(array_unique(array_filter(array_map('absint',explode(',',sanitize_text_field(wp_unslash($_POST['boxes']??'')))))));
        if(count($ids)>48){wp_send_json_error(array('message'=>__('در هر عملیات حداکثر ۴۸ باکس انتخاب کنید.','mojtabanaseri-article-products')),400);}
        return $ids;
    }
    protected static function records($ids=null){
        global $wpdb;
        $rows=$ids?$wpdb->get_results('SELECT b.id,b.source_post,b.group_key FROM '.$wpdb->prefix.'mnps_boxes b INNER JOIN '.$wpdb->posts.' p ON p.ID=b.source_post WHERE b.active=1 AND b.id IN ('.implode(',',array_map('absint',$ids)).')'):$wpdb->get_results('SELECT b.id,b.source_post,b.group_key FROM '.$wpdb->prefix.'mnps_boxes b INNER JOIN '.$wpdb->posts.' p ON p.ID=b.source_post WHERE b.active=1 ORDER BY b.id LIMIT 1001');
        if(count($rows)>1000){
            wp_send_json_error(array('message'=>__('بیش از ۱۰۰۰ باکس؛ بکاپ را در چند بخش انتخاب‌شده دریافت کنید.', 'mojtabanaseri-article-products')),400);
        }
        if($ids&&count($rows)!==count($ids)){
            wp_send_json_error(array('message'=>__('یکی از باکس‌ها حذف شده؛ صفحه را تازه کنید.', 'mojtabanaseri-article-products')),409);
        }
        $out=array();
        $sources=array();
        foreach($rows as$row){
            $id=(int)$row->source_post;
            if(!current_user_can('edit_post',$id)){
                wp_send_json_error(array('message'=>__('اجازه دسترسی به همه باکس‌ها را ندارید.', 'mojtabanaseri-article-products')),403);
            }
            if(!isset($sources[$id])){
                $sources[$id]=Plugin::boot()->groups($id);
            }
            foreach($sources[$id]as$g){
                if($g['key']===$row->group_key){
                    $out[]=array('box'=>(int)$row->id,'source'=>$id,'source_type'=>get_post_type($id),'name'=>get_the_title($id),'group'=>$g);
                    break;
                }
            }
        }
        return $out;
    }
    public static function backup($records,$include_settings=true) { Modules::require_enabled('transfer'); return TransferModule::backup($records,$include_settings); }
    public static function export_api() { Modules::require_enabled('transfer'); return TransferModule::export_api(); }
    protected static function put_review($type,$data){
        $token=wp_generate_password(32,false,false);
        set_transient('mnps_'.$type.'_'.get_current_user_id().'_'.$token,$data,10*MINUTE_IN_SECONDS);
        return $token;
    }
    protected static function review($type){
        $token=sanitize_key($_POST['token']??'');
        $key='mnps_'.$type.'_'.get_current_user_id().'_'.$token;
        $data=get_transient($key);
        if(!$data){
            wp_send_json_error(array('message'=>__('مهلت بررسی تمام شده؛ دوباره بررسی کنید.', 'mojtabanaseri-article-products')),409);
        }
        return array($key,$data);
    }
    
    public static function import_review_api() { Modules::require_enabled('transfer'); return TransferModule::import_review_api(); }
    
    public static function import_commit_api() { Modules::require_enabled('transfer'); return TransferModule::import_commit_api(); }
    public static function delete_review_api(){
        self::auth();
        $ids=self::selected();
        if(!$ids){
            wp_send_json_error(array('message'=>__('باکسی انتخاب نشده است.', 'mojtabanaseri-article-products')),400);
        }
        $records=self::records($ids);
        $hashes=array();
        $names=array();
        foreach($records as$r){
            if(!current_user_can('delete_post',$r['source'])){
                wp_send_json_error(array('message'=>__('اجازه حذف همه باکس‌ها را ندارید.', 'mojtabanaseri-article-products')),403);
            }
            $hashes[$r['source']]=Admin::fingerprint($r['source']);
            $names[]=array('name'=>$r['group']['title']?:$r['name'],'articles'=>Store::count($r['box']));
        }
        $backup=Modules::enabled('transfer')?self::backup($records,false):null;
        $digest=hash('sha256',wp_json_encode($backup));
        $token=self::put_review('delete',array('records'=>$records,'hashes'=>$hashes,'digest'=>$digest));
        wp_send_json_success(array('token'=>$token,'digest'=>$digest,'backup'=>$backup,'names'=>$names));
    }
    public static function delete_commit_api(){
        self::auth();
        list($key,$d)=self::review('delete');
        if(empty($_POST['confirmed'])||!hash_equals($d['digest'],(string)($_POST['digest']??''))){
            wp_send_json_error(array('message'=>__('حذف باکس‌ها در همه مقاله‌ها را تأیید کنید.', 'mojtabanaseri-article-products')),400);
        }
        foreach($d['hashes']as$id=>$hash){
            if(!current_user_can('delete_post',$id)||!hash_equals($hash,Admin::fingerprint($id))){
                wp_send_json_error(array('message'=>__('یکی از باکس‌ها تغییر کرده؛ حذف انجام نشد، دوباره بررسی کنید.', 'mojtabanaseri-article-products')),409);
            }
        }
        delete_transient($key);
        $keys=array();
        foreach($d['records']as$r){
            $keys[$r['source']][]=$r['group']['key'];
        }
        $deleted=0;
        $errors=array();
        foreach($keys as$id=>$remove){
            $before=get_post_meta($id,Plugin::META,true);
            if(!hash_equals($d['hashes'][$id],Admin::fingerprint($id))){
                $errors[]=get_the_title($id);
                continue;
            }
            $groups=array_values(array_filter(is_array($before)?$before:array(),function($g)use($remove){
                return !in_array($g['key'],$remove,true);
            }
            ));
            if(!update_post_meta($id,Plugin::META,wp_slash($groups),$before)&&wp_json_encode(get_post_meta($id,Plugin::META,true))!==wp_json_encode($groups)){
                $errors[]=get_the_title($id);
                continue;
            }
            Features::snapshot($id,$groups,$before);
            Plugin::boot()->index($id,$groups);
            Store::index($id);
            $deleted+=count($remove);
        }
        Store::rescan();
        Plugin::boot()->purge_all();
        wp_send_json_success(array('deleted'=>$deleted,'errors'=>$errors));
    }
    public static function page() { Modules::require_enabled('transfer'); return TransferModule::page(); }
}
