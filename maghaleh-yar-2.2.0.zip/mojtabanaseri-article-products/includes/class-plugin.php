<?php
namespace Mojtabanaseri\ArticleProducts;
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
final class Plugin {
    const META = '_mnps_groups';
    const REF = '_mnps_product_ids';
    const LIMIT = 12;
    private static $instance;
    private $purged = array();
    public static function boot() {
        if ( ! self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    private function __construct() {
        add_action('init',function(){
            load_plugin_textdomain('mojtabanaseri-article-products',false,dirname(plugin_basename(MNPS_FILE)).'/languages');
        }
        );
        add_action( 'init', array( $this, 'register' ) );
        add_action( 'init', array( $this, 'register_assets' ) );
        add_action( 'wp_loaded', array( $this, 'shortcodes' ), 100 );
        add_action( 'add_meta_boxes', array( $this, 'boxes' ) );
        add_action( 'save_post', array( $this, 'save' ), 20, 2 );
        add_action( 'admin_enqueue_scripts', array( $this, 'admin_assets' ) );
        add_action( 'admin_notices', array( $this, 'notices' ) );
        add_action( 'wp_ajax_mnps_links', array( $this, 'links' ) );
        add_action( 'wp_ajax_mnps_search', array( $this, 'search' ) );
        add_action( 'wp_ajax_mnps_catalog', array( $this, 'catalog' ) );
        add_action( 'wp_ajax_mnps_preview', array( $this, 'preview' ) );
        add_action( 'admin_menu', array( 'Mojtabanaseri\ArticleProducts\Admin', 'menu' ) );
        add_action( 'admin_bar_menu', array( 'Mojtabanaseri\ArticleProducts\Admin', 'toolbar' ), 90 );
        add_action( 'admin_post_mnps_settings', array( 'Mojtabanaseri\ArticleProducts\Admin', 'save_settings' ) );
        add_action( 'wp_ajax_mnps_saved_preview', array( $this, 'saved_preview' ) );
        add_action( 'wp_ajax_mnps_export_design', array( $this, 'export_design' ) );
        if(Modules::enabled('elementor'))add_action( 'elementor/editor/after_enqueue_scripts', array( $this, 'elementor_editor_assets' ) );
        add_action( 'enqueue_block_editor_assets', array( $this, 'editor_assets' ) );
        if(Modules::enabled('elementor'))add_action( 'elementor/widgets/register', array( $this, 'elementor' ) );
        add_filter( 'mce_external_plugins', array( $this, 'mce_plugin' ) );
        add_filter( 'mce_buttons', array( $this, 'mce_buttons' ) );
        add_action('woocommerce_updated_product_sales',array($this,'product_changed'));
        add_action( 'woocommerce_update_product', array( $this, 'product_changed' ) );
        add_action( 'woocommerce_update_product_variation', array( $this, 'product_changed' ) );
        add_action( 'woocommerce_product_set_stock', array( $this, 'stock_changed' ) );
        add_action( 'woocommerce_variation_set_stock', array( $this, 'stock_changed' ) );
        add_action( 'woocommerce_product_set_stock_status', array( $this, 'product_changed' ) );
        add_action( 'woocommerce_variation_set_stock_status', array( $this, 'product_changed' ) );
        if(Modules::enabled('acf'))add_action( 'acf/save_post', array( $this, 'acf_saved' ), 30 );
        add_action( 'transition_post_status', array( $this, 'status_changed' ), 10, 3 );
        add_action( 'before_delete_post', array( $this, 'deleting' ) );
        add_action('deleted_post',array($this,'deleted'),10,2);
        add_action('deleted_post_meta',array('Mojtabanaseri\\ArticleProducts\\Store','elementor_saved'),40,3);
        add_action( 'wp_enqueue_scripts', array( $this, 'register_assets' ) );
        add_action('admin_init',array('Mojtabanaseri\\ArticleProducts\\Admin','init'));
        add_action('save_post',array('Mojtabanaseri\\ArticleProducts\\Store','on_save'),40,2);
        add_action('added_post_meta',array('Mojtabanaseri\\ArticleProducts\\Store','elementor_saved'),40,3);
        add_action('updated_post_meta',array('Mojtabanaseri\\ArticleProducts\\Store','elementor_saved'),40,3);
        foreach(array('save_box','duplicate','usage','visibility','scan','save_template','delete_template','delete_box','archive_stats')as$a){
            add_action('wp_ajax_mnps_'.$a,array('Mojtabanaseri\\ArticleProducts\\Admin',$a));
        }
        add_action('mnps_health_batch',array('Mojtabanaseri\\ArticleProducts\\Features','health_batch'),10,2);
        add_filter('woocommerce_product_data_store_cpt_get_products_query',array('Mojtabanaseri\\ArticleProducts\\Features','order_query'),10,2);
        foreach(array('health','auto','restore','replace','candidates')as$a){
            add_action('wp_ajax_mnps_'.$a,array('Mojtabanaseri\\ArticleProducts\\Features',$a.'_api'));
        }
    }
    public function register() {
        register_post_type( 'mnps_group', array(
        'labels' => array( 'name' => __('مقاله‌یار', 'mojtabanaseri-article-products'), 'singular_name' => __('باکس', 'mojtabanaseri-article-products'), 'add_new_item' => __('ساخت باکس جدید', 'mojtabanaseri-article-products'), 'edit_item' => __('ویرایش باکس', 'mojtabanaseri-article-products'), 'add_new' => __('باکس جدید', 'mojtabanaseri-article-products'), 'all_items' => __('باکس‌های من', 'mojtabanaseri-article-products') ),
        'public' => false, 'show_ui' => true, 'show_in_rest' => false, 'show_in_menu' => false,
        'menu_icon' => 'dashicons-products', 'supports' => array( 'title' ),
        'capability_type' => 'post', 'map_meta_cap' => true, 'has_archive' => false, 'rewrite' => false,
        ) );
        register_post_type('mnps_design',array('public'=>false,'show_ui'=>false,'supports'=>array('title'),'capability_type'=>'post','map_meta_cap'=>true));
        wp_register_script( 'mnps-block', MNPS_URL . 'assets/block.js', array( 'wp-i18n', 'wp-blocks', 'wp-element', 'wp-components', 'wp-block-editor', 'wp-server-side-render' ), MNPS_VERSION, true );
        register_block_type( 'mojtabanaseri/article-products', array(
        'api_version' => 3, 'editor_script' => 'mnps-block',
        'attributes' => array( 'post' => array( 'type' => 'integer', 'default' => 0 ), 'group' => array( 'type' => 'string', 'default' => '' ), 'title' => array( 'type' => 'string', 'default' => '' ) ),
        'render_callback' => function ( $atts ) {
            if ( isset( $atts['title'] ) && '' === $atts['title'] ) {
                unset( $atts['title'] );
            }
            return $this->render( $atts );
        }
        ,
        ) );
    }
    public function shortcodes() {
        add_shortcode( 'mn_products', array( $this, 'render' ) );
        add_shortcode( 'mn_cta', array( $this, 'render' ) );
        add_shortcode( 'maghaleh_yar', array( $this, 'render' ) );
        add_shortcode( 'rg_related_products', array( $this, 'render' ) );
        add_shortcode('my_box',function($a){
            $r=Store::resolve(absint($a['id']??0));return $r?$this->render(array('post'=>(int)$r->source_post,'group'=>$r->group_key)):'';
        }
        );
    }
    public function register_assets() {
        wp_register_style( 'mnps-font', MNPS_URL . 'assets/font.css', array(), MNPS_VERSION );
        wp_register_style( 'mnps-front', MNPS_URL . 'assets/front.css', array(), MNPS_VERSION );
        wp_register_script( 'mnps-front', MNPS_URL . 'assets/front.js', array(), MNPS_VERSION, true );
    }
    public function groups( $post_id ) {
        $groups = get_post_meta( absint( $post_id ), self::META, true );
        if ( ! is_array( $groups ) ) {
            return array();
        }
        foreach ( $groups as &$group ) {
            if ( ! is_array( $group ) ) {
                continue;
            }
            $group += array( 'type' => 'products', 'style' => array(), 'cta' => Appearance::cta(array()) );
        }
        unset($group);
        return array_values( array_filter( $groups, 'is_array' ) );
    }
    private static function clip( $text, $start, $length ) {
        if ( function_exists( 'mb_substr' ) ) {
            return mb_substr( $text, $start, $length, 'UTF-8' );
        }
        $chars = preg_split( '//u', $text, -1, PREG_SPLIT_NO_EMPTY );
        return is_array( $chars ) ? implode( '', array_slice( $chars, $start, $length ) ) : substr( $text, $start, $length );
    }
    private static function length( $text ) {
        if ( function_exists( 'mb_strlen' ) ) {
            return mb_strlen( $text, 'UTF-8' );
        }
        return preg_match_all( '/./us', $text );
    }
    public function normalize( $input ) {
        if ( ! is_array( $input ) ) {
            return array();
        }
        $out = array();
        $seen = array();
        foreach ( array_slice( $input, 0, 20 ) as $group ) {
            if ( ! is_array( $group ) ) {
                continue;
            }
            $key = isset( $group['key'] ) && is_scalar( $group['key'] ) ? sanitize_key( $group['key'] ) : '';
            if ( ! $key || isset( $seen[$key] ) ) {
                $key = 'g' . str_replace( '-', '', wp_generate_uuid4() );
            }
            $seen[$key] = true;
            $text = function ( $field, $max ) use ( $group ) {
                return isset( $group[$field] ) && is_scalar( $group[$field] ) ? self::clip( sanitize_text_field( (string) $group[$field] ), 0, $max ) : '';
            }
            ;
            $items = array();
            $ids = array();
            foreach ( array_slice( isset( $group['items'] ) && is_array( $group['items'] ) ? $group['items'] : array(), 0, self::LIMIT ) as $item ) {
                if ( ! is_array( $item ) || empty( $item['id'] ) || ! is_scalar( $item['id'] ) ) {
                    continue;
                }
                $id = absint( $item['id'] );
                if ( ! $id || isset( $ids[$id] ) ) {
                    continue;
                }
                $ids[$id] = true;
                $desc = isset( $item['description'] ) && is_scalar( $item['description'] ) ? self::clip( sanitize_textarea_field( (string) $item['description'] ), 0, 1500 ) : '';
                $badge = isset( $item['badge'] ) && is_scalar( $item['badge'] ) ? self::clip( sanitize_text_field( (string) $item['badge'] ), 0, 80 ) : '';
                $items[] = array_merge(array( 'id' => $id, 'description' => $desc, 'badge' => $badge, 'hide_description'=>!empty($item['hide_description']) ), ProductOptions::clean_item($item));
            }
            $out[] = array( 'key' => $key, 'title' => $text( 'title', 200 ),
            'customize' => !isset($group['customize']) || !empty($group['customize']),
            'archive' => ProductOptions::clean_archive($group['archive']??array()),
            'type' => isset($group['type']) && 'cta' === $group['type'] ? 'cta' : 'products',
            'style' => Appearance::clean($group['style'] ?? array()),
            'custom' => Appearance::code($group['custom']??array()),
            'auto'=>Features::clean_auto($group['auto']??array()),
            'empty'=>($group['empty']??'hide')==='text'?'text':'hide',
            'empty_text'=>$text('empty_text',250),
            'font'=>($group['font']??'plugin')==='theme'?'theme':'plugin',
            'hide_title'=>!empty($group['hide_title']),
            'title_tag'=>in_array($group['title_tag']??'p',array('p','div','span','h1','h2','h3','h4','h5','h6'),true)?($group['title_tag']??'p'):'p',
            'title_line'=>!isset($group['title_line'])||!empty($group['title_line']),
            'show_price'=>!isset($group['show_price'])||!empty($group['show_price']),
            'show_badge'=>!isset($group['show_badge'])||!empty($group['show_badge']),
            'show_button'=>!isset($group['show_button'])||!empty($group['show_button']),
            'button_label'=>$text('button_label',100)?:__('مشاهده محصول', 'mojtabanaseri-article-products'),
            'button_icon'=>Appearance::attachment($group['button_icon']??0),
            'title_icon'=>Appearance::attachment($group['title_icon']??0),
            'left_icon'=>Appearance::attachment($group['left_icon']??0),
            'right_icon'=>Appearance::attachment($group['right_icon']??0),
            'tags'=>array_slice(array_values(array_unique(array_filter(array_map('sanitize_text_field',array_filter(is_array($group['tags']??null)?$group['tags']:array(),'is_string'))))),0,10),
            'cta' => Appearance::cta($group['cta'] ?? array()),
            'layout' => isset( $group['layout'] ) && 'grid' === $group['layout'] ? 'grid' : 'slider',
            'accent' => isset( $group['accent'] ) && is_scalar( $group['accent'] ) && sanitize_hex_color( $group['accent'] ) ? sanitize_hex_color( $group['accent'] ) : Appearance::current()['accent'],
            'hide_stock' => ! empty( $group['hide_stock'] ), 'description' => ! isset( $group['description'] ) || ! empty( $group['description'] ),
            'words' => isset( $group['words'] ) && is_scalar( $group['words'] ) ? max( 5, min( 100, absint( $group['words'] ) ) ) : 30,
            'desktop' => isset( $group['desktop'] ) && is_scalar( $group['desktop'] ) ? max( 1, min( 4, absint( $group['desktop'] ) ) ) : 3,
            'product_overrides'=>ProductOptions::clean_overrides($group['product_overrides']??array()),
            'items' => $items );
            $out[count($out)-1] = Suite::normalize($out[count($out)-1],$group);
        }
        return $out;
    }
    public function boxes() { return (new PluginAdmin($this))->boxes(); }
    public function box( $post ) { return (new PluginAdmin($this))->box($post); }
    public function save( $id, $post ) { if(!isset($_POST['mnps_save_nonce'],$_POST['mnps_data']))return; return (new PluginAdmin($this))->save($id,$post); }
    public function index( $id, $groups ) {
        delete_post_meta( $id, self::REF );
        $ids = array();
        foreach ( $groups as $group ) {
            foreach ( $group['items'] as $item ) {
                $ids[] = absint( $item['id'] );
            }
            foreach($group['table']['rows']??array()as$row){if(!empty($row['product']))$ids[]=absint($row['product']);}
            foreach($group['auto']['pinned']??array()as$pid){
                $ids[]=$pid;
            }
        }
        foreach ( array_unique( $ids ) as $product_id ) {
            add_post_meta( $id, self::REF, $product_id );
        }
        Store::sync($id,$groups);
        delete_post_meta($id,'_mnps_tags');
        $tags=array();
        foreach($groups as$g){
            $tags=array_merge($tags,$g['tags']??array());
        }
        foreach(array_unique($tags)as$t){
            add_post_meta($id,'_mnps_tags',$t);
        }
    }
    public function protect_code($groups,$id=0) {
        if(current_user_can('manage_options')&&current_user_can('unfiltered_html')){
            return $groups;
        }
        $existing=array();
        foreach($id?$this->groups($id):array()as$g){
            $existing[$g['key']]=$g['custom']??array();
        }
        foreach($groups as&$g){
            if(is_array($g)){
                $g['custom']=$existing[$g['key']??'']??array();
            }
        }
        unset($g);
        return $groups;
    }
    public function admin_assets( $hook ) { return (new PluginAdmin($this))->admin_assets($hook); }
    public function editor_assets() { return (new PluginAdmin($this))->editor_assets(); }
    
    
    public function search() { return (new PluginAdmin($this))->search(); }
    public function links() { return (new PluginAdmin($this))->links(); }
    public function catalog() { return (new PluginAdmin($this))->catalog(); }
    public function preview() { return (new PluginAdmin($this))->preview(); }
    public function render( $atts = array() ) {
        $atts = shortcode_atts( array( 'id' => 0, 'post' => 0, 'style' => array(), 'group' => '', 'title' => null, 'ids' => '', 'limit' => 12, 'desktop' => null, 'description' => null, 'description_words' => null,'controls'=>array() ), is_array( $atts ) ? $atts : array(), 'mn_products' );
        $post_id = absint($atts['id']) ?: ( absint( $atts['post'] ) ?: get_the_ID() );
        $source = get_post( $post_id );
        $can_preview = $source && current_user_can( 'edit_post', $post_id ) && ( is_preview() || ( defined( 'REST_REQUEST' ) && REST_REQUEST ) || ( class_exists( '\Elementor\Plugin' ) && \Elementor\Plugin::$instance->editor->is_edit_mode() ) );
        if ( $source && 'publish' !== $source->post_status && ! $can_preview ) {
            return '';
        }
        $group = null;
        if ( '' !== trim( (string) $atts['ids'] ) ) {
            $ids = preg_split( __('/[\\s,،]+/u', 'mojtabanaseri-article-products'), trim( (string) $atts['ids'] ) );
            $items = array();
            foreach ( array_slice( $ids, 0, 12 ) as $id ) {
                if ( preg_match( '/^[0-9]+$/D', (string) $id ) ) {
                    $items[] = array( 'id' => absint( $id ) );
                }
            }
            $data = $this->normalize( array( array( 'title' => __('محصولات مرتبط با این مقاله', 'mojtabanaseri-article-products'), 'product_overrides'=>ProductOptions::clean_overrides($group['product_overrides']??array()),
            'items' => $items ) ) );
            $group = $data[0];
        }
        else {
            $groups = $this->groups( $post_id );
            foreach ( $groups as $g ) {
                if ( '' === $atts['group'] || $g['key'] === sanitize_key( $atts['group'] ) ) {
                    $group = $g;
                    break;
                }
            }
            if ( ! $group && '' === $atts['group'] && Modules::enabled('acf') && function_exists( 'get_field' ) && $source && 'post' === $source->post_type ) {
                $selected = get_field( 'rg_related_products', $post_id );
                $items = array();
                if ( is_array( $selected ) ) {
                    foreach ( array_slice( $selected, 0, 12 ) as $p ) {
                        $items[] = array( 'id' => is_object( $p ) && isset( $p->ID ) ? absint( $p->ID ) : ( is_scalar( $p ) ? absint( $p ) : 0 ) );
                    }
                }
                $data = $this->normalize( array( array( 'title' => __('محصولات مرتبط با این مقاله', 'mojtabanaseri-article-products'), 'product_overrides'=>ProductOptions::clean_overrides($group['product_overrides']??array()),
                'items' => $items ) ) );
                $group = $data[0];
            }
        }
        if ( ! $group ) {
            return '';
        }
        if(empty($atts['ids'])&&!$can_preview&&Store::hidden($post_id,$group['key'])){
            return '';
        }
        if(is_array($atts['controls'])&&$atts['controls']){
            foreach(array('hide_title','title_tag','title_line','show_price','show_badge','show_button','button_label','button_icon','left_icon','right_icon')as$k){
                if(isset($atts['controls'][$k])){
                    $group[$k]=$atts['controls'][$k];
                }
            }
            $group=$this->normalize(array($group))[0];
        }
        if ( null !== $atts['title'] ) {
            $group['title'] = sanitize_text_field( $atts['title'] );
        }
        if ( null !== $atts['desktop'] ) {
            $group['desktop'] = max( 1, min( 4, absint( $atts['desktop'] ) ) );
        }
        if ( null !== $atts['description'] ) {
            $group['description'] = in_array( strtolower( (string) $atts['description'] ), array( 'yes', '1', 'true' ), true );
        }
        if ( null !== $atts['description_words'] ) {
            $group['words'] = max( 5, min( 100, absint( $atts['description_words'] ) ) );
        }
        $group['items'] = array_slice( $group['items'], 0, max( 1, min( 12, absint( $atts['limit'] ) ) ) );
        $group['style'] = array_merge($group['style']??array(),Appearance::clean($atts['style']));
        return $this->html( $group );
    }
    public function html( $group, $unused = 0, $preview = false ) {
        if (!$preview && (empty($group['display_enabled']) || Suite::expired($group))) return '';
        if (($group['type']??'products')==='table') $html=Suite::table_html($group,$preview);
        elseif (($group['type']??'products')==='cta' && !empty($group['content'])) $html=Suite::cta_html($group,$preview);
        else $html=$this->legacy_html($group,$unused,$preview);
        return Suite::decorate($html,$group,$preview);
    }
    private function legacy_html( $group, $unused = 0, $preview = false ) {
        if ( isset($group['type']) && 'cta' === $group['type'] ) {
            return ($group['font']??'plugin')==='theme'?str_replace('class="mnps-section ','class="mnps-section mnps-theme-font ',$this->cta_html($group,$preview)):$this->cta_html($group,$preview);
        }
        if ( ! function_exists( 'wc_get_product' ) ) {
            return $preview ? ('<p>'.esc_html__('برای نمایش محصولات، ووکامرس را فعال کن.', 'mojtabanaseri-article-products').'</p>') : '';
        }
        $group['items']=Features::effective($group);
        if(isset($group['customize'])&&!$group['customize']){
            return ProductOptions::theme_html($group,$preview);
        }
        $cards = '';
        if(function_exists('_prime_post_caches')){
            _prime_post_caches(array_column($group['items'],'id'),true,true);
        }
        foreach ( $group['items'] as $item ) {
            $p = wc_get_product( $item['id'] );
            if ( ! $p || 'publish' !== $p->get_status() || ! $p->is_visible() || ( $group['hide_stock'] && ! $p->is_in_stock() ) ) {
                continue;
            }
            $url = !empty($item['url']) ? $item['url'] : $p->get_permalink();
            $image = $p->get_image_id()?$p->get_image( 'woocommerce_thumbnail', array( 'class' => 'mnps-image', 'alt' => $p->get_name(), 'loading' => 'lazy', 'decoding' => 'async' ) ):'<span class="mnps-image-placeholder" role="img" aria-label="'.esc_attr($p->get_name().__(' — تصویر ثبت نشده', 'mojtabanaseri-article-products')).'">'.Appearance::icon('bag').'</span>';
            $description = $item['description'];
            if ( '' === $description ) {
                $description = wp_strip_all_tags( strip_shortcodes( $p->get_short_description() ), true );
            }
            $description = wp_trim_words( $description, $group['words'], '…' );
            $cards .= '<div class="mnps-card">';
            if ( '' !== $item['badge'] && ProductOptions::visible($item,'show_badge',$group) ) {
                $cards .= '<span class="mnps-badge">' . esc_html( $item['badge'] ) . '</span>';
            }
            $cards .= '<a class="mnps-image-link" href="' . esc_url( $url ) . '">' . wp_kses_post( $image ) . '</a><div class="mnps-card-body"><a class="mnps-product-name" href="' . esc_url( $url ) . '">' . esc_html( $p->get_name() ) . '</a>';
            if ( ProductOptions::visible($item,'show_description',$group) && '' !== trim( $description ) ) {
                $cards .= '<p class="mnps-description">' . esc_html( $description ) . '</p>';
            }
            if ( ! $p->is_in_stock() ) {
                $cards .= ('<span class="mnps-stock">'.esc_html__('فعلاً ناموجود', 'mojtabanaseri-article-products').'</span>');
            }
            $cards.='<div class="mnps-card-bottom">';
            if(ProductOptions::visible($item,'show_price',$group)){
                $cards.='<div class="mnps-price">'.(!empty($item['price_text'])?esc_html($item['price_text']):wp_kses_post($p->get_price_html())).'</div>';
            }
            if(ProductOptions::visible($item,'show_button',$group)){
                $cards.='<a class="mnps-button" href="'.esc_url($url).'">'.esc_html(!empty($item['button_label'])?$item['button_label']:($group['button_label']??__('مشاهده محصول', 'mojtabanaseri-article-products'))).Appearance::media_icon($group['button_icon']??0,'arrow').'<span class="screen-reader-text">: '.esc_html($p->get_name()).'</span></a>';
            }
            $cards.='</div></div></div>';
        }
        if ( '' === $cards ) {
            return ($group['empty']??'hide')==='text'?'<p class="mnps-empty-output">'.esc_html($group['empty_text']??'').'</p>':($preview?('<p>'.esc_html__('باکس در سایت پنهان می‌شود؛ محصول قابل نمایش وجود ندارد.', 'mojtabanaseri-article-products').'</p>'):'');
        }
        $styles=$this->output_assets($preview,$group['font']??'plugin');
        $id = wp_unique_id( 'mnps-' );
        $title_id = $id . '-title';
        $track_id = $id . '-track';
        $label = $group['title'] ?: __('محصولات پیشنهادی', 'mojtabanaseri-article-products');
        $out = '<section class="mnps-section mnps-' . esc_attr( $group['layout'] ) . '" dir="rtl" aria-label="' . esc_attr( $label ) . '" style="--mnps-accent:' . esc_attr( sanitize_hex_color( $group['accent'] ) ?: '#2563eb' ) . ';' . esc_attr(Appearance::css(array_merge(array('accent'=>$group['accent']),$group['style']??array()))) . '--mnps-columns:' . absint( $group['desktop'] ) . '">';
        if(($group['font']??'plugin')==='theme'){
            $out=str_replace('class="mnps-section ','class="mnps-section mnps-theme-font ',$out);
        }
        $out=str_replace('<section ', '<section data-mnps-custom="'.esc_attr(wp_json_encode($group['custom']??array())).'" ', $out);
        $out .= '<div class="mnps-heading">';
        $out.=Appearance::title($group,$title_id);
        $out.='<div class="mnps-heading-actions">'.ProductOptions::archive_html($group);
        if('slider'===$group['layout']){
            $out.=('<div class="mnps-arrows">'.'<button type="button" class="mnps-arrow" data-mnps-direction="previous" aria-label="'.esc_attr__('محصولات قبلی', 'mojtabanaseri-article-products').'" aria-controls="').esc_attr($track_id).'">'.Appearance::media_icon($group['right_icon']??0,'right').('</button>'.'<button type="button" class="mnps-arrow" data-mnps-direction="next" aria-label="'.esc_attr__('محصولات بعدی', 'mojtabanaseri-article-products').'" aria-controls="').esc_attr($track_id).'">'.Appearance::media_icon($group['left_icon']??0,'left').'</button></div>';
        }
        return $styles . $out . '</div></div><div class="mnps-track" id="' . esc_attr( $track_id ) . '" tabindex="0" aria-label="' . esc_attr( $label ) . '">' . $cards . '</div></section>';
    }
    public function output_assets($preview,$font='plugin',$type='products') {
        $this->register_assets();
        if($preview){
            return '';
        }
        $handles=array('mnps-front');
        if($font!=='theme'){
            wp_enqueue_style('mnps-font');
            array_unshift($handles,'mnps-font');
        }
        wp_enqueue_style('mnps-front');
        wp_enqueue_script('mnps-front');
        if(did_action('wp_head')){
            foreach($handles as$handle){
                if(!wp_style_is($handle,'done')){
                    ob_start();
                    wp_print_styles($handles);
                    return ob_get_clean();
                }
            }
        }
        return '';
    }
    private function cta_html($group,$preview=false) {
        $cta=Appearance::cta($group['cta']??array());
        $style=Appearance::css(array_merge(array('accent'=>$group['accent']??'#2563eb'),$group['style']??array()));
        $image_mode=$cta['image_mode'];
        if($image_mode==='background'&&$cta['image']){
            $image_url=wp_get_attachment_image_url($cta['image'],'large');
            if($image_url){
                $style.='background-image:url('.esc_url($image_url).');';
            }
        }
        $out=$this->output_assets($preview,$group['font']??'plugin','cta').'<section data-mnps-custom="'.esc_attr(wp_json_encode($group['custom']??array())).'" class="mnps-section mnps-cta mnps-cta-'.$cta['layout'].($image_mode==='background'?' mnps-cta-background':'').'" dir="rtl" style="'.esc_attr($style).'" aria-label="'.esc_attr($group['title']?:__('دعوت به اقدام', 'mojtabanaseri-article-products')).'">';
        if($cta['image']&&$image_mode==='side'){
            $out.='<div class="mnps-cta-media">'.wp_get_attachment_image($cta['image'],'medium_large',false,array('class'=>'mnps-cta-image','loading'=>'lazy','decoding'=>'async')).'</div>';
        }
        $out.='<div class="mnps-cta-body">';
        $out.=Appearance::title($group);
        if($cta['description']){
            $out.='<p class="mnps-description">'.esc_html($cta['description']).'</p>';
        }
        $icon=$cta['icon_media']?wp_get_attachment_image($cta['icon_media'],'thumbnail',false,array('class'=>'mnps-cta-icon','alt'=>'','loading'=>'lazy')):Appearance::icon($cta['icon']);
        if($cta['url']){
            $out.='<a class="mnps-button mnps-cta-button" href="'.esc_url($cta['url'],array('http','https','mailto','tel')).'"'.($cta['new_tab']?' target="_blank" rel="noopener noreferrer"':'').'>'.esc_html($cta['button_label']).$icon.'</a>';
        }
        elseif($preview){
            $out.='<span class="mnps-button mnps-cta-button">'.esc_html($cta['button_label']).$icon.('</span>'.'<small class="mnps-link-warning">'.esc_html__('برای فعال شدن دکمه، لینک مقصد را وارد کن.', 'mojtabanaseri-article-products').'</small>');
        }
        return $out.'</div></section>';
    }
    public function saved_preview() { return (new PluginAdmin($this))->saved_preview(); }
    public function elementor_editor_assets() { return (new PluginAdmin($this))->elementor_editor_assets(); }
    public function export_design() { return (new PluginAdmin($this))->export_design(); }
    public function elementor_cta($settings) {
        if(!empty($settings['source'])&&is_string($settings['source'])){
            $parts=explode(':',$settings['source'],2);
            return $this->render(array('post'=>absint($parts[0]),'group'=>$parts[1]??'','style'=>$settings['design']??array(),'controls'=>Appearance::widget_controls($settings)));
        }
        $group=array('type'=>'cta','title'=>$settings['title']??'','style'=>$settings['design']??array(),'cta'=>array('description'=>$settings['description']??'','button_label'=>$settings['button_label']??'','url'=>$settings['link']['url']??'','new_tab'=>!empty($settings['link']['is_external']),'image'=>$settings['image']['id']??0,'icon_media'=>$settings['icon_media']['id']??0,'icon'=>$settings['icon']??'arrow','layout'=>$settings['layout']??'horizontal'));
        $group=array_merge($group,Appearance::widget_controls($settings));
        $normalized=$this->normalize(array($group));
        return $this->html($normalized[0]);
    }
    public function elementor( $manager ) {
        if ( ! class_exists( '\Elementor\Widget_Base' ) ) {
            return;
        }
        if(!Modules::enabled('elementor'))return;
        $manager->register( new Elementor_Widget() );
        $manager->register( new Elementor_CTA_Widget() );
    }
    public function mce_plugin( $plugins ) { return (new PluginAdmin($this))->mce_plugin($plugins); }
    public function mce_buttons( $buttons ) { return (new PluginAdmin($this))->mce_buttons($buttons); }
    public function notices($inside=false) { return (new PluginAdmin($this))->notices($inside); }
    public function stock_changed( $product ) {
        if ( $product instanceof \WC_Product ) {
            $this->product_changed( $product->get_id() );
        }
    }
    public function product_changed( $product_id ) {
        $product_id = absint( $product_id );
        if ( 'product_variation' === get_post_type( $product_id ) ) {
            $product_id = wp_get_post_parent_id( $product_id );
        }
        if ( ! $product_id ) {
            return;
        }
        Features::product_changed($product_id);
        // Page builders and arbitrary shortcodes require site-wide invalidation.
        $this->purge_all();
    }
    public function status_changed( $new, $old, $post ) {
        if ( $new === $old ) {
            return;
        }
        Store::invalidate();
        if(in_array($post->post_type,array('product','product_variation'),true)){
            Features::product_changed($post->ID);
        }
        if ( in_array( $post->post_type, array( 'product', 'product_variation', 'mnps_group' ), true ) ) {
            $this->purge_all();
        }
    }
    public function deleted($id,$post=null){
        Store::invalidate();
        if($post&&in_array($post->post_type,array('product','product_variation'),true)){
            Features::product_changed($post->post_type==='product_variation'?$post->post_parent:$id);
        }
    }
    public function deleting( $id ) {
        if ( in_array( get_post_type( $id ), array( 'product', 'product_variation', 'mnps_group' ), true ) ) {
            $this->purge_all();
        }
    }
    public function acf_saved($id) { if(Modules::enabled('acf'))ACFIntegration::saved($id); }
    public function purge_post( $id ) {
        if ( isset( $this->purged[$id] ) ) {
            return;
        }
        $this->purged[$id] = true;
        clean_post_cache( $id );
        if ( function_exists( 'rocket_clean_post' ) ) {
            rocket_clean_post( $id );
        }
        do_action( 'litespeed_purge_post', $id );
        if ( function_exists( 'w3tc_flush_post' ) ) {
            w3tc_flush_post( $id );
        }
        if ( function_exists( 'wp_cache_post_change' ) ) {
            wp_cache_post_change( $id );
        }
        do_action( 'mnps_purge_post', $id );
    }
    public function purge_all() {
        if ( isset( $this->purged['all'] ) ) {
            return;
        }
        $this->purged['all'] = true;
        add_action( 'shutdown', function () {
            if ( function_exists( 'rocket_clean_domain' ) ) {
                rocket_clean_domain();
            }
            do_action( 'litespeed_purge_all' );
            if ( function_exists( 'w3tc_flush_all' ) ) {
                w3tc_flush_all();
            }
            if ( function_exists( 'wp_cache_clear_cache' ) ) {
                wp_cache_clear_cache();
            }
            do_action( 'mnps_purge_all' );
        }
        , 100 );
    }
}
