const fs=require('fs'),vm=require('vm'),assert=require('assert'),events=require('events'),path=require('path');
let assertions=0;
function ok(value,message){assert.ok(value,message);assertions++}
class El {
 constructor(tag='div',classes=''){this.tagName=tag.toUpperCase();this.children=[];this.attrs={};this.dataset={};this.listeners={};this.style={};this.parent=null;this._text='';this.classes=new Set(classes.split(' ').filter(Boolean));this.classList={add:(...x)=>x.forEach(v=>this.classes.add(v)),remove:(...x)=>x.forEach(v=>this.classes.delete(v)),toggle:(v,b)=>{b=b===undefined?!this.classes.has(v):b;b?this.classes.add(v):this.classes.delete(v);return b}};}
 append(...children){for(const c of children){c.parent=this;this.children.push(c)}}
 set textContent(v){this._text=String(v);this.children=[]}get textContent(){return this._text+this.children.map(x=>x.textContent).join('')}
 set className(v){this.classes=new Set(v.split(' '))}get className(){return [...this.classes].join(' ')}
 get firstElementChild(){return this.children[0]}
 setAttribute(k,v){this.attrs[k]=String(v)}getAttribute(k){return this.attrs[k]??null}removeAttribute(k){delete this.attrs[k]}
 matches(sel){return sel==='button'?this.tagName==='BUTTON':sel[0]==='.'?this.classes.has(sel.slice(1)):sel==='[data-action]'?!!this.dataset.action:false}
 closest(sel){return this.matches(sel)?this:this.parent?.closest(sel)||null}
 contains(node){return node===this||this.children.some(x=>x.contains(node))}
 querySelectorAll(sel){let out=[];for(const c of this.children){if(c.matches(sel))out.push(c);out.push(...c.querySelectorAll(sel))}return out}
 querySelector(sel){if(sel==='.lumi-progress > span')return this.querySelector('.lumi-progress')?.children[0]||null;const a=sel.match(/^\[data-action="(.*)"\]$/);if(a)return this.all().find(x=>x.dataset.action===a[1])||null;return this.querySelectorAll(sel)[0]||null}
 all(){return this.children.flatMap(x=>[x,...x.all()])}
 addEventListener(e,f){(this.listeners[e]||=new Set()).add(f)}removeEventListener(e,f){this.listeners[e]?.delete(f)}
 getBoundingClientRect(){return {width:this.width||0}}
 setPointerCapture(id){this.capture=id}hasPointerCapture(id){return this.capture===id}releasePointerCapture(){this.capture=null}
}
function setup(file,rtl=false,mode='negative',count=8,cols=2.3,banner=false){
 let clock=0,next=1,raf=new Map(),timers=new Map(),observer=[];
 const doc=new El();doc.readyState='loading';doc.hidden=false;doc.documentElement={lang:'fa-IR'};doc.createElement=t=>new El(t);doc.body=new El();doc.append(doc.body);
 const root=new El('section','lumi-slider');root.isConnected=true;const viewport=new El('div','lumi-viewport'),track=new El('div','lumi-track'),dots=new El('div','lumi-dots'),arrows=new El('div','lumi-arrows');
 root.dir=rtl?'rtl':'ltr';viewport.dir=root.dir;const gap=banner?0:12,sw=(500-(cols-1)*gap)/cols;
 viewport.clientWidth=500;viewport.scrollWidth=count*sw+(count-1)*gap;
 let raw=rtl&&mode==='default'?Math.max(0,viewport.scrollWidth-500):0;
 Object.defineProperty(viewport,'scrollLeft',{get(){return raw},set(v){const max=Math.max(0,viewport.scrollWidth-viewport.clientWidth);raw=rtl&&mode==='negative'?Math.max(-max,Math.min(0,v)):Math.max(0,Math.min(max,v))}});
 for(let i=0;i<count;i++){const slide=new El('div','lumi-slide');slide.width=sw;track.append(slide)}viewport.append(track);
 for(const action of ['prev','next','pause']){const b=new El('button');b.dataset.action=action;b.append(new El('span'));arrows.append(b)}
 root.append(viewport,arrows,dots);doc.body.append(root);
 const media=new El();media.matches=false;
 class AC extends AbortController{constructor(){super();events.setMaxListeners(0,this.signal)}}
 const ctx={document:doc,window:new El(),AbortController:AC,matchMedia:()=>media,getComputedStyle:el=>({direction:el.dir||root.dir,columnGap:String(gap)}),requestAnimationFrame:f=>{const id=next++;raf.set(id,f);return id},cancelAnimationFrame:id=>raf.delete(id),setTimeout:(f,d)=>{const id=next++;timers.set(id,{f,d});return id},clearTimeout:id=>timers.delete(id),performance:{now:()=>clock},console};
 ctx.window.AbortController=AC;
 ctx.window.ResizeObserver=class{constructor(f){this.f=f;observer.push(this)}observe(){}disconnect(){this.disconnected=true}};
 ctx.ResizeObserver=ctx.window.ResizeObserver;
 let source=fs.readFileSync(file,'utf8');source=source.replace('window.ECC=',`rtlMode=${JSON.stringify(mode)};window.Engine=ECCSlider;window.ECC=`).replace('window.ECC =',`rtlMode=${JSON.stringify(mode)};window.Engine=ECCSlider;window.ECC =`);
 vm.createContext(ctx);vm.runInContext(source,ctx);
 const settings={speed:0,delay:5000,autoplay:false,hover:true,loop:false,drag:true,dots:true,banner,nav:'numbers_titles',labels:['الف','ب'],dotLabel:'صفحه %s',slideLabel:'%1$s از %2$s',playLabel:'پخش',pauseLabel:'توقف'};root.dataset.settings=JSON.stringify(settings);
 const create=overrides=>{root.dataset.settings=JSON.stringify({...settings,...overrides});return new ctx.window.Engine(root)};
 const flush=ms=>{clock+=ms;const jobs=[...raf.values()];raf.clear();jobs.forEach(f=>f(clock))};
 return {ctx,root,viewport,track,dots,create,timers,raf,flush,media,observer,settings};
}
for(const file of [path.join(__dirname,'../assets/js/lumi-slider.js'),path.join(__dirname,'../assets/js/lumi-slider.min.js')]){
 for(const [rtl,mode] of [[false,'negative'],[true,'negative'],[true,'reverse'],[true,'default']]){
  const t=setup(file,rtl,mode),s=t.create();
  ok(s.pages===7,'fractional page count');ok(s.position()===0,'normalized start');
  s.advance(1);ok(Math.abs(s.position()-s.step)<.01,'next moves one step');
  s.go(s.pages-1);ok(Math.abs(s.position()-s.max)<.01,'last page reaches exact end');
  ok(t.root.querySelector('[data-action="next"]').getAttribute('aria-disabled')==='true','finite end arrow disabled');
  s.go(0);let prevented=false;s.key({target:t.viewport,key:rtl?'ArrowLeft':'ArrowRight',preventDefault(){prevented=true}});
  ok(prevented&&s.active===1,'keyboard direction');
  s.key({target:t.viewport,key:'Home',preventDefault(){}});ok(s.position()===0,'Home');
  s.key({target:t.viewport,key:'End',preventDefault(){}});ok(s.position()===s.max,'End');
  s.destroy();ok(Object.values(t.viewport.listeners).every(x=>!x.size),'listeners removed');ok(t.observer[0].disconnected,'resize observer removed');
 }
 {
  const t=setup(file),s=t.create({loop:true});s.go(s.pages-1);s.advance(1);ok(s.position()===0,'rewind next');s.advance(-1);ok(s.position()===s.max,'rewind previous');s.destroy();
 }
 {
  const t=setup(file),s=t.create({speed:450});s.advance(1);t.flush(225);ok(s.position()>0&&s.position()<s.step,'animated intermediate position');t.flush(225);ok(Math.abs(s.position()-s.step)<.01&&!s.anim,'animation completes');s.destroy();
 }
 {
  const t=setup(file),s=t.create({autoplay:true,loop:true});ok(t.timers.size===1,'autoplay timer');s.pause('focus',true);ok(t.timers.size===0,'focus pauses');s.pause('focus',false);ok(t.timers.size===1,'focus resumes');s.pause('hidden',true);ok(t.timers.size===0,'hidden pauses');s.pause('hidden',false);s.pause('manual',true);ok(t.timers.size===0,'manual pauses');s.destroy();ok(t.timers.size===0,'destroy clears timers');
 }
 {
  const t=setup(file,true),s=t.create();s.down({pointerType:'mouse',button:0,target:t.viewport,clientX:100,pointerId:1});let prevented=false;s.move({clientX:160,preventDefault(){prevented=true}});ok(prevented&&s.position()===60,'RTL drag');s.up();ok(s.suppress&&!s.drag,'drag suppresses click');s.destroy();
 }
 {
  const t=setup(file,false,'negative',1,1,true),s=t.create({autoplay:true});ok(s.pages===1&&t.dots.hidden,'one-slide dots hidden');ok(t.timers.size===0,'one slide no timer');s.destroy();
 }
 {
  const t=setup(file,false,'negative',3,1,true),s=t.create();s.go(1);ok(t.track.children[0].inert&&!t.track.children[1].inert,'only active banner interactive');ok(t.dots.children[0].textContent.includes('الف'),'numbered titled navigation');s.destroy();ok(t.track.children.every(x=>!x.inert),'destroy releases inert');
 }
 {
  const t=setup(file);t.media.matches=true;const s=t.create({autoplay:true,speed:450});ok(t.timers.size===0,'reduced motion stops autoplay');s.advance(1);ok(!s.anim,'reduced motion instant');s.destroy();
 }
 {
  const t=setup(file);t.ctx.window.ECC.initAll(t.root);const n=t.viewport.listeners.scroll.size;t.ctx.window.ECC.initAll(t.root);ok(t.viewport.listeners.scroll.size===n,'idempotent initialization');t.ctx.window.ECC.destroyAll(t.root);ok(t.viewport.listeners.scroll.size===0,'global destroy');t.ctx.window.ECC.initAll(t.root);ok(t.viewport.listeners.scroll.size===1,'reinitialization');t.ctx.window.ECC.destroyAll(t.root);
 }
 {
  const t=setup(file);const s=t.create();t.viewport.clientWidth=800;s.measure();s.sync();ok(t.dots.children[s.active].getAttribute('aria-current')==='true','resized dots active state');s.destroy();
 }
 {
  const t=setup(file);t.root.children=t.root.children.filter(x=>!x.classes.has('lumi-arrows')&&!x.classes.has('lumi-dots'));
  const s=t.create({dots:false});ok(!s.nav&&!s.dotButtons.length,'all optional navigation absent');s.advance(1);ok(s.active===1,'navigation-free keyboard engine');s.destroy();ok(!t.root.dataset.lumiInit,'navigation-free teardown');
 }
 {
  const t=setup(file);const s=t.create({nav:'numbers'});ok(t.dots.children[0].textContent.length>0,'category numbers rendered');ok(!t.dots.children[0].classes.has('lumi-number'),'category numbers do not inherit banner styling');s.go(2);ok(t.dots.children[2].getAttribute('aria-current')==='true','category numbered active page');s.destroy();
 }
 {
  const t=setup(file,false,'negative',0);t.ctx.window.ECC.initAll(t.root);ok(!t.root.dataset.lumiInit,'zero slides no error');
  t.root.dataset.settings='{bad';t.ctx.window.ECC.initAll(t.root);ok(!t.root.dataset.lumiInit,'invalid JSON remains unenhanced');
 }
}
console.log(JSON.stringify({passed_assertions:assertions,environment:'Node VM with simulated DOM/layout; not a browser or WordPress integration test'},null,2));
