<?php
/** Shared native Elementor controls and render helpers. @package Lumi */
defined( 'ABSPATH' ) || exit;

/** Common API with compact, conditional controls. */
abstract class LUMI_Widget extends \Elementor\Widget_Base {
	/** @var array Unsanitized input snapshot; reading controls here would recurse. */
	protected $lumi_saved_settings = array();

	/** Seed migration before Elementor initializes its globally cached control stack. @param array $data Widget data. @param array|null $args Widget arguments. */
	public function __construct( $data = array(), $args = null ) {
		$this->lumi_saved_settings = isset( $data['settings'] ) && is_array( $data['settings'] ) ? $data['settings'] : array();
		if ( $this->lumi_saved_settings ) {
			$settings = $this->lumi_saved_settings;
			if ( empty( $settings['_lumi_ui_version'] ) ) {
				if ( ! array_key_exists( 'show_arrows', $settings ) ) { $settings['show_arrows'] = ! isset( $settings['arrows'] ) || 'none' !== $settings['arrows'] ? 'yes' : ''; }
				if ( ! array_key_exists( 'dots', $settings ) ) { $settings['dots'] = 'yes'; }
			}
			$settings['_lumi_ui_version'] = '2';
			$data['settings'] = $this->prepare_saved_settings( $settings );
		}
		parent::__construct( $data, $args );
	}

	/** Subclasses may migrate row switches without changing saved content. @param array $settings Input. @return array */
	protected function prepare_saved_settings( $settings ) { return $settings; }

	/** Return the custom category. */
	public function get_categories() { return array( 'lumi' ); }
	/** On-demand style dependencies. */
	public function get_style_depends() { return array( 'lumi-slider' ); }
	/** On-demand script dependencies. */
	public function get_script_depends() { return array( 'lumi-slider' ); }
	/** Search terms. */
	public function get_keywords() { return array( 'lumi', 'slider', 'carousel', 'لومی', 'اسلایدر', 'کروسل' ); }

	/** Register a native responsive control. @param string $id ID. @param array $args Arguments. */
	protected function responsive( $id, $args ) { $this->add_responsive_control( $id, $args ); }

	/** Register a native switcher with optional dependency. @param object $owner Widget/repeater. @param string $id ID. @param string $label Label. @param bool $on Default. @param array $condition Dependency. */
	protected function toggle( $owner, $id, $label, $on = true, $condition = array() ) {
		$owner->add_control( $id, array( 'label' => $label, 'type' => \Elementor\Controls_Manager::SWITCHER, 'default' => $on ? 'yes' : '', 'return_value' => 'yes', 'condition' => $condition ) );
	}

	/** Color control. @param string $id ID. @param string $label Label. @param string $selector Target. @param string $property Property. @param array $condition Dependency. */
	protected function color( $id, $label, $selector, $property = 'color', $condition = array() ) {
		$this->add_control( $id, array( 'label' => $label, 'type' => \Elementor\Controls_Manager::COLOR, 'selectors' => array( $selector => $property . ': {{VALUE}};' ), 'condition' => $condition ) );
	}

	/** Responsive scalar with units. @param string $id ID. @param string $label Label. @param string $selector Target. @param string $property Property. @param int $max Maximum. @param array $units Units. @param array $condition Dependency. @param array $default Default scalar. */
	protected function dimension( $id, $label, $selector, $property, $max = 300, $units = array( 'px', '%' ), $condition = array(), $default = array() ) {
		$this->responsive( $id, array( 'label' => $label, 'type' => \Elementor\Controls_Manager::SLIDER, 'size_units' => $units, 'range' => array( 'px' => array( 'min' => 0, 'max' => $max ), '%' => array( 'min' => 0, 'max' => 100 ) ), 'default' => $default, 'selectors' => array( $selector => $property . ': {{SIZE}}{{UNIT}};' ), 'condition' => $condition ) );
	}

	/** Shared motion controls: optional children only appear after activation. */
	protected function motion_controls() {
		$this->start_controls_section( 'motion', array( 'label' => esc_html__( 'حرکت و ناوبری', 'lumi' ) ) );
		$this->add_control( '_lumi_ui_version', array( 'type' => \Elementor\Controls_Manager::HIDDEN, 'default' => '2' ) );
		$this->toggle( $this, 'show_arrows', esc_html__( 'فلش‌های قبلی و بعدی', 'lumi' ), false );
		$this->responsive( 'arrows', array( 'label' => esc_html__( 'نمایش در دستگاه', 'lumi' ), 'type' => \Elementor\Controls_Manager::SELECT, 'default' => 'flex', 'options' => array( 'flex' => esc_html__( 'نمایش', 'lumi' ), 'none' => esc_html__( 'مخفی', 'lumi' ) ), 'selectors' => array( '{{WRAPPER}} .lumi-arrows' => '--lumi-arrow-display: {{VALUE}};' ), 'condition' => array( 'show_arrows' => 'yes' ) ) );
		$this->toggle( $this, 'dots', esc_html__( 'صفحه‌بندی', 'lumi' ), false );
		if ( 'lumi_slider' === $this->get_name() ) {
			$this->add_control( 'nav_mode', array( 'label' => esc_html__( 'نوع صفحه‌بندی', 'lumi' ), 'type' => \Elementor\Controls_Manager::SELECT, 'default' => 'numbers_titles', 'options' => array( 'numbers' => esc_html__( 'شماره', 'lumi' ), 'numbers_titles' => esc_html__( 'شماره و عنوان', 'lumi' ), 'dots' => esc_html__( 'نقطه', 'lumi' ) ), 'condition' => array( 'dots' => 'yes' ) ) );
		}
		$this->toggle( $this, 'autoplay', esc_html__( 'حرکت خودکار', 'lumi' ), false );
		$this->add_control( 'delay', array( 'label' => esc_html__( 'زمان هر اسلاید (میلی‌ثانیه)', 'lumi' ), 'type' => \Elementor\Controls_Manager::NUMBER, 'default' => 5000, 'min' => 1000, 'step' => 100, 'placeholder' => '5000', 'condition' => array( 'autoplay' => 'yes' ) ) );
		$this->toggle( $this, 'hover_pause', esc_html__( 'توقف هنگام هاور', 'lumi' ), true, array( 'autoplay' => 'yes' ) );
		$this->toggle( $this, 'loop', esc_html__( 'برگشت از پایان به ابتدا', 'lumi' ), true );
		$this->add_control( 'speed', array( 'label' => esc_html__( 'مدت انتقال (میلی‌ثانیه)', 'lumi' ), 'type' => \Elementor\Controls_Manager::NUMBER, 'default' => 450, 'min' => 0, 'max' => 3000, 'step' => 50, 'placeholder' => '450' ) );
		$this->toggle( $this, 'drag', esc_html__( 'کشیدن با ماوس', 'lumi' ), true );
		$this->end_controls_section();
	}

	/** Essential image appearance, modeled on the supplied carousel. @param string $id Prefix. @param string $target Media wrapper. @param string $size_name Image-size group. @param array $condition Dependency. */
	protected function image_styles( $id, $target, $size_name = 'image', $condition = array() ) {
		$sel = '{{WRAPPER}} ' . $target;
		$this->start_controls_section( $id . '_style', array( 'label' => esc_html__( 'تصویر', 'lumi' ), 'tab' => \Elementor\Controls_Manager::TAB_STYLE, 'condition' => $condition ) );
		$this->add_group_control( \Elementor\Group_Control_Image_Size::get_type(), array( 'name' => $size_name, 'label' => esc_html__( 'رزولوشن تصویر', 'lumi' ), 'default' => 'woocommerce_thumbnail', 'exclude' => array( 'custom' ) ) );
		$this->add_control( 'image_ratio', array( 'label' => esc_html__( 'نسبت تصویر', 'lumi' ), 'type' => \Elementor\Controls_Manager::SELECT, 'default' => '1 / 1', 'condition' => array( 'shape!' => 'circle' ), 'options' => array( '1 / 1' => '1:1', '4 / 3' => '4:3', '3 / 2' => '3:2', '16 / 9' => '16:9', '3 / 4' => '3:4' ), 'selectors' => array( $sel => 'aspect-ratio: {{VALUE}};' ) ) );
		$this->responsive( $id . '_radius', array( 'label' => esc_html__( 'گردی گوشه‌ها', 'lumi' ), 'type' => \Elementor\Controls_Manager::DIMENSIONS, 'size_units' => array( '%', 'px' ), 'condition' => array( 'shape!' => 'circle' ), 'selectors' => array( $sel => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};' ) ) );
		$this->color( $id . '_bg', esc_html__( 'رنگ پس‌زمینه', 'lumi' ), $sel, 'background-color' );
		$this->add_group_control( \Elementor\Group_Control_Border::get_type(), array( 'name' => $id . '_border_normal', 'selector' => $sel ) );
		$this->add_group_control( \Elementor\Group_Control_Box_Shadow::get_type(), array( 'name' => $id . '_shadow', 'selector' => $sel ) );
		$this->toggle( $this, $id . '_hover_enabled', esc_html__( 'زوم هنگام هاور', 'lumi' ), false );
		$this->add_control( $id . '_zoom', array( 'label' => esc_html__( 'میزان زوم', 'lumi' ), 'type' => \Elementor\Controls_Manager::NUMBER, 'default' => 1.05, 'min' => 1, 'max' => 1.3, 'step' => 0.01, 'selectors' => array( '{{WRAPPER}} .lumi-card:hover ' . $target . ' img' => 'transform: scale({{VALUE}});' ), 'condition' => array( $id . '_hover_enabled' => 'yes' ) ) );
		$this->end_controls_section();
	}

	/** Compact typography/color/distance section. @param string $id Prefix. @param string $label Label. @param string $target Selector. @param array $condition Dependency. */
	protected function text_styles( $id, $label, $target, $condition = array() ) {
		$sel = '{{WRAPPER}} ' . $target;
		$this->start_controls_section( $id . '_style', array( 'label' => $label, 'tab' => \Elementor\Controls_Manager::TAB_STYLE, 'condition' => $condition ) );
		$this->add_group_control( \Elementor\Group_Control_Typography::get_type(), array( 'name' => $id . '_font', 'selector' => $sel ) );
		$this->color( $id . '_color', esc_html__( 'رنگ', 'lumi' ), $sel );
		$this->color( $id . '_hover', esc_html__( 'رنگ هاور', 'lumi' ), '{{WRAPPER}} .lumi-card:hover ' . $target );
		$this->dimension( $id . '_distance', esc_html__( 'فاصله', 'lumi' ), $sel, 'margin-block-start', 100, array( 'px' ) );
		if ( preg_match( '/^text([1-4])$/', $id, $match ) ) {
			$n = $match[1];
			$this->dimension( 'icon' . $n . '_size', esc_html__( 'اندازه آیکن', 'lumi' ), $sel . ' .lumi-icon', 'font-size', 80, array( 'px' ), array( 'lumi_has_icon_' . $n => 'yes' ) );
			$this->color( 'icon' . $n . '_color', esc_html__( 'رنگ آیکن', 'lumi' ), $sel . ' .lumi-icon', 'color', array( 'lumi_has_icon_' . $n => 'yes' ) );
		}
		$this->end_controls_section();
	}

	/** Compact shared button appearance. @param int $n Button number. */
	protected function button_styles( $n ) {
		$sel = '{{WRAPPER}} .lumi-button-' . $n;
		$this->start_controls_section( 'button' . $n . '_style', array( 'label' => sprintf( esc_html__( 'دکمه %s', 'lumi' ), $n ), 'tab' => \Elementor\Controls_Manager::TAB_STYLE, 'condition' => array( 'lumi_has_button_' . $n => 'yes' ) ) );
		$this->add_group_control( \Elementor\Group_Control_Typography::get_type(), array( 'name' => 'button' . $n . '_text_font', 'selector' => $sel ) );
		$this->start_controls_tabs( 'button' . $n . '_colors' );
		foreach ( array( 'normal' => esc_html__( 'عادی', 'lumi' ), 'hover' => esc_html__( 'هاور', 'lumi' ) ) as $state => $label ) {
			$target = $sel . ( 'hover' === $state ? ':hover' : '' );
			$this->start_controls_tab( 'button' . $n . '_' . $state, array( 'label' => $label ) );
			$this->color( 'button' . $n . '_color_' . $state, esc_html__( 'رنگ متن', 'lumi' ), $target );
			$this->color( 'button' . $n . '_background_' . $state, esc_html__( 'پس‌زمینه', 'lumi' ), $target, 'background-color' );
			$this->end_controls_tab();
		}
		$this->end_controls_tabs();
		$this->dimension( 'button' . $n . '_radius', esc_html__( 'گردی گوشه‌ها', 'lumi' ), $sel, 'border-radius', 60, array( 'px' ) );
		$this->end_controls_section();
	}

	/** Separate arrow controls from pagination; no redundant border/padding controls. */
	protected function nav_styles() {
		$condition = array( 'show_arrows' => 'yes' );
		$this->start_controls_section( 'nav_style', array( 'label' => esc_html__( 'فلش‌ها', 'lumi' ), 'tab' => \Elementor\Controls_Manager::TAB_STYLE, 'condition' => $condition ) );
		foreach ( array( 'prev' => esc_html__( 'آیکن قبلی', 'lumi' ), 'next' => esc_html__( 'آیکن بعدی', 'lumi' ) ) as $key => $label ) {
			$this->add_control( 'arrow_icon_' . $key, array( 'label' => $label, 'type' => \Elementor\Controls_Manager::ICONS ) );
		}
		$this->dimension( 'arrow_size', esc_html__( 'اندازه دکمه', 'lumi' ), '{{WRAPPER}} .lumi-arrow', '--lumi-arrow-size', 80, array( 'px' ) );
		$this->dimension( 'arrow_icon_size', esc_html__( 'اندازه آیکن', 'lumi' ), '{{WRAPPER}} .lumi-arrow', '--lumi-arrow-icon-size', 48, array( 'px' ) );
		$this->start_controls_tabs( 'arrow_colors' );
		foreach ( array( 'normal' => esc_html__( 'عادی', 'lumi' ), 'hover' => esc_html__( 'هاور', 'lumi' ) ) as $state => $label ) {
			$sel = '{{WRAPPER}} .lumi-arrow' . ( 'hover' === $state ? ':hover' : '' );
			$this->start_controls_tab( 'arrow_' . $state, array( 'label' => $label ) );
			$this->color( 'hover' === $state ? 'arrow_hover_color' : 'arrow_color', esc_html__( 'رنگ آیکن', 'lumi' ), $sel );
			$this->color( 'hover' === $state ? 'arrow_hover_bg' : 'arrow_bg', esc_html__( 'پس‌زمینه', 'lumi' ), $sel, 'background-color' );
			$this->end_controls_tab();
		}
		$this->end_controls_tabs();
		$this->responsive( 'arrow_layout', array( 'label' => esc_html__( 'چیدمان', 'lumi' ), 'type' => \Elementor\Controls_Manager::SELECT, 'default' => 'space-between', 'options' => array( 'space-between' => esc_html__( 'دو طرف', 'lumi' ), 'flex-start' => esc_html__( 'کنار هم، ابتدا', 'lumi' ), 'center' => esc_html__( 'کنار هم، وسط', 'lumi' ), 'flex-end' => esc_html__( 'کنار هم، انتها', 'lumi' ) ), 'selectors' => array( '{{WRAPPER}} .lumi-arrows' => 'justify-content: {{VALUE}};' ) ) );
		$this->dimension( 'arrow_top', esc_html__( 'جایگاه عمودی', 'lumi' ), '{{WRAPPER}} .lumi-arrows', 'inset-block-start', 100, array( '%' ) );
		$this->end_controls_section();
		$this->start_controls_section( 'pagination_style', array( 'label' => esc_html__( 'صفحه‌بندی', 'lumi' ), 'tab' => \Elementor\Controls_Manager::TAB_STYLE, 'condition' => array( 'dots' => 'yes' ) ) );
		if ( 'lumi_category_carousel' === $this->get_name() ) {
			// Presets generate native Elementor CSS; no additional frontend stylesheet.
			$this->add_control( 'category_pagination', array( 'label' => esc_html__( 'نوع نمایش', 'lumi' ), 'type' => \Elementor\Controls_Manager::SELECT, 'default' => 'dots', 'options' => array( 'dots' => esc_html__( 'نقطه‌ای', 'lumi' ), 'lines' => esc_html__( 'خطی', 'lumi' ), 'capsules' => esc_html__( 'کپسولی', 'lumi' ), 'numbers' => esc_html__( 'شماره‌ای', 'lumi' ) ), 'selectors_dictionary' => array( 'dots' => 'border-radius:50%;', 'lines' => 'width:calc(var(--lumi-dot-size,8px)*3);height:3px;aspect-ratio:auto;border-radius:2px;', 'capsules' => 'width:calc(var(--lumi-dot-size,8px)*3);aspect-ratio:auto;border-radius:99px;', 'numbers' => 'width:calc(var(--lumi-dot-size,8px) + 16px);height:calc(var(--lumi-dot-size,8px) + 16px);font-size:12px;color:#fff;border-radius:50%;' ), 'selectors' => array( '{{WRAPPER}} .lumi-categories .lumi-dot' => '{{VALUE}}' ) ) );
			$this->responsive( 'pagination_align', array( 'label' => esc_html__( 'جایگاه', 'lumi' ), 'type' => \Elementor\Controls_Manager::SELECT, 'default' => 'center', 'options' => array( 'flex-start' => esc_html__( 'ابتدا', 'lumi' ), 'center' => esc_html__( 'وسط', 'lumi' ), 'flex-end' => esc_html__( 'انتها', 'lumi' ) ), 'selectors' => array( '{{WRAPPER}} .lumi-categories .lumi-dots' => 'justify-content: {{VALUE}};' ) ) );
		}
		$this->dimension( 'dot_size', esc_html__( 'اندازه', 'lumi' ), '{{WRAPPER}} .lumi-dots', '--lumi-dot-size', 20, array( 'px' ) );
		$this->dimension( 'dot_gap', esc_html__( 'فاصله', 'lumi' ), '{{WRAPPER}} .lumi-dots', 'gap', 50, array( 'px' ) );
		$this->color( 'dot_color', esc_html__( 'رنگ', 'lumi' ), '{{WRAPPER}} .lumi-dots', '--lumi-dot-color' );
		$this->color( 'dot_active', esc_html__( 'رنگ فعال', 'lumi' ), '{{WRAPPER}} .lumi-dots', '--lumi-dot-active' );
		$this->end_controls_section();
	}

	/** Validate an allowed title tag. @param string $tag Tag input. @return string */
	protected function tag( $tag ) {
		return in_array( $tag, array( 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'p', 'div', 'span' ), true ) ? $tag : 'div';
	}

	/** Render escaped title markup. @param string $tag Tag. @param string $class CSS class. @param string $text Content. @param array $icon Native icon. @param string $position Before/after. */
	protected function title( $tag, $class, $text, $icon = array(), $position = 'before' ) {
		if ( '' === trim( (string) $text ) ) { return; }
		$tag = $this->tag( $tag );
		echo '<' . esc_html( $tag ) . ' class="' . esc_attr( $class ) . '"><span class="lumi-title-inner">';
		if ( 'after' !== $position ) { $this->icon( $icon ); }
		echo '<span>' . esc_html( $text ) . '</span>';
		if ( 'after' === $position ) { $this->icon( $icon ); }
		echo '</span></' . esc_html( $tag ) . '>';
	}

	/** Render Elementor's validated icon output. @param array $icon Native icon selection. */
	protected function icon( $icon ) {
		if ( ! empty( $icon['value'] ) ) {
			echo '<span class="lumi-icon" aria-hidden="true">';
			\Elementor\Icons_Manager::render_icon( $icon, array( 'aria-hidden' => 'true' ) );
			echo '</span>';
		}
	}

	/** Render a WordPress responsive image with real dimensions. @param int $id Attachment. @param string $size Size. @param string $alt Alt. @param string $class Class. @param bool $eager Above-fold intent. */
	protected function image( $id, $size, $alt, $class, $eager = false ) {
		$attrs = array( 'class' => $class, 'alt' => $alt, 'loading' => $eager ? 'eager' : 'lazy', 'decoding' => 'async' );
		if ( $eager ) { $attrs['fetchpriority'] = 'high'; }
		$html = $id ? wp_get_attachment_image( absint( $id ), $size, false, $attrs ) : '';
		if ( $html ) {
			echo wp_kses_post( $html );
		} else {
			echo '<img class="' . esc_attr( $class ) . '" src="' . esc_url( wc_placeholder_img_src( $size ) ) . '" alt="' . esc_attr( $alt ) . '" width="300" height="300" loading="lazy" decoding="async">';
		}
	}

	/** Print complete native URL attributes, including custom attributes. @param string $key Unique render key. @param array $link Native URL control. @param string $class CSS class. */
	protected function link_attrs( $key, $link, $class ) {
		$this->add_render_attribute( $key, 'class', $class );
		$link['url'] = ! empty( $link['url'] ) ? esc_url( $link['url'] ) : '#';
		$this->add_link_attributes( $key, $link );
		$this->print_render_attribute_string( $key );
	}

	/** Create the region and single engine JSON. @param array $s Settings. @param bool $banner Banner mode. @param array $labels Navigation labels. */
	protected function open_slider( $s, $banner = false, $labels = array() ) {
		$settings = array( 'editor' => \Elementor\Plugin::$instance->editor->is_edit_mode() || \Elementor\Plugin::$instance->preview->is_preview_mode(), 'banner' => $banner, 'autoplay' => 'yes' === $s['autoplay'], 'delay' => max( 1000, (int) $s['delay'] ), 'speed' => max( 0, min( 3000, (int) $s['speed'] ) ), 'hover' => 'yes' === $s['hover_pause'], 'loop' => 'yes' === $s['loop'], 'drag' => 'yes' === $s['drag'], 'dots' => 'yes' === $s['dots'], 'labels' => $labels, 'dotLabel' => __( 'رفتن به صفحه %s', 'lumi' ), 'slideLabel' => __( '%1$s از %2$s', 'lumi' ), 'pauseLabel' => __( 'توقف پخش', 'lumi' ), 'playLabel' => __( 'ادامه پخش', 'lumi' ) );
		if ( $banner ) {
			$settings['nav'] = isset( $s['nav_mode'] ) ? $s['nav_mode'] : 'numbers';
		}
		if ( ! $banner ) { $settings['nav'] = isset( $s['category_pagination'] ) ? $s['category_pagination'] : 'dots'; }
		$label = ! empty( $s['aria_label'] ) ? $s['aria_label'] : $this->get_title();
		echo '<section class="lumi-slider ' . ( $banner ? 'lumi-banner' : 'lumi-categories' ) . '" dir="' . ( is_rtl() ? 'rtl' : 'ltr' ) . '" role="region" aria-roledescription="' . esc_attr__( 'کروسل', 'lumi' ) . '" aria-label="' . esc_attr( $label ) . '" data-settings="' . esc_attr( wp_json_encode( $settings ) ) . '">';
		echo '<div class="lumi-viewport" tabindex="0"><div class="lumi-track">';
	}

	/** Render only enabled controls; an empty navigation wrapper is never emitted. @param bool $banner Banner. @param array $s Settings. */
	protected function close_slider( $banner = false, $s = array() ) {
		echo '</div></div>';
		if ( ! empty( $s['show_arrows'] ) && 'yes' === $s['show_arrows'] ) {
			echo '<div class="lumi-arrows">';
			foreach ( array( 'prev' => __( 'قبلی', 'lumi' ), 'next' => __( 'بعدی', 'lumi' ) ) as $action => $label ) {
				$icon = isset( $s[ 'arrow_icon_' . $action ] ) ? $s[ 'arrow_icon_' . $action ] : array();
				echo '<button type="button" class="lumi-arrow lumi-' . esc_attr( $action ) . '" data-action="' . esc_attr( $action ) . '" aria-label="' . esc_attr( $label ) . '">';
				if ( ! empty( $icon['value'] ) ) { $this->icon( $icon ); }
				else { echo '<svg class="lumi-default-arrow" viewBox="0 0 24 24" aria-hidden="true"><path d="M9 5l7 7-7 7"/></svg>'; }
				echo '</button>';
			}
			echo '</div>';
		}
		$pagination = isset( $s['dots'] ) && 'yes' === $s['dots'];
		$playing = $banner && isset( $s['autoplay'] ) && 'yes' === $s['autoplay'];
		if ( $pagination || $playing ) {
			echo '<div class="lumi-navigation" hidden>';
			if ( $pagination ) { echo '<div class="lumi-dots" role="group" aria-label="' . esc_attr__( 'ناوبری اسلایدها', 'lumi' ) . '"></div>'; }
			if ( $playing ) {
				echo '<button class="lumi-pause" type="button" data-action="pause" aria-label="' . esc_attr__( 'توقف پخش', 'lumi' ) . '" aria-pressed="false"><span aria-hidden="true">Ⅱ</span></button><span class="lumi-progress" aria-hidden="true"><span></span></span>';
			}
			echo '</div>';
		}
		if ( isset( $s['autoplay'] ) && 'yes' !== $s['autoplay'] ) { echo '<span class="lumi-live" aria-live="polite" aria-atomic="true"></span>'; }
		echo '</section>';
	}
}
