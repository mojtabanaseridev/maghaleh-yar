<?php
namespace Mojtabanaseri\ArticleProducts;
if(!defined('ABSPATH')){
    exit;
}
final class Admin {
    public static function is_page(){
        return isset($_GET['page'])&&is_string($_GET['page'])&&0===strpos($_GET['page'],'mnps-');
    }
    public static function init(){
        if(!current_user_can('edit_posts')){
            return;
        }
        Store::install();
        if(self::is_page()){
            Store::batch();
            add_action('in_admin_header',array(__CLASS__,'quiet_notices'),9999);
            add_filter('admin_body_class',function($classes){return $classes.' mnps-screen';});
        }
        $id=absint($_GET['post']??0);
        if(!wp_doing_ajax()&&!isset($_POST['action'])&&(($id&&'mnps_group'===get_post_type($id)&&'post.php'===($GLOBALS['pagenow']??''))||('post-new.php'===($GLOBALS['pagenow']??'')&&'mnps_group'===($_GET['post_type']??'')))){
            wp_safe_redirect($id?self::edit_url($id):admin_url('admin.php?page=mnps-editor&type='.('cta'===($_GET['mnps_type']??'')?'cta':'products')));
            exit;
        }
    }
    /** Keep the editor free of unrelated banners, on our screens only. */
    public static function quiet_notices(){
        if(!self::is_page()){return;}
        foreach(array('admin_notices','all_admin_notices','network_admin_notices','user_admin_notices')as$hook){
            remove_all_actions($hook);
        }
        add_action('admin_notices',array(Plugin::boot(),'notices'));
    }
    public static function edit_url($id,$key=''){
        return admin_url('admin.php?page=mnps-editor&post='.absint($id).($key?'&group='.rawurlencode($key):''));
    }
    public static function toolbar($bar){
        if(is_admin()||!is_singular()||!current_user_can('edit_post',get_queried_object_id())||!in_array(get_option('mnps_schema'),array('1','2','3'),true)){
            return;
        }
        global $wpdb;
        $rows=$wpdb->get_results($wpdb->prepare("SELECT b.id,b.source_post,b.group_key FROM {$wpdb->prefix}mnps_boxes b INNER JOIN {$wpdb->prefix}mnps_usage u ON u.box_id=b.id WHERE u.post_id=%d AND b.active=1 ORDER BY b.id LIMIT 50",get_queried_object_id()));
        $links=array();
        foreach($rows as$row){
            if(!current_user_can('edit_post',$row->source_post)){
                continue;
            }
            foreach(Plugin::boot()->groups($row->source_post)as$g){
                if($g['key']!==$row->group_key){
                    continue;
                }
                $links[]=array('id'=>'mnps-edit-'.$row->id,'title'=>__('ویرایش: ', 'mojtabanaseri-article-products').($g['title']?:get_the_title($row->source_post)),'href'=>self::edit_url($row->source_post,$row->group_key));
                break;
            }
        }
        if(!$links){
            return;
        }
        $bar->add_node(array('id'=>'mnps-edit-boxes','title'=>count($links)>1?__('ویرایش باکس‌های مقاله', 'mojtabanaseri-article-products'):__('ویرایش باکس مقاله', 'mojtabanaseri-article-products'),'href'=>$links[0]['href']));
        foreach($links as$link){
            $link['parent']='mnps-edit-boxes';
            $bar->add_node($link);
        }
    }
    public static function menu(){
        add_menu_page(__('مقاله‌یار', 'mojtabanaseri-article-products'),__('مقاله‌یار', 'mojtabanaseri-article-products'),'edit_posts','mnps-home',array(__CLASS__,'dashboard'),'dashicons-layout',26);
        foreach(array('mnps-home'=>array(__('مدیریت باکس‌ها', 'mojtabanaseri-article-products'),'dashboard'),'mnps-editor'=>array(__('ساخت باکس', 'mojtabanaseri-article-products'),'editor'),'mnps-templates'=>array(__('طرح‌های آماده', 'mojtabanaseri-article-products'),'gallery'),'mnps-modules'=>array(__('ماژول‌ها', 'mojtabanaseri-article-products'),'modules'),'mnps-settings'=>array(__('تنظیمات', 'mojtabanaseri-article-products'),'settings'),'mnps-backup'=>array(__('بکاپ و بازیابی', 'mojtabanaseri-article-products'),'backup'),'mnps-connection'=>array(__('ارتباط و اعلان‌ها', 'mojtabanaseri-article-products'),'connection'),'mnps-help'=>array(__('راهنما', 'mojtabanaseri-article-products'),'help'))as$slug=>$r){
            add_submenu_page('mnps-home',$r[0],$r[0],in_array($slug,array('mnps-settings','mnps-backup','mnps-connection','mnps-modules'),true)?'manage_options':'edit_posts',$slug,array(__CLASS__,$r[1]));
        }
        add_submenu_page(null,__('ساخت باکس', 'mojtabanaseri-article-products'),__('ساخت باکس', 'mojtabanaseri-article-products'),'edit_posts','mnps-new',array(__CLASS__,'editor'));
    }
    private static function header($title,$text,$show_title=true){
        echo '<div class="wrap mnps-app" dir="rtl">'; Plugin::boot()->notices(true); echo '<header class="mnps-app-header"><a class="mnps-brand" href="'.esc_url(admin_url('admin.php?page=mnps-home')).'"><span class="mnps-brand-symbol" aria-hidden="true"><img src="'.esc_url(MNPS_URL.'assets/logo.webp').('" alt="">'.'</span>'.'<span class="mnps-brand-name">'.esc_html__('مقاله‌یار', 'mojtabanaseri-article-products').'</span>'.'</a>'.'<nav class="mnps-app-tabs" aria-label="'.esc_attr__('صفحات مقاله‌یار', 'mojtabanaseri-article-products').'">');
        foreach(array('mnps-home'=>__('مدیریت باکس‌ها', 'mojtabanaseri-article-products'),'mnps-editor'=>__('ساخت باکس', 'mojtabanaseri-article-products'),'mnps-templates'=>__('طرح‌های آماده', 'mojtabanaseri-article-products'),'mnps-modules'=>__('ماژول‌ها', 'mojtabanaseri-article-products'),'mnps-settings'=>__('تنظیمات', 'mojtabanaseri-article-products'),'mnps-backup'=>__('بکاپ', 'mojtabanaseri-article-products'),'mnps-connection'=>__('ارتباط', 'mojtabanaseri-article-products'),'mnps-help'=>__('راهنما', 'mojtabanaseri-article-products'))as$slug=>$label){
            if(in_array($slug,array('mnps-settings','mnps-backup','mnps-connection','mnps-modules'),true)&&!current_user_can('manage_options')){
                continue;
            }
            echo '<a '.($slug===($_GET['page']??'')?'aria-current="page" ':'').'href="'.esc_url(admin_url('admin.php?page='.$slug)).'">'.esc_html($label).'</a>';
        }
        $version=('<span class="mnps-version" dir="ltr">'.esc_html__('نسخه ', 'mojtabanaseri-article-products')).esc_html(strtr(str_replace(array('-beta.1','-beta.2'),array(__(' آزمایشی ۱', 'mojtabanaseri-article-products'),__(' آزمایشی ۲', 'mojtabanaseri-article-products')),MNPS_VERSION),array('0'=>__('۰', 'mojtabanaseri-article-products'),'1'=>__('۱', 'mojtabanaseri-article-products'),'2'=>__('۲', 'mojtabanaseri-article-products'),'3'=>__('۳', 'mojtabanaseri-article-products'),'4'=>__('۴', 'mojtabanaseri-article-products'),'5'=>__('۵', 'mojtabanaseri-article-products'),'6'=>__('۶', 'mojtabanaseri-article-products'),'7'=>__('۷', 'mojtabanaseri-article-products'),'8'=>__('۸', 'mojtabanaseri-article-products'),'9'=>__('۹', 'mojtabanaseri-article-products'),'.'=>__('٫', 'mojtabanaseri-article-products')))).'</span>';
        echo '</nav><div class="mnps-header-actions">'.$version;
        echo '<a class="mnps-primary mnps-header-new" href="'.esc_url(self::edit_url(0)).'">+ ساخت باکس جدید</a>';
        if(in_array($_GET['page']??'',array('mnps-editor','mnps-new'),true)){
            echo ('<span id="mnps-header-status" class="mnps-save-state">'.esc_html__('آماده ساخت', 'mojtabanaseri-article-products').'</span>'.'<button type="button" class="mnps-primary" data-editor-save>').Appearance::icon('save').(esc_html__(' ذخیره باکس', 'mojtabanaseri-article-products').'</button>');
        }
        else{
            echo '';
        }
        echo '</div></header>';
        if($show_title){
            echo '<div class="mnps-page-title"><div><h1>'.esc_html($title).'</h1><p>'.esc_html($text).'</p></div></div>';
        }
    }
    private static function end(){
        echo ('<footer class="mnps-support">'.'<span>'.esc_html__('به‌دست: ', 'mojtabanaseri-article-products').'<bdi>'.'mojtabanaseri'.'</bdi>'.'</span>'.'<a href="tel:+989367800550">'.esc_html__('تماس: ', 'mojtabanaseri-article-products').'<bdi>'.'09367800550'.'</bdi>'.'</a>'.'<a href="mailto:mojtabanaseri157@gmail.com">'.esc_html__('ایمیل: ', 'mojtabanaseri-article-products').'<bdi>'.'mojtabanaseri157@gmail.com'.'</bdi>'.'</a>'.'</footer>'.'</div>');
    }
    public static function hydrate($id,$groups=null){
        $groups=null===$groups?Plugin::boot()->groups($id):$groups;
        if($id){
            foreach($groups as$g){
                if(!Store::id($id,$g['key'])){
                    Store::sync($id,$groups);
                    break;
                }
            }
        }
        foreach($groups as&$g){
            $default=Plugin::boot()->normalize(array(array('type'=>$g['type']??'products')))[0];
            $image_position=$g['image_position']??(($g['cta']['layout']??'horizontal')==='vertical'?'top':'right');
            $g=array_merge($default,$g);$g['image_position']=$image_position;
            $g['cta']=Appearance::cta($g['cta']);
            foreach($g['items']as&$item){
                $p=function_exists('wc_get_product')?wc_get_product($item['id']):false;
                $item['name']=$p?$p->get_name():__('محصول در دسترس نیست', 'mojtabanaseri-article-products');
                $item['image']=$p?(wp_get_attachment_image_url($p->get_image_id(),'thumbnail')?:''):'';
                $item['hide_description']=!empty($item['hide_description']);
            }
            unset($item);
            $g['archive']=ProductOptions::clean_archive($g['archive']??array());
            $g['archive']['icon_url']=$g['archive']['icon']?wp_get_attachment_url($g['archive']['icon']):'';
            foreach(array('title_icon','button_icon','left_icon','right_icon')as$k){
                $g[$k.'_url']=!empty($g[$k])?wp_get_attachment_url($g[$k]):'';
            }
            foreach(array('image','icon_media')as$k){
                $g['cta'][$k.'_url']=$g['cta'][$k]?wp_get_attachment_image_url($g['cta'][$k],'medium'):'';
            }
            foreach($g['table']['rows']??array()as$i=>$row){foreach($row['cells']as$j=>$cell)$g['table']['rows'][$i]['cells'][$j]['image_url']=!empty($cell['image'])?wp_get_attachment_image_url($cell['image'],'thumbnail'):'';}
            $g['code']=$id?Store::code($id,$g['key']):'';
        }
        unset($g);
        return $groups;
    }
    public static function fingerprint($id){
        return hash('sha256',wp_json_encode(Plugin::boot()->groups($id)));
    }
    public static function manager($id,$standalone=true,$groups=null){
        echo '<div id="mnps-manager" class="mnps-admin" data-post="'.absint($id).'" data-standalone="'.($standalone?'1':'0').'" data-hash="'.esc_attr(self::fingerprint($id)).'" data-group="'.esc_attr(sanitize_key($_GET['group']??'')).'"><input type="hidden" id="mnps-data" name="mnps_data" value="'.esc_attr(wp_json_encode(self::hydrate($id,$groups),JSON_UNESCAPED_UNICODE)).'"><div class="mnps-toolbar">';
        if($standalone){
            echo ('<label class="mnps-field mnps-name">'.'<span>'.esc_html__('نام باکس در آرشیو', 'mojtabanaseri-article-products').'</span>'.'<input id="mnps-box-name" maxlength="200" placeholder="'.esc_attr__('مثلاً پیشنهاد محصولات برای مقاله زرشک', 'mojtabanaseri-article-products').'" value="').esc_attr($id?get_the_title($id):'').'"'.($id&&'post'===get_post_type($id)?' readonly':'').'></label>';
        }
        echo '<div class="mnps-box-tabs" id="mnps-box-tabs"></div><div class="mnps-toolbar-actions"><button type="button" class="mnps-secondary" data-action="add-products">'.Appearance::icon('plus').(esc_html__(' محصولات', 'mojtabanaseri-article-products').'</button>'.'<button type="button" class="mnps-secondary" data-action="add-cta">').Appearance::icon('plus').(esc_html__(' دعوت به اقدام', 'mojtabanaseri-article-products').'</button><button type="button" class="mnps-secondary" data-action="add-table">+ '.esc_html__('جدول', 'mojtabanaseri-article-products').'</button>'.'</div>'.'</div>'.'<div id="mnps-groups">'.'</div>'.'<div class="mnps-savebar">');
        $publish=current_user_can('publish_posts')&&(!$id||('mnps_group'===get_post_type($id)&&'publish'!==get_post_status($id)));
        echo $standalone?'<button type="button" class="mnps-primary" data-action="save" data-publish="'.($publish?'1':'0').'">'.($publish?__('ذخیره و انتشار باکس', 'mojtabanaseri-article-products'):__('ذخیره باکس', 'mojtabanaseri-article-products')).'</button>':('<span>'.esc_html__('با ذخیره یا به‌روزرسانی مقاله، باکس‌ها هم ذخیره می‌شوند.', 'mojtabanaseri-article-products').'</span>');
        echo ($standalone?'<button type="button" class="mnps-secondary" data-action="save-draft">ذخیره پیش‌نویس</button>':''); echo '<span id="mnps-status" hidden role="status" aria-live="polite"></span></div></div>';
    }
    public static function editor(){
        $id=absint($_GET['post']??0);
        if($id&&(!current_user_can('edit_post',$id)||!in_array(get_post_type($id),array('post','mnps_group'),true))){
            wp_die(esc_html__('اجازه ویرایش این باکس را نداری.', 'mojtabanaseri-article-products'));
        }
        self::header($id?__('ویرایش باکس', 'mojtabanaseri-article-products'):__('ساخت باکس', 'mojtabanaseri-article-products'),__('محتوا را انتخاب کن؛ نتیجه را هم‌زمان در پیش‌نمایش ببین.', 'mojtabanaseri-article-products'));
        $groups=$id?Plugin::boot()->groups($id):Plugin::boot()->normalize(array(array('type'=>in_array($_GET['type']??'',array('cta','table'),true)?$_GET['type']:'products','archive'=>array('show'=>true),'paint'=>Suite::paint(get_option('mnps_paint',array())),'title_line'=>false,'hide_stock'=>Features::settings()['hide_stock'],'empty'=>Features::settings()['empty'],'empty_text'=>Features::settings()['empty_text'],'font'=>Features::new_font(),'auto'=>array('count'=>Features::settings()['auto_count'],'order'=>Features::settings()['auto_order'],'stock'=>Features::settings()['auto_stock']))));
        self::manager($id,true,$groups);
        self::end();
    }
    public static function thumbnail($g){
        $images='';
        if('cta'===($g['type']??'products')&&!empty($g['cta']['image'])){
            $images=wp_get_attachment_image($g['cta']['image'],'thumbnail',false,array('loading'=>'lazy'));
        }
        elseif(($g['type']??'products')==='table'){return '<span class="mnps-table-mini" aria-label="جدول">▦</span>';}
        elseif(function_exists('wc_get_product')){
            foreach(array_slice(Features::effective($g),0,3)as$item){
                $p=wc_get_product($item['id']);
                if($p){
                    $images.=$p->get_image_id()?$p->get_image('thumbnail',array('loading'=>'lazy')):'<span class="mnps-thumb-placeholder">'.Appearance::icon('bag').'</span>';
                }
            }
        }
        if(!$images){
            for($i=0;$i<3;$i++){
                $images.='<span class="mnps-thumb-placeholder">'.Appearance::icon('bag').'</span>';
            }
        }
        return '<div class="mnps-thumbnail-strip">'.$images.'</div>';
    }
    public static function visibility_badge($summary,$published=true){
        $total=$summary['total'];
        $enabled=$published?$summary['enabled']:0;
        $state=!$total?'unused':(!$enabled?'off':($enabled===$total?'on':'mixed'));
        $label=!$enabled?__('غیرفعال', 'mojtabanaseri-article-products'):($enabled===$total?__('فعال', 'mojtabanaseri-article-products'):__('فعال در برخی مقاله‌ها', 'mojtabanaseri-article-products'));
        return '<span class="mnps-display-state is-'.$state.'" data-total="'.absint($total).'" data-enabled="'.absint($enabled).'" role="status">'.'<i class="mnps-status-dot" aria-hidden="true"></i>'.'<span>'.esc_html($label).'</span></span>';
    }
    private static function inline_usage($box,$published){
        $summary=Store::visibility_summary($box);
        $enabled=$published?$summary['enabled']:0;
        $disabled=$summary['total']-$enabled;
        return '<section class="mnps-inline-usage" data-usage="'.absint($box).'" data-published="'.($published?'1':'0').'"><div class="mnps-visibility-actions"><button type="button" class="mnps-mini-button" data-manage-usage="'.absint($box).'" data-desired="1" '.(!$published?'disabled':'').('>'.esc_html__('فعال‌کردن در مقاله‌ها', 'mojtabanaseri-article-products').'</button>'.'<button type="button" class="mnps-mini-button" data-manage-usage="').absint($box).'" data-desired="0" '.(!$published?'disabled':'').('>'.esc_html__('غیرفعال‌کردن در مقاله‌ها', 'mojtabanaseri-article-products').'</button>'.'</div>'.'<button type="button" class="mnps-mini-button" data-manage-usage="').absint($box).('">'.esc_html__('محل‌های استفاده', 'mojtabanaseri-article-products').'</button>'.'<div class="mnps-usage-counts">'.'<span>'.esc_html__('فعال در ', 'mojtabanaseri-article-products').'<b data-active-count>').absint($enabled).('</b>'.esc_html__(' مقاله', 'mojtabanaseri-article-products').'</span>'.'<span>'.esc_html__('غیرفعال در ', 'mojtabanaseri-article-products').'<b data-inactive-count>').absint($disabled).('</b>'.esc_html__(' مقاله', 'mojtabanaseri-article-products').'</span>'.'</div>'.'<p class="mnps-usage-status" role="status" aria-live="polite">'.'</p>'.'</section>');
    }
    private static function overview(){
        echo ('<div class="mnps-overview-board">'.'<section class="mnps-overview-boxes">'.'<div class="mnps-section-title">'.'<h2>'.esc_html__('باکس‌های من', 'mojtabanaseri-article-products').'</h2>'.'<a class="mnps-mini-button" href="').esc_url(admin_url('admin.php?page=mnps-home')).('">'.esc_html__('دیدن همه باکس‌ها', 'mojtabanaseri-article-products').'</a>'.'</div>');
        $args=array('post_type'=>array('post','mnps_group'),'post_status'=>array('publish','draft','pending','private','future'),'posts_per_page'=>3,'meta_key'=>Plugin::META,'orderby'=>'modified','order'=>'DESC','no_found_rows'=>true);
        if(!current_user_can('edit_others_posts')){
            $args['author']=get_current_user_id();
        }
        $q=new \WP_Query($args);
        $n=0;
        foreach($q->posts as$p){
            if(!current_user_can('edit_post',$p->ID)){
                continue;
            }
            foreach(Plugin::boot()->groups($p->ID)as$g){
                if($n>=3){
                    break 2;
                }
                $n++;
                $box=Store::id($p->ID,$g['key']);
                $summary=Store::visibility_summary($box);
                echo '<article class="mnps-overview-row" data-published="'.('publish'===$p->post_status?'1':'0').'">'.self::thumbnail($g).'<div class="mnps-overview-detail"><h3>'.esc_html($g['title']?:$p->post_title).'</h3>'.self::visibility_badge($summary,'publish'===$p->post_status).'<div class="mnps-toolbar-actions"><a class="mnps-mini-button" href="'.esc_url(self::edit_url($p->ID,$g['key'])).'">'.Appearance::icon('edit').(esc_html__(' ویرایش', 'mojtabanaseri-article-products').'</a>'.'<button type="button" class="mnps-mini-button" data-usage="').absint($box).('">'.esc_html__('محل‌های استفاده', 'mojtabanaseri-article-products').'</button>'.'<button type="button" class="mnps-mini-button" data-mnps-copy="').esc_attr(Store::code($p->ID,$g['key'])).'">'.Appearance::icon('copy').(esc_html__(' کپی شورت‌کد', 'mojtabanaseri-article-products').'</button>'.'</div>'.'</div>'.'</article>');
            }
        }
        if(!$n){
            echo ('<div class="mnps-empty-compact">'.esc_html__('باکس‌های ذخیره‌شده اینجا قرار می‌گیرند.', 'mojtabanaseri-article-products').'</div>');
        }
        echo ('</section>'.'<section class="mnps-overview-templates">'.'<div class="mnps-section-title">'.'<h2>'.esc_html__('طرح‌های آماده', 'mojtabanaseri-article-products').'</h2>'.'<a class="mnps-mini-button" href="').esc_url(admin_url('admin.php?page=mnps-templates')).('">'.esc_html__('آرشیو طرح‌ها', 'mojtabanaseri-article-products').'</a>'.'</div>'.'<div id="mnps-template-archive" class="mnps-template-grid">');
        echo '</div></section></div>';
    }
    public static function dashboard(){
        self::header(__('مدیریت باکس‌ها', 'mojtabanaseri-article-products'),__('باکس‌ها و نمایش آن‌ها در مقاله‌ها را مدیریت کنید.', 'mojtabanaseri-article-products'),false);
        $page=max(1,absint($_GET['mnps_page']??1));
        $search=sanitize_text_field(wp_unslash($_GET['mnps_search']??''));
        $tag=sanitize_text_field(wp_unslash($_GET['mnps_tag']??''));
        $filter=sanitize_key($_GET['mnps_state']??'all');
        if(!in_array($filter,array('all','active','inactive','expired'),true)){
            $filter='all';
        }
        $type=sanitize_key($_GET['mnps_type']??'all');
        if(!in_array($type,array('all','products','cta','table'),true)){
            $type='all';
        }
        $health=!empty($_GET['mnps_health']);
        $query=Store::archive_query($search,$tag,$filter,$type,$health,$page);
        $total=$query['total'];
        $pages=$query['pages'];
        $page=$query['page'];
        $stats=Store::archive_stats();
        $tags=Store::archive_tags();
        $index=Store::archive_index(array_map(function($r){
            return (int)$r->id;
        }
        ,$query['rows']));
        $shown=array();
        foreach($query['rows']as$row){
            $p=get_post($row->source_post);
            if(!$p||!current_user_can('edit_post',$p->ID)){
                continue;
            }
            foreach(Plugin::boot()->groups($p->ID)as$g){
                if($g['key']===$row->group_key&&isset($index[$p->ID.':'.$g['key']])){
                    $shown[]=array($p,$g,$index[$p->ID.':'.$g['key']],'publish'===$p->post_status,$row->title,(int)$row->issues);
                    break;
                }
            }
        }
        echo ('<div id="mnps-archive-page">'.'<div class="mnps-archive-top">'.'<div class="mnps-page-title">'.'<div>'.'<h1>'.esc_html__('مدیریت باکس‌ها', 'mojtabanaseri-article-products').'</h1>'.'<p>'.esc_html__('باکس‌ها و نمایش آن‌ها در مقاله‌ها را مدیریت کنید.', 'mojtabanaseri-article-products').'</p>'.'</div>'.'</div>'.'<form class="mnps-library-search">'.'<input type="hidden" name="page" value="mnps-home">'.'<input type="hidden" name="mnps_state" value="').esc_attr($filter).('">'.'<input type="search" aria-label="'.esc_attr__('جستجوی نام باکس', 'mojtabanaseri-article-products').'" name="mnps_search" placeholder="'.esc_attr__('جستجوی نام باکس…', 'mojtabanaseri-article-products').'" value="').esc_attr($search).'"><div class="mnps-archive-filters">';
        foreach(array('all'=>__('همه', 'mojtabanaseri-article-products'),'active'=>__('فعال', 'mojtabanaseri-article-products'),'expired'=>__('پایان‌یافته', 'mojtabanaseri-article-products'),'inactive'=>__('غیرفعال', 'mojtabanaseri-article-products'))as$k=>$label){
            echo '<button type="submit" name="mnps_state" value="'.$k.'" class="'.($filter===$k?'mnps-primary':'mnps-secondary').'" aria-pressed="'.($filter===$k?'true':'false').'">'.$label.'</button>';
        }
        echo ('</div>'.'<select name="mnps_type" aria-label="'.esc_attr__('نوع باکس', 'mojtabanaseri-article-products').'">'.'<option value="all" ').selected($type,'all',false).('>'.esc_html__('همه باکس‌ها', 'mojtabanaseri-article-products').'</option>'.'<option value="products" ').selected($type,'products',false).('>'.esc_html__('محصولات', 'mojtabanaseri-article-products').'</option>'.'<option value="cta" ').selected($type,'cta',false).('>'.esc_html__('دعوت به اقدام', 'mojtabanaseri-article-products').'</option>'.'<option value="table" ').selected($type,'table',false).('>جدول</option>'.'</select>'.'<select name="mnps_tag" aria-label="'.esc_attr__('فیلتر برچسب', 'mojtabanaseri-article-products').'">'.'<option value="">'.esc_html__('همه برچسب‌ها', 'mojtabanaseri-article-products').'</option>');
        foreach($tags as$t){
            echo '<option value="'.esc_attr($t).'" '.selected($tag,$t,false).'>'.esc_html($t).'</option>';
        }
        echo '</select><label class="mnps-health-filter"><input type="checkbox" name="mnps_health" value="1" '.checked($health,true,false).('>'.esc_html__(' نیازمند بررسی', 'mojtabanaseri-article-products').'</label>'.'<button type="submit" class="mnps-secondary">'.esc_html__('جستجو', 'mojtabanaseri-article-products').'</button>'.'<a class="mnps-secondary" href="').esc_url(admin_url('admin.php?page=mnps-templates')).('">'.esc_html__('طرح‌های آماده', 'mojtabanaseri-article-products').'</a>'.'<button type="button" class="mnps-secondary" data-action="rescan">'.esc_html__('بررسی محل‌های استفاده', 'mojtabanaseri-article-products').'</button>'.'</form>'.'</div>'.'<div class="mnps-archive-bottom">'.'<div class="mnps-archive-summary">'.'<span>'.esc_html__('باکس فعال ', 'mojtabanaseri-article-products').'<b data-archive-active>').number_format_i18n($stats['active']).('</b>'.'</span>'.'<span>'.esc_html__('باکس غیرفعال ', 'mojtabanaseri-article-products').'<b data-archive-inactive>').number_format_i18n($stats['inactive']).('</b>'.'</span>'.'</div>'.'<div class="mnps-bulk-toolbar" hidden>'.'<label class="mnps-bulk-select">'.'<input type="checkbox" data-select-all-boxes>'.esc_html__(' انتخاب همه این صفحه', 'mojtabanaseri-article-products').'</label>'.'<button type="button" class="mnps-mini-button" data-select-results>انتخاب همه نتایج</button>'.'<span data-selected-box-count role="status">'.esc_html__('هیچ باکسی انتخاب نشده', 'mojtabanaseri-article-products').'</span>'.'<span class="mnps-bulk-hint">'.esc_html__('وضعیت مقاله‌ها در پنجره انتخاب می‌شود.', 'mojtabanaseri-article-products').'</span>'.'<button type="button" class="mnps-primary" data-bulk-visibility="1" disabled>'.esc_html__('فعال‌سازی', 'mojtabanaseri-article-products').'</button>'.'<button type="button" class="mnps-secondary" data-bulk-visibility="0" disabled>'.esc_html__('غیرفعال‌سازی', 'mojtabanaseri-article-products').'</button>'.'<button type="button" class="mnps-secondary" data-replace-selected>'.esc_html__('جایگزینی محصول', 'mojtabanaseri-article-products').'</button>'.'<button type="button" class="mnps-secondary" data-export-selected>'.esc_html__('بکاپ انتخاب‌شده‌ها', 'mojtabanaseri-article-products').'</button>'.'<button type="button" class="mnps-secondary" data-delete-selected>'.esc_html__('حذف کامل انتخاب‌شده‌ها', 'mojtabanaseri-article-products').'</button>'.'<button type="button" class="mnps-secondary" data-clear-box-selection>'.esc_html__('لغو انتخاب', 'mojtabanaseri-article-products').'</button>'.'</div>'.'</div>'.'<p class="mnps-help">'.esc_html__('نمایش ', 'mojtabanaseri-article-products')).number_format_i18n(count($shown)).__(' باکس از ', 'mojtabanaseri-article-products').number_format_i18n($total).'</p><p id="mnps-scan-status" class="mnps-help" role="status" aria-live="polite"></p><div class="mnps-library-grid">';
        foreach($shown as$r){
            list($p,$g,$entry,$published,$title)=$r;
            $box=$entry['id'];
            $count=$entry['total'];
            $enabled=$published?$entry['enabled']:0;
            $disabled=$count-$enabled;
            $code=Store::code($p->ID,$g['key']);
            $pct=$count?round($enabled*100/$count):0;
            $issues=$r[5];
            $previous=get_post_meta($p->ID,Features::PREVIOUS,true);
            Workflow::card($p,$g,$entry,$published,$title,$issues,$previous);
        }
        echo '</div>';
        if(!$total){
            echo ('<div class="mnps-empty">'.'<h2>'.esc_html__('باکسی پیدا نشد', 'mojtabanaseri-article-products').'</h2>'.'<p>'.esc_html__('فیلترها را تغییر بده یا باکس جدید بساز.', 'mojtabanaseri-article-products').'</p>'.'</div>');
        }
        echo ('<div class="mnps-pagination-row">'.'<span>'.esc_html__('صفحه ', 'mojtabanaseri-article-products')).number_format_i18n($page).__(' از ', 'mojtabanaseri-article-products').number_format_i18n($pages).('</span>'.'<nav class="mnps-pagination" aria-label="'.esc_attr__('صفحه‌های باکس‌ها', 'mojtabanaseri-article-products').'">');
        $url=function($i)use($search,$tag,$filter,$type,$health){
            return esc_url(add_query_arg(array('page'=>'mnps-home','mnps_page'=>$i,'mnps_search'=>$search,'mnps_tag'=>$tag,'mnps_state'=>$filter,'mnps_type'=>$type,'mnps_health'=>$health?1:0),admin_url('admin.php')));
        }
        ;
        echo $page>1?'<a href="'.$url($page-1).('">'.esc_html__('قبلی', 'mojtabanaseri-article-products').'</a>'):('<span aria-disabled="true">'.esc_html__('قبلی', 'mojtabanaseri-article-products').'</span>');
        $numbers=array_unique(array_merge(array(1,$pages),range(max(1,$page-2),min($pages,$page+2))));
        sort($numbers);
        $last=0;
        foreach($numbers as$i){
            if($last&&$i>$last+1){
                echo '<span class="mnps-page-ellipsis">…</span>';
            }
            echo '<a '.($i===$page?'aria-current="page" ':'').'href="'.$url($i).'">'.number_format_i18n($i).'</a>';
            $last=$i;
        }
        echo $page<$pages?'<a href="'.$url($page+1).('">'.esc_html__('بعدی', 'mojtabanaseri-article-products').'</a>'):('<span aria-disabled="true">'.esc_html__('بعدی', 'mojtabanaseri-article-products').'</span>');
        echo '</nav></div><p id="mnps-app-status" role="status" aria-live="polite"></p></div>';
        self::end();
    }
    public static function templates(){
        $d=Appearance::current();
        $out=array(array('id'=>'simple','name'=>__('ساده', 'mojtabanaseri-article-products'),'style'=>array_merge($d,array('background'=>'#ffffff','accent'=>'#475569','shadow'=>'none','card_radius'=>12,'radius'=>16))),array('id'=>'modern','name'=>__('مدرن', 'mojtabanaseri-article-products'),'style'=>array_merge($d,array('background'=>'#edf6f7','accent'=>'#086779','line_color'=>'#086779'))),array('id'=>'shop','name'=>__('فروشگاهی', 'mojtabanaseri-article-products'),'style'=>array_merge($d,array('background'=>'#f7f9f7','accent'=>'#287867','line_color'=>'#287867','button_radius'=>8,'card_radius'=>18))));
        $args=array('post_type'=>'mnps_design','post_status'=>array('publish','draft'),'numberposts'=>100,'orderby'=>'modified');
        if(!current_user_can('edit_others_posts')){
            $args['author']=get_current_user_id();
        }
        foreach(get_posts($args)as$p){
            if(current_user_can('edit_post',$p->ID)){
                $out[]=array('id'=>(string)$p->ID,'name'=>$p->post_title,'personal'=>true,'paint'=>Suite::paint(get_post_meta($p->ID,'_mnps_paint',true)),'style'=>Appearance::current(get_post_meta($p->ID,'_mnps_style',true)));
            }
        }
        return $out;
    }
    public static function categories(){
        if(!taxonomy_exists('product_cat')){
            return array();
        }
        $terms=get_terms(array('taxonomy'=>'product_cat','hide_empty'=>true,'number'=>100));
        return is_wp_error($terms)?array():array_values(array_map(function($t){
            return array('id'=>$t->term_id,'name'=>$t->name);
        }
        ,$terms));
    }
    public static function gallery(){
        self::header(__('طرح‌های آماده', 'mojtabanaseri-article-products'),__('طرح را انتخاب کن و با محصولات و متن دلخواه خودت بساز.', 'mojtabanaseri-article-products'));
        echo '<div id="mnps-template-archive" class="mnps-template-grid"></div><p id="mnps-app-status" role="status" aria-live="polite"></p>';
        self::end();
    }
    public static function settings(){
        self::header(__('ظاهر پیش‌فرض', 'mojtabanaseri-article-products'),__('این تنظیمات برای باکس‌هایی است که ظاهر اختصاصی ندارند.', 'mojtabanaseri-article-products'));
        $a=Appearance::current();
        $limits=Appearance::limits();
        echo '<form class="mnps-settings-panel" method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="mnps_settings">';
        wp_nonce_field('mnps_settings');
        echo ('<div class="mnps-settings-columns">'.'<section class="mnps-setting-card">'.'<h3>'.esc_html__('رنگ‌ها', 'mojtabanaseri-article-products').'</h3>'.'<div class="mnps-field-grid">');
        foreach(array('accent'=>__('رنگ اصلی', 'mojtabanaseri-article-products'),'background'=>__('پس‌زمینه باکس', 'mojtabanaseri-article-products'),'card_background'=>__('پس‌زمینه کارت', 'mojtabanaseri-article-products'),'title_color'=>__('رنگ عنوان', 'mojtabanaseri-article-products'),'text_color'=>__('رنگ توضیح', 'mojtabanaseri-article-products'),'button_text'=>__('متن دکمه', 'mojtabanaseri-article-products'),'border_color'=>__('رنگ حاشیه', 'mojtabanaseri-article-products'),'line_color'=>__('خط کنار عنوان', 'mojtabanaseri-article-products'))as$k=>$l){
            echo '<label class="mnps-field mnps-color-field"><span>'.esc_html($l).'</span><span class="mnps-color-pair"><input type="color" data-settings-color="'.$k.'" name="appearance['.$k.']" value="'.esc_attr($a[$k]).'"><input type="text" data-settings-hex="'.$k.'" aria-label="'.esc_attr('کد '.$l).'" dir="ltr" maxlength="7" pattern="#[0-9a-fA-F]{6}" required value="'.esc_attr($a[$k]).'"></span></label>';
        }
        echo ('</div>'.'</section>'.'<section class="mnps-setting-card">'.'<h3>'.esc_html__('اندازه‌ها', 'mojtabanaseri-article-products').'</h3>'.'<div class="mnps-field-grid">');
        foreach(array('radius'=>__('گردی باکس', 'mojtabanaseri-article-products'),'card_radius'=>__('گردی کارت', 'mojtabanaseri-article-products'),'button_radius'=>__('گردی دکمه', 'mojtabanaseri-article-products'),'padding'=>__('فاصله داخلی', 'mojtabanaseri-article-products'),'gap'=>__('فاصله کارت‌ها', 'mojtabanaseri-article-products'),'title_size'=>__('اندازه عنوان', 'mojtabanaseri-article-products'),'text_size'=>__('اندازه توضیح', 'mojtabanaseri-article-products'),'button_size'=>__('اندازه متن دکمه', 'mojtabanaseri-article-products'))as$k=>$l){
            echo '<label class="mnps-field" data-compact-number><span>'.esc_html($l).' (px)</span><input type="number" min="'.absint($limits[$k][0]).'" max="'.absint($limits[$k][1]).'" name="appearance['.$k.']" value="'.absint($a[$k]).'"></label>';
        }
        echo '</div></section></div>';
        self::behavior_settings();
        echo ('<div class="mnps-settings-footer">'.'<label class="mnps-field">'.'<span>'.esc_html__('سایه', 'mojtabanaseri-article-products').'</span>'.'<select name="appearance[shadow]">');
        foreach(array('none'=>__('بدون سایه', 'mojtabanaseri-article-products'),'soft'=>__('ملایم', 'mojtabanaseri-article-products'),'strong'=>__('برجسته', 'mojtabanaseri-article-products'))as$k=>$v){
            echo '<option value="'.$k.'" '.selected($a['shadow'],$k,false).'>'.esc_html($v).'</option>';
        }
        echo ('</select>'.'</label>'.'<button type="submit" class="mnps-primary">'.esc_html__('ذخیره تنظیمات', 'mojtabanaseri-article-products').'</button>'.'<span role="status">').(isset($_GET['saved'])?__('تنظیمات ذخیره شد.', 'mojtabanaseri-article-products'):'').'</span></div></form>';
        self::end();
    }
    private static function behavior_settings(){
        $b=Features::settings();$b['font']=Features::new_font();
        $select=function($key,$label,$options)use($b){
            echo '<label class="mnps-field"><span>'.esc_html($label).'</span><select name="behavior['.$key.']">';
            foreach($options as$v=>$text){
                echo '<option value="'.esc_attr($v).'" '.selected($b[$key],$v,false).'>'.esc_html($text).'</option>';
            }
            echo '</select></label>';
        }
        ;
        echo ('<div class="mnps-settings-columns mnps-behavior-settings">'.'<section class="mnps-setting-card">'.'<h3>'.esc_html__('مدیریت باکس‌ها', 'mojtabanaseri-article-products').'</h3>');
        $select('per_page',__('تعداد باکس در هر صفحه', 'mojtabanaseri-article-products'),array(12=>__('۱۲ باکس', 'mojtabanaseri-article-products'),24=>__('۲۴ باکس', 'mojtabanaseri-article-products'),48=>__('۴۸ باکس', 'mojtabanaseri-article-products')));
        echo ('</section>'.'<section class="mnps-setting-card">'.'<h3>'.esc_html__('پیش‌فرض نمایش', 'mojtabanaseri-article-products').'</h3>');
        $select('hide_stock',__('محصول ناموجود', 'mojtabanaseri-article-products'),array(0=>__('نمایش داده شود', 'mojtabanaseri-article-products'),1=>__('پنهان شود', 'mojtabanaseri-article-products')));
        $select('empty',__('باکس بدون محصول', 'mojtabanaseri-article-products'),array('hide'=>__('پنهان شود', 'mojtabanaseri-article-products'),'text'=>__('متن دلخواه', 'mojtabanaseri-article-products')));
        echo '<label class="mnps-field" data-empty-message '.($b['empty']==='text'?'':'hidden').('>'.'<span>'.esc_html__('متن باکس بدون محصول', 'mojtabanaseri-article-products').'</span>'.'<input name="behavior[empty_text]" maxlength="250" value="').esc_attr($b['empty_text']).('">'.'</label>'.'<div class="mnps-auto-defaults">'.'<label class="mnps-field">'.'<span>'.esc_html__('تعداد محصولات خودکار', 'mojtabanaseri-article-products').'</span>'.'<input type="number" name="behavior[auto_count]" min="1" max="12" value="').absint($b['auto_count']).'"></label>';
        $select('auto_order',__('ترتیب نمایش', 'mojtabanaseri-article-products'),array('sales'=>__('پرفروش‌ترین', 'mojtabanaseri-article-products'),'date'=>__('جدیدترین', 'mojtabanaseri-article-products'),'rating'=>__('بالاترین امتیاز', 'mojtabanaseri-article-products'),'price'=>__('ارزان‌ترین', 'mojtabanaseri-article-products')));
        echo ('<label class="mnps-switch-row">'.'<span>'.esc_html__('فقط موجود', 'mojtabanaseri-article-products').'</span>'.'<span class="mnps-switch">'.'<input type="checkbox" role="switch" name="behavior[auto_stock]" value="1" ').checked($b['auto_stock'],true,false).'><i></i></span></label></div>';
        $select('font',__('فونت خروجی', 'mojtabanaseri-article-products'),array('plugin'=>__('فونت مقاله‌یار', 'mojtabanaseri-article-products'),'theme'=>__('فونت قالب', 'mojtabanaseri-article-products')));
        echo ('<p class="mnps-help">'.esc_html__('پیش‌فرض‌ها برای باکس‌های جدید هستند؛ هر باکس تنظیم مستقل دارد.', 'mojtabanaseri-article-products').'</p>'.'</section>'.'</div>');
    }
    public static function save_settings(){
        if(!current_user_can('manage_options')){
            wp_die(esc_html__('دسترسی مجاز نیست.', 'mojtabanaseri-article-products'));
        }
        check_admin_referer('mnps_settings');
        update_option('mnps_behavior',Features::clean_settings(wp_unslash($_POST['behavior']??array())),false);
        update_option('mnps_new_font',($_POST['behavior']['font']??'theme')==='plugin'?'plugin':'theme',false);
        update_option('mnps_appearance',Appearance::clean(wp_unslash($_POST['appearance']??array())),false);
        update_option('mnps_paint',Suite::paint(json_decode(wp_unslash($_POST['mnps_paint']??'{}'),true)),false);
        Plugin::boot()->purge_all();
        wp_safe_redirect(admin_url('admin.php?page=mnps-settings&saved=1'));
        exit;
    }
    public static function help(){
        self::header(__('راهنمای مقاله‌یار', 'mojtabanaseri-article-products'),__('مراحل ساخت و مدیریت باکس، همراه با نکته‌های بازیابی و رفع مشکل.', 'mojtabanaseri-article-products'));
        echo '<div class="mnps-settings-panel mnps-help-sections">';
        echo '<details><summary>ساخت جدول و قالب آماده</summary><p>در ساخت باکس، جدول را انتخاب کنید. از یک نمونه آماده شروع کنید یا تعداد سطر و ستون را تعیین کنید. محتوای کپی‌شده از اکسل را در کادر ورود بچسبانید. محتوا بالا و پیش‌نمایش پایین قرار دارد. برای تنظیم سلول روی چرخ‌دنده آن بزنید؛ نوع محتوا، لینک، تصویر و استایل اختصاصی در همان بخش قابل تغییر است. تغییرات ساختار با بازگردانی و انجام دوباره قابل مرور هستند.</p></details><details><summary>دعوت به اقدام و زمان‌بندی</summary><p>در مرحله دوم عنوان، توضیح، دکمه و تصویر را وارد کنید؛ افزودن محتوا برای عنوان یا دکمه بیشتر است. مرحله سوم تراز کلی و اختصاصی را تنظیم می‌کند. در مرحله ظاهر اندازه متن رایانه و موبایل قابل تنظیم است. زمان‌بندی پیش‌فرض خاموش است؛ با روشن‌کردن آن تاریخ شمسی و ساعت ۲۴ ساعته پایان را تعیین کنید. منطقه زمانی از تنظیمات وردپرس خوانده می‌شود. بعد از موعد باکس نمایش داده نمی‌شود؛ کش صفحه سایت ممکن است نیاز به پاک‌سازی داشته باشد.</p></details>';
        echo ('<details>'.'<summary>'.esc_html__('اولین باکس در پنج مرحله', 'mojtabanaseri-article-products').'</summary>'.'<p>'.esc_html__('در «ساخت باکس» نوع محصولات یا دعوت به اقدام را انتخاب کنید. برای محصولات، فهرست کناری را جست‌وجو کنید و با تیک انتخاب، محصولات را اضافه کنید. سپس عنوان و توضیحات، ظاهر و پیش‌نمایش را بررسی کنید و «ذخیره باکس» را بزنید. در دعوت به اقدام، مرحله محصولات حذف می‌شود. تا ۱۲ محصول و ۲۰ باکس در هر منبع پشتیبانی می‌شود.', 'mojtabanaseri-article-products').'</p>'.'</details>');
        echo ('<details>'.'<summary>'.esc_html__('تنظیمات اختصاصی هر محصول', 'mojtabanaseri-article-products').'</summary>'.'<p>'.esc_html__('داخل کارت محصول، «تنظیمات اختصاصی این محصول» را باز کنید. سوییچ استفاده از تنظیمات باکس را خاموش کنید تا نمایش قیمت، دکمه، توضیحات و نشان را مستقل تعیین کنید. لینک اختصاصی اختیاری است؛ خالی باشد، تصویر، نام و دکمه به صفحه همان محصول می‌روند. تغییر این موارد، محصول ووکامرس را ویرایش نمی‌کند.', 'mojtabanaseri-article-products').'</p>'.'</details>');
        echo ('<details>'.'<summary>'.esc_html__('ظاهر قالب یا شخصی‌سازی', 'mojtabanaseri-article-products').'</summary>'.'<p>'.esc_html__('در مرحله ظاهر، خاموش کردن «شخصی‌سازی ظاهر» کارت استاندارد ووکامرس را از قالب فعال فراخوانی می‌کند. فونت، رنگ و پوست کارت از استایل قالب می‌آید؛ تنظیمات اختصاصی قبلی حفظ می‌شود. طرح‌های Elementor Theme Builder خودکار فراخوانی نمی‌شوند و قالبی که هوک استاندارد ووکامرس را حذف کرده ممکن است نیاز به تطبیق داشته باشد. ظاهر نهایی حالت قالب را در صفحه واقعی سایت بررسی کنید. روشن کردن سوییچ، رنگ و اندازه‌های مقاله‌یار را بازمی‌گرداند.', 'mojtabanaseri-article-products').'</p>'.'</details>');
        echo ('<details>'.'<summary>'.esc_html__('محصولات خودکار و سلامت باکس', 'mojtabanaseri-article-products').'</summary>'.'<p>'.esc_html__('در مرحله انتخاب محصولات، حالت خودکار، دسته، تعداد، ترتیب و موجودی را تعیین کنید. ثابت کردن محصول آن را در پیشنهادها نگه می‌دارد و حذف از فهرست، آن را کنار می‌گذارد. تنظیمات اختصاصی محصولات فعلی از پنل همان محصول قابل تغییر است. نتیجه پیشنهادها پنج دقیقه کش می‌شود و با تغییر محصول دوباره محاسبه می‌شود. بخش بررسی سلامت، محصول حذف‌شده، منتشرنشده، پنهان یا ناموجود را نشان می‌دهد.', 'mojtabanaseri-article-products').'</p>'.'</details>');
        echo ('<details>'.'<summary>'.esc_html__('دکمه مشاهده همه محصولات', 'mojtabanaseri-article-products').'</summary>'.'<p>'.esc_html__('در مرحله ظاهر، بخش دکمه آرشیو را باز کنید. متن پیش‌فرض «مشاهده همه محصولات» است و لینک خالی برای انتخاب خودکار به دسته منتخب، و برای انتخاب دستی به فروشگاه ووکامرس می‌رود. متن، لینک، آیکن و باز شدن در صفحه جدید مستقل‌اند. رنگ و اندازه رایانه و موبایل در حالت شخصی‌سازی تنظیم می‌شوند. دکمه کنار و سمت راست فلش‌های اسلایدر قرار می‌گیرد.', 'mojtabanaseri-article-products').'</p>'.'</details>');
        echo ('<details>'.'<summary>'.esc_html__('کد باکس و محل استفاده', 'mojtabanaseri-article-products').'</summary>'.'<p>'.esc_html__('پس از ذخیره، «کپی کد» را بزنید و کد را در بلوک شورت‌کد مقاله یا ویجت شورت‌کد المنتور قرار دهید. ویجت مقاله‌یار هم باکس ذخیره‌شده را نمایش می‌دهد. در مدیریت باکس‌ها، وضعیت نمایش هر مقاله را از محل‌های استفاده کنترل کنید. خاموش کردن نمایش، داده‌ها و شورت‌کد را حذف نمی‌کند. استفاده در کد PHP قالب یا خروجی افزونه‌های دیگر ممکن است در آمار شناسایی نشود.', 'mojtabanaseri-article-products').'</p>'.'</details>');
        echo ('<details>'.'<summary>'.esc_html__('بکاپ JSON و بازیابی', 'mojtabanaseri-article-products').'</summary>'.'<p>'.esc_html__('در صفحه بکاپ، خروجی کامل شامل باکس‌ها، تنظیمات و طرح‌های شخصی است؛ در مدیریت باکس‌ها خروجی انتخابی فقط همان باکس‌ها را دارد. فایل JSON حداکثر ۵ مگابایت است. ابتدا بررسی فایل و موارد پیدا‌نشده انجام می‌شود و سپس با تأیید شما ذخیره می‌شود. روی همان سایت، به‌روزرسانی باکس‌های قبلی کدها را حفظ می‌کند؛ نسخه جدید کد جدید می‌گیرد. در انتقال به سایت دیگر، محصول با SKU تطبیق داده می‌شود؛ موارد پیدا‌نشده باید به شناسه سایت مقصد وصل یا با ۰ آگاهانه کنار گذاشته شوند. تصویر دانلود نمی‌شود. این بکاپ شامل فایل تصاویر، داده محصولات، مقاله‌ها و کل سایت نیست.', 'mojtabanaseri-article-products').'</p>'.'</details>');
        echo ('<details>'.'<summary>'.esc_html__('حذف کامل و بازگردانی', 'mojtabanaseri-article-products').'</summary>'.'<p>'.esc_html__('کارت‌ها را انتخاب کنید و «حذف کامل انتخاب‌شده‌ها» را بزنید. نام باکس‌ها و تعداد محل‌های استفاده را بررسی کنید، دریافت بکاپ JSON اختیاری است؛ با یا بدون بکاپ، تأیید نهایی حذف را بزنید. خروجی باکس‌ها در تمام مقاله‌ها حذف می‌شود؛ مقاله‌ها، محصولات و باکس‌های دیگر حفظ می‌شوند. حذف گروهی از بازیابی آخرین ذخیره بازنمی‌گردد؛ از فایل JSON و روش به‌روزرسانی همین سایت استفاده کنید. اگر عملیات فقط بخشی موفق شود، موارد ناموفق در گزارش نشان داده می‌شوند.', 'mojtabanaseri-article-products').'</p>'.'</details>');
        echo ('<details>'.'<summary>'.esc_html__('ارتباط، لایسنس و اعلان اختیاری', 'mojtabanaseri-article-products').'</summary>'.'<p>'.esc_html__('نسخه رایگان بدون لایسنس، ثبت‌نام یا اینترنت کار می‌کند. سرور مرکزی یک بسته جداست و باید روی دامنه HTTPS نصب شود. با واردکردن کلید و زدن دکمه بررسی، ارتباط فعال می‌شود. دریافت اخبار با تیک «اخبار مقاله‌یار» در تنظیمات صفحه پیشخوان انتخاب می‌شود. آدرس سایت، شناسه نصب، نسخه افزونه و کلید واردشده به سرور انتخابی ارسال می‌شود؛ اطلاعات مشتریان و سفارش‌ها ارسال نمی‌شود. اخبار هر ۱۲ ساعت با WP-Cron دریافت و کش می‌شوند و فقط در ویجت پیشخوان کاربرانی که تیک آن را روشن کرده‌اند نمایش داده می‌شوند. با قطع سرور، باکس‌ها فعال می‌مانند. پاک‌کردن کلید و خاموش‌کردن ویجت اخبار، کش و برنامه زمان‌بندی را پاک می‌کند؛ حذف سابقه سرور مرکزی را از مدیر سرویس بخواهید.', 'mojtabanaseri-article-products').'</p>'.'</details>');
        echo ('<details>'.'<summary>'.esc_html__('رفع مشکل و ارتقا', 'mojtabanaseri-article-products').'</summary>'.'<p>'.esc_html__('اگر محصول نمایش داده نمی‌شود، انتشار، موجودی، قابلیت نمایش ووکامرس و وضعیت باکس در مقاله را بررسی کنید. پیام تغییر هم‌زمان یعنی صفحه دیگری داده‌ها را تغییر داده؛ صفحه را دوباره باز کنید. نبودن محل استفاده را با «بررسی محل‌های استفاده» بازبینی کنید. برای محصول لازم است ووکامرس فعال باشد؛ دعوت به اقدام مستقل و المنتور و ACF اختیاری‌اند. پیش از ارتقا، بکاپ مقاله‌یار و بکاپ سایت را بگیرید. ZIP جدید را جایگزین کنید؛ حذف افزونه داده‌ها را خودکار پاک نمی‌کند. ارتقا را ابتدا روی نسخه آزمایشی سایت بررسی کنید.', 'mojtabanaseri-article-products').'</p>'.'</details>');
        echo '<details><summary>ساخت جدول مقایسه با کمک هوش مصنوعی</summary><ol><li>در ووکامرس، محصولات موردنظر را خروجی بگیرید؛ ستون شناسه یا SKU و مشخصات موردنیاز را نگه دارید.</li><li>فایل را به هوش مصنوعی بدهید و جدول مقایسه بخواهید؛ شناسه یا SKU هر محصول باید حفظ شود. نمونه درخواست: «فقط براساس داده‌های این فایل، محصولات را از نظر قیمت، موجودی و ویژگی‌ها مقایسه کن؛ اطلاعات ناموجود را حدس نزن. هر سطر یک محصول باشد، شناسه یا SKU را نگه دار و خروجی XLSX یا CSV بده.»</li><li>در مرحله محتوای جدول مقاله‌یار، فایل XLSX یا CSV را انتخاب کنید؛ برای XLSX نخستین برگه خوانده می‌شود. فایل رمزدار، XLS و ماکرو پشتیبانی نمی‌شوند. حداکثر فایل ۵ مگابایت، ۱۰۰ سطر محتوا و ۱۲ ستون است.</li><li>پیش‌نمایش را ببینید، سطر عنوان و نام ستون‌ها را تنظیم کنید. ورود، محتوای جدول فعلی را پس از تأیید جایگزین می‌کند و با بازگردانی قابل برگشت است.</li><li>برای اطلاعات ثابت، ورود دستی را انتخاب کنید. برای اتصال زنده، ستون شناسه یا SKU و فیلد خودکار هر ستون را انتخاب کنید؛ هر سطر باید به محصول معتبر متصل شود. قیمت و موجودی متصل، از ووکامرس خوانده می‌شوند.</li><li>بعد از ورود، محتوا، سلول‌ها، ظاهر، سطرها و ستون‌ها قابل ویرایش‌اند؛ با تنظیم «جایگزینی اطلاعات خودکار محصول»، متن دلخواه سلول را حفظ کنید. پیش‌نمایش نهایی را بررسی و باکس را ذخیره کنید.</li></ol><p>این مسیر از ابزار هوش مصنوعی انتخابی شما خارج از افزونه استفاده می‌کند؛ مقاله‌یار فایل محصولات را خودکار به سرویس هوش مصنوعی ارسال نمی‌کند. فقط فایل محصول لازم را در اختیار آن ابزار قرار دهید.</p></details></div>';
        self::end();
    }
    public static function backup(){
        self::header(__('بکاپ و بازیابی', 'mojtabanaseri-article-products'),__('نسخه JSON اطلاعات مقاله‌یار؛ محصولات و فایل‌های سایت در این بکاپ قرار نمی‌گیرند.', 'mojtabanaseri-article-products'));
        if(Modules::enabled('transfer'))Transfer::page();else echo '<section class="mnps-setting-card"><p>ماژول ورود و بکاپ خاموش است. داده‌ها حفظ شده‌اند؛ برای استفاده دوباره آن را از صفحه ماژول‌ها روشن کنید.</p></section>';
        self::end();
    }
    public static function connection(){
        self::header(__('ارتباط اختیاری', 'mojtabanaseri-article-products'),__('افزونه رایگان برای کارکرد خود نیازی به اتصال یا لایسنس ندارد.', 'mojtabanaseri-article-products'));
        Connection::page();
        self::end();
    }
    private static function auth($source=0){
        check_ajax_referer('mnps_admin','nonce');
        if(!current_user_can('edit_posts')||($source&&!current_user_can('edit_post',$source))){
            wp_send_json_error(array('message'=>__('اجازه انجام این تغییر را نداری.', 'mojtabanaseri-article-products')),403);
        }
    }
    public static function save_box(){
        $id=absint($_POST['post']??0);
        self::auth($id);
        $before=$id?get_post_meta($id,Plugin::META,true):false;
        if($id&&!in_array(get_post_type($id),array('post','mnps_group'),true)){
            wp_send_json_error(array('message'=>__('منبع معتبر نیست.', 'mojtabanaseri-article-products')),400);
        }
        if($id&&!hash_equals(self::fingerprint($id),(string)($_POST['hash']??''))){
            wp_send_json_error(array('message'=>__('باکس در جای دیگری تغییر کرده؛ صفحه را دوباره باز کن.', 'mojtabanaseri-article-products')),409);
        }
        $raw=wp_unslash($_POST['groups']??'');
        $g=is_string($raw)&&strlen($raw)<=1000000?json_decode($raw,true):null;
        if(!is_array($g)||($g&&array_keys($g)!==range(0,count($g)-1))){
            wp_send_json_error(array('message'=>__('داده‌ها معتبر نیست؛ تغییرات ذخیره نشد.', 'mojtabanaseri-article-products')),400);
        }
        $clean=Plugin::boot()->normalize(Plugin::boot()->protect_code($g,$id));
        foreach($g as$raw_group){if(!empty($raw_group['schedule']['enabled'])&&empty($raw_group['schedule']['end']))wp_send_json_error(array('message'=>'تاریخ پایان معتبر نیست.'),400);}
        $draft=!empty($_POST['draft']);
        if($draft&&$id&&get_post_type($id)!=='mnps_group')wp_send_json_error(array('message'=>'پیش‌نویس فقط برای باکس مستقل است.'),400);
        foreach($clean as$group){if($group['type']!=='table')continue;
            if(!$draft&&(!$group['table']['rows']||!$group['table']['columns']))wp_send_json_error(array('message'=>'محتوای جدول را وارد کنید.'),400);
            if(!$draft&&$group['table']['mode']==='products')foreach($group['table']['rows']as$i=>$row){$product=function_exists('wc_get_product')?wc_get_product($row['product']):false;if(!$product||$product->get_status()!=='publish'||!$product->is_visible())wp_send_json_error(array('message'=>'سطر '.($i+1).' جدول: محصول معتبر و قابل نمایش انتخاب کنید.','row'=>$i),400);}
        }
        $name=sanitize_text_field(wp_unslash($_POST['name']??''));
        if(!$id){
            $id=wp_insert_post(array('post_type'=>'mnps_group','post_status'=>(!$draft&&current_user_can('publish_posts'))?'publish':'draft','post_author'=>get_current_user_id(),'post_title'=>$name?:($clean[0]['title']??__('باکس بدون عنوان', 'mojtabanaseri-article-products'))),true);
            if(is_wp_error($id)){
                wp_send_json_error(array('message'=>__('باکس ذخیره نشد.', 'mojtabanaseri-article-products')),500);
            }
        }
        elseif('mnps_group'===get_post_type($id)){
            $changes=array('ID'=>$id,'post_title'=>$name?:__('باکس بدون عنوان', 'mojtabanaseri-article-products'));
            if($draft){$changes['post_status']='draft';}
            elseif(!empty($_POST['publish'])&&current_user_can('publish_posts')){
                $changes['post_status']='publish';
            }
            $r=wp_update_post($changes,true);
            if(is_wp_error($r)){
                wp_send_json_error(array('message'=>__('ذخیره انجام نشد.', 'mojtabanaseri-article-products')),500);
            }
        }
        Features::write($id,$clean,$before);
        Store::rescan();
        Plugin::boot()->purge_all();
        wp_send_json_success(array('id'=>$id,'groups'=>self::hydrate($id),'hash'=>self::fingerprint($id),'published'=>'publish'===get_post_status($id),'edit'=>self::edit_url($id)));
    }
    public static function duplicate(){
        $id=absint($_POST['post']??0);
        self::auth($id);
        $key=sanitize_key($_POST['group']??'');
        foreach(Plugin::boot()->groups($id)as$g){
            if($g['key']!==$key){
                continue;
            }
            $g['key']='g'.str_replace('-','',wp_generate_uuid4());
            $copy=wp_insert_post(array('post_type'=>'mnps_group','post_status'=>current_user_can('publish_posts')?'publish':'draft','post_title'=>($g['title']?:get_the_title($id)).__(' — نسخه مشابه', 'mojtabanaseri-article-products'),'post_author'=>get_current_user_id()),true);
            if(is_wp_error($copy)){
                wp_send_json_error(array('message'=>__('نسخه مشابه ساخته نشد.', 'mojtabanaseri-article-products')),500);
            }
            update_post_meta($copy,Plugin::META,wp_slash(array($g)));
            Plugin::boot()->index($copy,array($g));
            wp_send_json_success(array('edit'=>self::edit_url($copy)));
        }
        wp_send_json_error(array('message'=>__('باکس پیدا نشد.', 'mojtabanaseri-article-products')),404);
    }
    public static function delete_box(){
        $id=absint($_POST['post']??0);
        self::auth($id);
        if(!$id||!in_array(get_post_type($id),array('post','mnps_group'),true)||!current_user_can('delete_post',$id)){
            wp_send_json_error(array('message'=>__('اجازه حذف باکس را نداری.', 'mojtabanaseri-article-products')),403);
        }
        $key=sanitize_key($_POST['group']??'');
        $groups=Plugin::boot()->groups($id);
        $remaining=array();
        $found=false;
        foreach($groups as$g){
            if($g['key']===$key){
                $found=true;
            }
            else{
                $remaining[]=$g;
            }
        }
        if(!$found){
            wp_send_json_error(array('message'=>__('باکس پیدا نشد.', 'mojtabanaseri-article-products')),404);
        }
        if(!hash_equals(self::fingerprint($id),(string)($_POST['hash']??''))){
            wp_send_json_error(array('message'=>__('باکس تغییر کرده؛ صفحه را دوباره باز کن.', 'mojtabanaseri-article-products')),409);
        }
        Features::snapshot($id,$remaining);
        update_post_meta($id,Plugin::META,wp_slash($remaining));
        Plugin::boot()->index($id,$remaining);
        Store::rescan();
        Plugin::boot()->purge_all();
        wp_send_json_success(array('deleted'=>true,'hash'=>self::fingerprint($id)));
    }
    public static function usage(){
        $box=absint($_POST['box']??0);
        $r=Store::resolve($box);
        self::auth($r?$r->source_post:0);
        if(!$r){
            wp_send_json_error(array('message'=>__('باکس پیدا نشد.', 'mojtabanaseri-article-products')),404);
        }
        $page=max(1,min(10000,absint($_POST['page_number']??1)));
        $summary=Store::visibility_summary($box);
        $total=$summary['total'];
        wp_send_json_success(array('items'=>Store::usage($box,$page),'more'=>$total>$page*100,'total'=>$total,'summary'=>$summary));
    }
    public static function visibility(){
        $box=absint($_POST['box']??0);
        $id=absint($_POST['destination']??0);
        $r=Store::resolve($box);
        self::auth($r?$r->source_post:0);
        if(!$r||!current_user_can('edit_post',$id)||!in_array($box,Store::detect($id),true)){
            wp_send_json_error(array('message'=>__('دسترسی به این محل استفاده مجاز نیست.', 'mojtabanaseri-article-products')),403);
        }
        $h=get_post_meta($id,Store::HIDDEN,true);
        $h=is_array($h)?array_map('absint',$h):array();
        $h=array_values(array_diff($h,array($box)));
        if(empty($_POST['enabled'])){
            $h[]=$box;
        }
        update_post_meta($id,Store::HIDDEN,$h);
        Store::index($id);
        Plugin::boot()->purge_post($id);
        wp_send_json_success(array('enabled'=>!empty($_POST['enabled']),'summary'=>Store::visibility_summary($box)));
    }
    public static function archive_stats(){
        self::auth();
        wp_send_json_success(Store::archive_stats());
    }
    public static function scan(){
        self::auth();
        if(!empty($_POST['reset'])){
            Store::rescan(true);
        }
        wp_send_json_success(Store::batch());
    }
    public static function save_template(){
        self::auth();
        $name=sanitize_text_field(wp_unslash($_POST['name']??''));
        $raw=wp_unslash($_POST['style']??'');
        $s=is_string($raw)&&strlen($raw)<5000?Appearance::clean(json_decode($raw,true)):array();
        if(!$name||!$s){
            wp_send_json_error(array('message'=>__('نام و ظاهر طرح را وارد کن.', 'mojtabanaseri-article-products')),400);
        }
        $id=wp_insert_post(array('post_type'=>'mnps_design','post_status'=>'draft','post_author'=>get_current_user_id(),'post_title'=>$name),true);
        if(is_wp_error($id)){
            wp_send_json_error(array('message'=>__('طرح ذخیره نشد.', 'mojtabanaseri-article-products')),500);
        }
        update_post_meta($id,'_mnps_style',$s);
        update_post_meta($id,'_mnps_paint',Suite::paint(json_decode(wp_unslash($_POST['paint']??'{}'),true)));
        wp_send_json_success(self::templates());
    }
    public static function delete_template(){
        $id=absint($_POST['template']??0);
        self::auth($id);
        if('mnps_design'!==get_post_type($id)||!current_user_can('delete_post',$id)){
            wp_send_json_error(array('message'=>__('حذف مجاز نیست.', 'mojtabanaseri-article-products')),403);
        }
        wp_trash_post($id);
        wp_send_json_success(self::templates());
    }

    public static function modules() {
        if(!current_user_can('manage_options'))wp_die(esc_html__('اجازه دسترسی ندارید.','mojtabanaseri-article-products'));
        self::header('ماژول‌ها','بخش‌های اختیاری را روشن یا خاموش کنید؛ داده‌های شما حذف نمی‌شوند.');
        $state=Modules::state();echo '<div class="mnps-modules-grid">';
        foreach(Modules::definitions()as$id=>$module){
            echo '<section class="mnps-setting-card mnps-module-card"><label class="mnps-switch-row"><span class="mnps-switch"><input type="checkbox" role="switch" data-module="'.esc_attr($id).'" '.checked($state[$id],true,false).' '.disabled($module['locked'],true,false).'><i></i></span><strong>'.esc_html($module['title']).'</strong></label><p>'.esc_html($module['description']).'</p><small>'.($module['locked']?'همیشه روشن':'اختیاری').'</small><p class="mnps-module-status" role="status" aria-live="polite"></p></section>';
        }
        echo '</div>';self::end();
    }
}
