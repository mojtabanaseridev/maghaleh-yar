<?php
namespace Mojtabanaseri\ArticleProducts;
if (!defined('ABSPATH')) { exit; }
/** Version two additions. Legacy groups and stable aliases remain untouched. */
final class Suite {
    public static function text($v,$max=1500){return is_scalar($v)?sanitize_textarea_field(wp_html_excerpt((string)$v,$max,'')):'';}
    public static function color($v,$default='#ffffff') {return is_string($v)&&preg_match('/^#[a-f0-9]{6}(?:[a-f0-9]{2})?$/i',$v)?strtolower($v):$default;}
    public static function num($v,$min,$max,$default){return is_numeric($v)?max($min,min($max,(float)$v)):$default;}
    public static function align($v){return in_array($v,array('left','center','right'),true)?$v:'right';}
    public static function paint($raw){
        $out=array();foreach(array_slice(is_array($raw)?$raw:array(),0,1500,true)as$k=>$v){
            if(!is_array($v)||!preg_match('/^(?:style|archive|table)\.[a-zA-Z0-9_.]+$/',$k)||strpos($k,'__')!==false)continue;
            $out[$k]=array('on'=>!empty($v['on']),'a'=>self::color($v['a']??'','#086779'),'b'=>self::color($v['b']??'','#12b8bd'),'angle'=>self::num($v['angle']??90,0,360,90),'alpha'=>self::num($v['alpha']??100,0,100,100));
        }return $out;
    }
    public static function table_style($v){
        $v=is_array($v)?$v:array();$out=array();foreach(array('bg','text','header_bg','header_text','border','stripe','button_bg','button_text')as$k)if(isset($v[$k]))$out[$k]=self::color($v[$k]);
        foreach(array('font'=>array(10,48,14),'mobile_font'=>array(10,36,13),'padding_x'=>array(0,48,12),'padding_y'=>array(0,48,10),'radius'=>array(0,40,8),'border_width'=>array(0,8,1))as$k=>$b)if(isset($v[$k]))$out[$k]=self::num($v[$k],$b[0],$b[1],$b[2]);
        if(isset($v['align']))$out['align']=self::align($v['align']);if(isset($v['bold']))$out['bold']=!empty($v['bold']);return $out;
    }
    public static function defaults(){return array('bg'=>'#ffffff','text'=>'#1e293b','header_bg'=>'#086779','header_text'=>'#ffffff','border'=>'#e2e8f0','stripe'=>'#f5f7f8','button_bg'=>'#086779','button_text'=>'#ffffff','font'=>14,'mobile_font'=>13,'padding_x'=>12,'padding_y'=>10,'radius'=>8,'border_width'=>1,'align'=>'right');}
    public static function table($raw){
        $r=is_array($raw)?$raw:array();$cols=array();$rows=array();
        foreach(array_slice(is_array($r['columns']??null)?$r['columns']:array(),0,12)as$i=>$c){if(!is_array($c))continue;$cols[]=array('id'=>sanitize_key($c['id']??'col'.$i),'label'=>self::text($c['label']??'',120),'source'=>in_array($c['source']??'',array('name','image','price','stock','description','button','badge'),true)?$c['source']:'','width'=>self::num($c['width']??180,60,800,180),'style'=>self::table_style($c['style']??array()));}
        foreach(array_slice(is_array($r['rows']??null)?$r['rows']:array(),0,100)as$i=>$row){if(!is_array($row))continue;$cells=array();foreach($cols as$j=>$col){$c=is_array($row['cells'][$j]??null)?$row['cells'][$j]:array();$cells[]=array('id'=>sanitize_key($c['id']??'cell'.$i.'x'.$j),'type'=>in_array($c['type']??'text',array('text','image','link','button','badge','yes','no'),true)?($c['type']??'text'):'text','text'=>self::text($c['text']??''),'url'=>esc_url_raw(self::text($c['url']??'',2000),array('http','https','mailto','tel')),'image'=>Appearance::attachment($c['image']??0),'override'=>!empty($c['override']),'span'=>max(1,min(count($cols)-$j,absint($c['span']??1))),'rowspan'=>max(1,min(count(is_array($r['rows']??null)?$r['rows']:array())-$i,absint($c['rowspan']??1))),'style'=>self::table_style($c['style']??array()));}
            $rows[]=array('id'=>sanitize_key($row['id']??'row'.$i),'product'=>absint($row['product']??0),'style'=>self::table_style($row['style']??array()),'cells'=>$cells);
        }
        return array('mode'=>($r['mode']??'manual')==='products'?'products':'manual','caption'=>self::text($r['caption']??'',200),'header'=>!isset($r['header'])||!empty($r['header']),'stripes'=>!isset($r['stripes'])||!empty($r['stripes']),'hover'=>!isset($r['hover'])||!empty($r['hover']),'sticky'=>!empty($r['sticky']),'sticky_header'=>!empty($r['sticky_header']),'mobile'=>($r['mobile']??'scroll')==='cards'?'cards':'scroll','highlight'=>isset($r['highlight'])?(int)self::num($r['highlight'],-1,11,-1):-1,'style'=>array_merge(self::defaults(),self::table_style($r['style']??array())),'columns'=>$cols,'rows'=>$rows);
    }
    public static function content($raw){$out=array();foreach(array_slice(is_array($raw)?$raw:array(),0,30)as$i=>$c){if(!is_array($c))continue;$out[]=array('id'=>sanitize_key($c['id']??'content'.$i),'type'=>in_array($c['type']??'',array('title','text','button'),true)?$c['type']:'text','text'=>self::text($c['text']??'',3000),'tag'=>in_array($c['tag']??'',array('p','div','span','h1','h2','h3','h4','h5','h6'),true)?$c['tag']:'p','url'=>esc_url_raw(self::text($c['url']??'',2000),array('http','https','mailto','tel')),'width_mode'=>in_array($c['width_mode']??'',array('auto','full','custom'),true)?$c['width_mode']:'auto','button_width'=>self::num($c['button_width']??180,48,1200,180),'mobile_width_mode'=>in_array($c['mobile_width_mode']??'',array('auto','full','custom'),true)?$c['mobile_width_mode']:'auto','mobile_button_width'=>self::num($c['mobile_button_width']??160,48,600,160),'padding_x'=>self::num($c['padding_x']??18,0,80,18),'padding_y'=>self::num($c['padding_y']??10,0,48,10),'button_text_align'=>self::align($c['button_text_align']??'center'),'new_tab'=>!empty($c['new_tab']),'align'=>in_array($c['align']??'',array('left','right','center'),true)?$c['align']:'inherit','font'=>self::num($c['font']??16,10,60,16),'mobile_font'=>self::num($c['mobile_font']??14,10,44,14));}return $out;}
    public static function normalize($g,$raw){
        $g['type']=in_array($raw['type']??'',array('products','cta','table'),true)?$raw['type']:'products';
        $g['display_enabled']=!isset($raw['display_enabled'])||!empty($raw['display_enabled']);$g['paint']=self::paint($raw['paint']??array());$g['table']=self::table($raw['table']??array());$g['content']=self::content($raw['content']??array());
        $g['content_align']=self::align($raw['content_align']??'right');$g['image_position']=in_array($raw['image_position']??'',array('right','left','top','bottom'),true)?$raw['image_position']:(($g['cta']['layout']??'horizontal')==='vertical'?'top':'right');
        $g['schedule']=array('enabled'=>!empty($raw['schedule']['enabled']),'end'=>absint($raw['schedule']['end']??0));
        if($g['schedule']['enabled']&&!$g['schedule']['end'])$g['schedule']['enabled']=false;
        return $g;
    }
    public static function expired($g){return !empty($g['schedule']['enabled'])&&!empty($g['schedule']['end'])&&time()>=(int)$g['schedule']['end'];}
    public static function paint_value($p,$fallback){
        if(!$p)return $fallback;
        $rgba=function($c)use($p){$c=self::color($c);$rgb=sscanf(substr($c,1,6),'%02x%02x%02x');$alpha=($p['alpha']/100)*(strlen($c)===9?hexdec(substr($c,7,2))/255:1);return 'rgba('.implode(',',$rgb).','.$alpha.')';};
        if(!empty($p['on']))return 'linear-gradient('.(int)$p['angle'].'deg,'.$rgba($p['a']).','.$rgba($p['b']).')';
        return $rgba($p['a']);
    }
    public static function table_paint($paint,$paths,$key,$fallback){$p=null;foreach($paths as$path){if(isset($paint[$path.'.'.$key]))$p=$paint[$path.'.'.$key];}return self::paint_value($p,$fallback);}
    public static function text_css($value){return strpos($value,'linear-gradient')===0?'background-image:'.$value.';background-clip:text;-webkit-background-clip:text;color:transparent;':'color:'.$value.';';}
    public static function css($s,$path,$paint,$mobile=false){
        $paths=is_array($path)?$path:array('table.style',$path);$value=function($k,$fallback)use($paths,$paint){return self::table_paint($paint,$paths,$k,$fallback);};
        $s=array_merge(self::defaults(),$s);$border=$value('border',$s['border']);return 'background:'.$value('bg',$s['bg']).';color:'.$s['text'].';font-size:'.($mobile?$s['mobile_font']:$s['font']).'px;text-align:'.$s['align'].';padding:'.$s['padding_y'].'px '.$s['padding_x'].'px;border:'.$s['border_width'].'px solid '.(strpos($border,'linear-gradient')===0?$s['border']:$border).';'.(strpos($border,'linear-gradient')===0?'border-image:'.$border.' 1;':'').(!empty($s['bold'])?'font-weight:700;':'');
    }
    public static function table_html($g,$preview=false) { return TableRenderer::render($g,$preview); }
    public static function cta_html($g,$preview=false) { return CTARenderer::render($g,$preview); }
    public static function decorate($html,$g,$preview=false){
        if(!$html)return $html;$id=wp_unique_id('mnps-painted-');$rules='';$map=array('style.background'=>array('.mnps-section','background'),'style.card_background'=>array('.mnps-card','background'),'style.accent'=>array('.mnps-button','background'),'style.hover'=>array('.mnps-button:hover','background'),'style.title_color'=>array('.mnps-title,.mnps-product-name,.mnps-v2-cta h1,.mnps-v2-cta h2,.mnps-v2-cta h3','color'),'style.text_color'=>array('.mnps-description,.mnps-v2-cta .mnps-content','color'),'style.line_color'=>array('.mnps-title-line:before','background'),'style.button_text'=>array('.mnps-button','color'),'style.border_color'=>array('.mnps-card','border-color'),'archive.background'=>array('.mnps-archive-button','background'),'archive.hover'=>array('.mnps-archive-button:hover','background'),'archive.text'=>array('.mnps-archive-button','color'));
        foreach((($g['type']??'products')==='products'&&isset($g['customize'])&&!$g['customize']?array():($g['paint']??array()))as$k=>$p){if(!isset($map[$k]))continue;list($selector,$prop)=$map[$k];if($prop==='color'&&strpos($selector,'button')!==false&& !empty($p['on'])){if($k==='archive.text')$html=preg_replace('/(<a[^>]*class="mnps-archive-button[^>]*>)(.*?)(<\/a>)/s','$1<span class="mnps-paint-label">$2</span>$3',$html);else $html=preg_replace('/(<a[^>]*class="mnps-button[^>]*>)(.*?)(<\/a>)/s','$1<span class="mnps-paint-label">$2</span>$3',$html);$selector.=' .mnps-paint-label';}$selectors=explode(',',$selector);$selector=implode(',',array_map(function($s)use($id){return '#'.$id.' '.$s;},$selectors));$value=self::paint_value($p,'');if($prop==='border-color'&&!empty($p['on']))$rules.=$selector.'{border-image:'.$value.' 1}';elseif($prop==='color'&&!empty($p['on']))$rules.=$selector.'{background-image:'.$value.';background-clip:text;-webkit-background-clip:text;color:transparent}';else $rules.=$selector.'{'.$prop.':'.$value.'}';}
        if(!$preview&&!empty($g['schedule']['enabled']))$html='<div class="mnps-scheduled" data-mnps-end="'.absint($g['schedule']['end']).'">'.$html.'</div>';
        if(!$preview&&!empty($g['schedule']['enabled']))wp_enqueue_script('mnps-front');
        if(!$rules)return $html;return '<div id="'.$id.'" class="mnps-painted"><style>'.$rules.'</style>'.$html.'</div>';
    }
}
