<?php
namespace Mojtabanaseri\ArticleProducts;
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
final class Appearance {
    public static function defaults() {
        return array( 'accent' => '#086779', 'background' => '#f5f7f8', 'card_background' => '#ffffff', 'title_color' => '#1e293b', 'text_color' => '#64748b', 'button_text' => '#ffffff', 'border_color' => '#e2e8f0', 'line_color'=>'#086779', 'title_icon_size'=>20,'button_icon_size'=>18,'arrow_icon_size'=>18,'radius' => 10, 'card_radius' => 8, 'button_radius' => 6, 'padding' => 16, 'gap' => 12, 'product_size'=>15,'product_mobile_size'=>15,'price_size'=>15,'price_mobile_size'=>15,'title_size' => 21, 'text_size' => 14, 'button_size' => 14, 'shadow' => 'soft' );
    }
    public static function clean( $raw ) {
        if ( ! is_array( $raw ) ) {
            return array();
        }
        $out = array();
        foreach ( array( 'accent','hover','background','card_background','title_color','text_color','button_text','border_color','line_color' ) as $key ) {
            if ( isset( $raw[$key] ) && is_string( $raw[$key] ) && sanitize_hex_color( $raw[$key] ) ) {
                $out[$key] = sanitize_hex_color( $raw[$key] );
            }
        }
        foreach ( self::limits() as $key=>$bounds ) {
            if ( isset( $raw[$key] ) && is_scalar( $raw[$key] ) && is_numeric( $raw[$key] ) ) {
                $out[$key] = max( $bounds[0], min( $bounds[1], (int) $raw[$key] ) );
            }
        }
        if ( isset( $raw['shadow'] ) && in_array( $raw['shadow'], array('none','soft','strong'), true ) ) {
            $out['shadow']=$raw['shadow'];
        }
        return $out;
    }
    public static function limits(){
        return array('product_size'=>array(10,40),'product_mobile_size'=>array(10,32),'price_size'=>array(10,40),'price_mobile_size'=>array(10,32),'radius'=>array(0,48),'card_radius'=>array(0,40),'button_radius'=>array(0,40),'padding'=>array(0,64),'gap'=>array(0,40),'title_size'=>array(12,42),'text_size'=>array(11,24),'button_size'=>array(11,22),'title_icon_size'=>array(8,64),'button_icon_size'=>array(8,64),'arrow_icon_size'=>array(8,40));
    }
    public static function current( $overrides = array() ) {
        $saved = get_option( 'mnps_appearance', array() );
        return array_merge( self::defaults(), self::clean($saved), self::clean($overrides) );
    }
    public static function css( $overrides = array() ) {
        $a = self::current( $overrides );
        $out = '';
        foreach ( $a as $key=>$value ) {
            if ( 'shadow' === $key ) {
                $value = 'none' === $value ? 'none' : ( 'strong' === $value ? '0 18px 48px rgba(15,23,42,.14)' : '0 10px 32px rgba(15,23,42,.07)' );
            }
            elseif ( is_int($value) ) {
                $value .= 'px';
            }
            $out .= '--mnps-' . str_replace('_','-',$key) . ':' . $value . ';';
        }
        return $out;
    }
    public static function attachment( $value ) {
        $id = is_scalar( $value ) ? absint( $value ) : 0;
        if ( ! $id || 'attachment' !== get_post_type( $id ) ) {
            return 0;
        }
        $mime = get_post_mime_type($id);
        return in_array($mime, array('image/jpeg','image/png','image/webp','image/gif','image/avif','image/svg+xml'),true) ? $id : 0;
    }
    public static function code($raw) {
        $out=array();
        $raw=is_array($raw)?$raw:array();
        foreach(array('global','desktop','tablet','mobile','js')as$key){
            $out[$key]=isset($raw[$key])&&is_string($raw[$key])?self::clip(str_replace("\0",'', $raw[$key]),12000):'';
        }
        return $out;
    }
    public static function cta( $raw ) {
        $raw=is_array($raw)?$raw:array();
        $text=function($key,$max)use($raw){
            return isset($raw[$key]) && is_scalar($raw[$key])?self::clip(sanitize_textarea_field((string)$raw[$key]),$max):'';
        }
        ;
        $url=isset($raw['url']) && is_string($raw['url'])?esc_url_raw($raw['url'],array('http','https','mailto','tel')):'';
        return array('description'=>$text('description',1500),'button_label'=>$text('button_label',100) ?: __('بیشتر بدانید', 'mojtabanaseri-article-products'),'url'=>$url,'new_tab'=>!empty($raw['new_tab']), 'image'=>self::attachment($raw['image']??0),'icon_media'=>self::attachment($raw['icon_media']??0),'icon'=>isset($raw['icon'])&&in_array($raw['icon'],array('arrow','bag','phone','check','none'),true)?$raw['icon']:'arrow','image_mode'=>in_array($raw['image_mode']??'side',array('side','background','none'),true)?($raw['image_mode']??'side'):'side','layout'=>isset($raw['layout'])&&in_array($raw['layout'],array('horizontal','vertical'),true)?$raw['layout']:'horizontal');
    }
    private static function clip($text,$length) {
        $chars=preg_split('//u',$text,-1,PREG_SPLIT_NO_EMPTY);
        return is_array($chars)?implode('',array_slice($chars,0,$length)):substr($text,0,$length);
    }
    public static function icon($name) {
        $paths=array('left'=>'<path d="m14 6-6 6 6 6"/>','right'=>'<path d="m10 6 6 6-6 6"/>','plus'=>'<path d="M12 5v14M5 12h14"/>','grid'=>'<rect x="3" y="3" width="7" height="7" rx="2"/><rect x="14" y="3" width="7" height="7" rx="2"/><rect x="3" y="14" width="7" height="7" rx="2"/><rect x="14" y="14" width="7" height="7" rx="2"/>','copy'=>'<rect x="8" y="8" width="12" height="12" rx="3"/><path d="M16 8V5a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h3"/>','arrow'=>'<path d="M19 12H5m6-6-6 6 6 6"/>','bag'=>'<path d="M5 7h14l1 14H4L5 7Zm3 0V5a4 4 0 0 1 8 0v2"/>','phone'=>'<path d="M6 3h4l1 5-3 2a15 15 0 0 0 6 6l2-3 5 1v4c0 2-2 3-4 3C9 20 4 15 3 7c0-2 1-4 3-4Z"/>','check'=>'<path d="m5 12 4 4L19 6"/>');
        $paths+=array('trash'=>'<path d="M3 6h18M9 6V3h6v3M5 6l1 15h12l1-15M10 10v7M14 10v7"/>','off'=>'<circle cx="12" cy="12" r="8"/><path d="m8 8 8 8"/>','mixed'=>'<circle cx="12" cy="12" r="8"/><path d="M8 12h8"/>','edit'=>'<path d="m15 4 5 5M4 20l5-1L20 8a2 2 0 0 0-4-4L5 15l-1 5Z"/>','save'=>'<path d="M5 3h12l4 4v14H3V3h2Zm2 0v6h9V3M7 21v-8h10v8"/>');
        return isset($paths[$name])?'<svg class="mnps-cta-icon" viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">'.$paths[$name].'</svg>':'';
    }
    public static function title($g,$id='') {
        if(empty($g['title'])||!empty($g['hide_title'])){
            return '';
        }
        $tag=$g['title_tag']??'p';
        if(!in_array($tag,array('p','div','span','h1','h2','h3','h4','h5','h6'),true)){
            $tag='p';
        }
        return '<'.$tag.' class="mnps-title'.((!isset($g['title_line'])||$g['title_line'])?' mnps-title-line':'').'"'.($id?' id="'.esc_attr($id).'"':'').'>'.(!empty($g['title_icon'])?self::media_icon($g['title_icon'],''):'').esc_html($g['title']).'</'.$tag.'>';
    }
    public static function media_icon($id,$default) {
        return $id?wp_get_attachment_image($id,'thumbnail',false,array('class'=>'mnps-cta-icon','alt'=>'','loading'=>'lazy')):self::icon($default);
    }
    public static function widget_controls($s){
        $out=array();
        foreach(array('hide_title','title_line','show_price','show_badge','show_button')as$k){
            if(isset($s['box_'.$k])&&in_array($s['box_'.$k],array('yes','no'),true)){
                $out[$k]='yes'===$s['box_'.$k];
            }
        }
        if(!empty($s['box_title_tag'])){
            $out['title_tag']=$s['box_title_tag'];
        }
        if(!empty($s['box_button_label'])){
            $out['button_label']=$s['box_button_label'];
        }
        foreach(array('button_icon','left_icon','right_icon')as$k){
            if(!empty($s['box_'.$k]['id'])){
                $out[$k]=self::attachment($s['box_'.$k]['id']);
            }
        }
        return $out;
    }
}
