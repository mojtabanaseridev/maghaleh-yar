<?php
/** Compact rich-banner Elementor widget. @package Lumi */
defined( 'ABSPATH' ) || exit;

/** Four texts, two buttons and one optional card with progressive disclosure. */
final class LUMI_Slider extends LUMI_Widget {
	/** Stable widget identifier preserves existing documents. */
	public function get_name() { return 'lumi_slider'; }
	/** Panel label. */
	public function get_title() { return esc_html__( 'اسلایدر لومی', 'lumi' ); }
	/** Native panel icon, without a New badge. */
	public function get_icon() { return 'eicon-slides'; }
	/** Safe title tags. @return array */
	private function tags() { return array( 'h1' => 'H1', 'h2' => 'H2', 'h3' => 'H3', 'h4' => 'H4', 'p' => 'P', 'div' => 'DIV', 'span' => 'SPAN' ); }

	/** Normalize legacy rows without deleting content or overriding explicit new switches. @param array $row Saved values. @return array */
	private function normalize_slide( $row ) {
		$legacy = empty( $row['_lumi_version'] );
		$defaults = array( '_id' => '', '_lumi_version' => '2', 'nav_title' => '', 'background' => array(), 'background_mobile' => array(), 'card_mode' => 'product', 'product_id' => 0, 'card_image' => array(), 'card_title' => '', 'card_subtitle' => '', 'card_description' => '', 'card_price' => '', 'card_link' => array(), 'card_button' => __( 'مشاهده محصول', 'lumi' ) );
		$defaults['mobile_background_enabled'] = ! empty( $row['background_mobile']['id'] ) ? 'yes' : '';
		$defaults['show_card'] = ! empty( $row['card_mode'] ) && 'none' !== $row['card_mode'] ? 'yes' : '';
		for ( $n = 1; $n <= 4; $n++ ) {
			$defaults[ 'text_' . $n ] = '';
			$defaults[ 'show_text_' . $n ] = ( $legacy ? ! empty( $row[ 'text_' . $n ] ) : 2 === $n ) ? 'yes' : '';
			$defaults[ 'tag_' . $n ] = 2 === $n ? 'h2' : 'div';
			$defaults[ 'icon_' . $n ] = array();
			$defaults[ 'icon_position_' . $n ] = 'before';
			$defaults[ 'show_icon_' . $n ] = ! empty( $row[ 'icon_' . $n ]['value'] ) ? 'yes' : '';
		}
		for ( $n = 1; $n <= 2; $n++ ) {
			$defaults[ 'show_button_' . $n ] = $legacy && ! empty( $row[ 'button_text_' . $n ] ) ? 'yes' : '';
			$defaults[ 'button_text_' . $n ] = '';
			$defaults[ 'button_link_' . $n ] = array();
			$defaults[ 'button_icon_' . $n ] = array();
			$defaults[ 'show_button_icon_' . $n ] = ! empty( $row[ 'button_icon_' . $n ]['value'] ) ? 'yes' : '';
		}
		if ( isset( $row['card_mode'] ) && 'none' === $row['card_mode'] ) { $row['card_mode'] = 'product'; }
		return wp_parse_args( $row, $defaults );
	}


	/** Seed per-document visibility before the native cached controls are read. @param array $settings Input. @return array */
	protected function prepare_saved_settings( $settings ) {
		$flags = array( 'lumi_has_card' => '' );
		for ( $n = 1; $n <= 4; $n++ ) { $flags[ 'lumi_has_text_' . $n ] = ''; $flags[ 'lumi_has_icon_' . $n ] = ''; }
		for ( $n = 1; $n <= 2; $n++ ) { $flags[ 'lumi_has_button_' . $n ] = ''; }
		if ( isset( $settings['slides'] ) && is_array( $settings['slides'] ) ) {
			foreach ( $settings['slides'] as $index => $saved ) {
				if ( ! is_array( $saved ) ) { continue; }
				$row = $this->normalize_slide( $saved );
				$settings['slides'][ $index ] = $row;
				for ( $n = 1; $n <= 4; $n++ ) {
					if ( 'yes' === $row[ 'show_text_' . $n ] ) { $flags[ 'lumi_has_text_' . $n ] = 'yes'; if ( 'yes' === $row[ 'show_icon_' . $n ] ) { $flags[ 'lumi_has_icon_' . $n ] = 'yes'; } }
				}
				for ( $n = 1; $n <= 2; $n++ ) { if ( 'yes' === $row[ 'show_button_' . $n ] ) { $flags[ 'lumi_has_button_' . $n ] = 'yes'; } }
				if ( 'yes' === $row['show_card'] ) { $flags['lumi_has_card'] = 'yes'; }
			}
		}
		return array_merge( $settings, $flags, array( 'lumi_legacy_map' => '[]' ) );
	}

	/** Stored rows are used only to seed native visibility and non-destructive migration. @return array */
	private function stored_rows() {
		$raw = $this->lumi_saved_settings;
		return is_array( $raw ) && ! empty( $raw['slides'] ) && is_array( $raw['slides'] ) ? array_values( array_filter( $raw['slides'], 'is_array' ) ) : array();
	}

	/** Seed aggregate hidden flags; editor updates them when repeater switches change. */
	private function visibility_controls() {
		$flags = array( 'lumi_has_card' => '' );
		for ( $n = 1; $n <= 4; $n++ ) { $flags[ 'lumi_has_text_' . $n ] = 2 === $n ? 'yes' : ''; $flags[ 'lumi_has_icon_' . $n ] = ''; }
		for ( $n = 1; $n <= 2; $n++ ) { $flags[ 'lumi_has_button_' . $n ] = ''; }
		foreach ( $flags as $id => $value ) { $this->add_control( $id, array( 'type' => \Elementor\Controls_Manager::HIDDEN, 'default' => $value, 'render_type' => 'ui' ) ); }
		$this->add_control( 'lumi_legacy_map', array( 'type' => \Elementor\Controls_Manager::HIDDEN, 'default' => '[]', 'render_type' => 'ui' ) );
	}

	/** Register four compact native repeater tabs and common controls. */
	protected function register_controls() {
		$this->start_controls_section( 'slides_content', array( 'label' => esc_html__( 'اسلایدها', 'lumi' ) ) );
		$this->visibility_controls();
		$rep = new \Elementor\Repeater();
		$rep->add_control( '_lumi_version', array( 'type' => \Elementor\Controls_Manager::HIDDEN, 'default' => '2' ) );
		$rep->add_control( 'nav_title', array( 'label' => esc_html__( 'نام اسلاید', 'lumi' ), 'type' => \Elementor\Controls_Manager::TEXT, 'placeholder' => esc_html__( 'مثلاً مجموعه پاییز', 'lumi' ), 'label_block' => true ) );
		$rep->start_controls_tabs( 'slide_parts' );
		$rep->start_controls_tab( 'slide_image', array( 'label' => esc_html__( 'تصویر', 'lumi' ) ) );
		$rep->add_control( 'background', array( 'label' => esc_html__( 'تصویر اصلی', 'lumi' ), 'type' => \Elementor\Controls_Manager::MEDIA ) );
		$this->toggle( $rep, 'mobile_background_enabled', esc_html__( 'تصویر جدا برای موبایل', 'lumi' ), false );
		$rep->add_control( 'background_mobile', array( 'label' => esc_html__( 'تصویر موبایل', 'lumi' ), 'type' => \Elementor\Controls_Manager::MEDIA, 'condition' => array( 'mobile_background_enabled' => 'yes' ) ) );
		$rep->end_controls_tab();
		$rep->start_controls_tab( 'slide_texts', array( 'label' => esc_html__( 'متن', 'lumi' ) ) );
		for ( $n = 1; $n <= 4; $n++ ) {
			$on = array( 'show_text_' . $n => 'yes' );
			$this->toggle( $rep, 'show_text_' . $n, sprintf( esc_html__( 'عنوان %s', 'lumi' ), $n ), 2 === $n );
			$rep->add_control( 'text_' . $n, array( 'label' => esc_html__( 'متن', 'lumi' ), 'type' => \Elementor\Controls_Manager::TEXTAREA, 'rows' => 2, 'placeholder' => esc_html__( 'متن این بخش را بنویسید', 'lumi' ), 'condition' => $on ) );
			$rep->add_control( 'tag_' . $n, array( 'label' => esc_html__( 'تگ HTML', 'lumi' ), 'type' => \Elementor\Controls_Manager::SELECT, 'options' => $this->tags(), 'default' => 2 === $n ? 'h2' : 'div', 'condition' => $on ) );
			$this->toggle( $rep, 'show_icon_' . $n, esc_html__( 'آیکن کنار متن', 'lumi' ), false, $on );
			$icon_on = array_merge( $on, array( 'show_icon_' . $n => 'yes' ) );
			$rep->add_control( 'icon_' . $n, array( 'label' => esc_html__( 'انتخاب آیکن', 'lumi' ), 'type' => \Elementor\Controls_Manager::ICONS, 'condition' => $icon_on ) );
			$rep->add_control( 'icon_position_' . $n, array( 'label' => esc_html__( 'جای آیکن', 'lumi' ), 'type' => \Elementor\Controls_Manager::SELECT, 'default' => 'before', 'options' => array( 'before' => esc_html__( 'قبل از متن', 'lumi' ), 'after' => esc_html__( 'بعد از متن', 'lumi' ) ), 'condition' => $icon_on ) );
		}
		$rep->end_controls_tab();
		$rep->start_controls_tab( 'slide_buttons', array( 'label' => esc_html__( 'دکمه', 'lumi' ) ) );
		for ( $n = 1; $n <= 2; $n++ ) {
			$on = array( 'show_button_' . $n => 'yes' );
			$this->toggle( $rep, 'show_button_' . $n, sprintf( esc_html__( 'دکمه %s', 'lumi' ), $n ), false );
			$rep->add_control( 'button_text_' . $n, array( 'label' => esc_html__( 'متن دکمه', 'lumi' ), 'type' => \Elementor\Controls_Manager::TEXT, 'placeholder' => esc_html__( 'مثلاً مشاهده محصولات', 'lumi' ), 'condition' => $on ) );
			$rep->add_control( 'button_link_' . $n, array( 'label' => esc_html__( 'لینک', 'lumi' ), 'type' => \Elementor\Controls_Manager::URL, 'placeholder' => 'https://example.com/shop/', 'options' => array( 'url', 'is_external', 'nofollow', 'custom_attributes' ), 'condition' => $on ) );
			$this->toggle( $rep, 'show_button_icon_' . $n, esc_html__( 'آیکن دکمه', 'lumi' ), false, $on );
			$rep->add_control( 'button_icon_' . $n, array( 'label' => esc_html__( 'انتخاب آیکن', 'lumi' ), 'type' => \Elementor\Controls_Manager::ICONS, 'condition' => array_merge( $on, array( 'show_button_icon_' . $n => 'yes' ) ) ) );
		}
		$rep->end_controls_tab();
		$rep->start_controls_tab( 'slide_card', array( 'label' => esc_html__( 'کارت', 'lumi' ) ) );
		$this->toggle( $rep, 'show_card', esc_html__( 'کارت محصول', 'lumi' ), false );
		$rep->add_control( 'card_mode', array( 'label' => esc_html__( 'منبع کارت', 'lumi' ), 'type' => \Elementor\Controls_Manager::SELECT, 'default' => 'product', 'options' => array( 'product' => esc_html__( 'محصول ووکامرس', 'lumi' ), 'manual' => esc_html__( 'ورود دستی', 'lumi' ) ), 'condition' => array( 'show_card' => 'yes' ) ) );
		$product_options = array();
		$editing = is_admin() || wp_doing_ajax() || \Elementor\Plugin::$instance->editor->is_edit_mode() || \Elementor\Plugin::$instance->preview->is_preview_mode();
		$products = $editing ? get_posts( array( 'post_type' => 'product', 'post_status' => 'publish', 'numberposts' => -1, 'orderby' => 'title', 'order' => 'ASC', 'update_post_meta_cache' => false, 'update_post_term_cache' => false ) ) : array();
		foreach ( $products as $product ) { $product_options[ $product->ID ] = $product->post_title . ' (#' . $product->ID . ')'; }
		$rep->add_control( 'product_id', array( 'label' => esc_html__( 'محصول', 'lumi' ), 'type' => \Elementor\Controls_Manager::SELECT2, 'options' => $product_options, 'placeholder' => esc_html__( 'یک محصول انتخاب کنید', 'lumi' ), 'label_block' => true, 'condition' => array( 'show_card' => 'yes', 'card_mode' => 'product' ) ) );
		$manual = array( 'show_card' => 'yes', 'card_mode' => 'manual' );
		$rep->add_control( 'card_image', array( 'label' => esc_html__( 'تصویر کارت', 'lumi' ), 'type' => \Elementor\Controls_Manager::MEDIA, 'condition' => $manual ) );
		foreach ( array( 'card_title' => esc_html__( 'عنوان', 'lumi' ), 'card_subtitle' => esc_html__( 'زیرعنوان', 'lumi' ), 'card_description' => esc_html__( 'توضیح کوتاه', 'lumi' ), 'card_price' => esc_html__( 'قیمت نمایشی', 'lumi' ) ) as $id => $label ) {
			$rep->add_control( $id, array( 'label' => $label, 'type' => \Elementor\Controls_Manager::TEXT, 'placeholder' => esc_html__( 'اختیاری؛ خالی = نمایش ندادن', 'lumi' ), 'label_block' => true, 'condition' => $manual ) );
		}
		$rep->add_control( 'card_link', array( 'label' => esc_html__( 'لینک کارت', 'lumi' ), 'type' => \Elementor\Controls_Manager::URL, 'placeholder' => 'https://example.com/product/', 'options' => array( 'url', 'is_external', 'nofollow', 'custom_attributes' ), 'condition' => $manual ) );
		$rep->add_control( 'card_button', array( 'label' => esc_html__( 'متن دکمه کارت', 'lumi' ), 'type' => \Elementor\Controls_Manager::TEXT, 'default' => __( 'مشاهده محصول', 'lumi' ), 'placeholder' => esc_html__( 'خالی = بدون دکمه', 'lumi' ), 'condition' => array( 'show_card' => 'yes' ) ) );
		$rep->end_controls_tab();
		$rep->end_controls_tabs();
		$this->add_control( 'slides', array( 'type' => \Elementor\Controls_Manager::REPEATER, 'fields' => $rep->get_controls(), 'title_field' => '{{{ nav_title || text_2 || ' . wp_json_encode( __( 'اسلاید', 'lumi' ) ) . ' }}}', 'default' => array( array( '_lumi_version' => '2', 'nav_title' => __( 'اسلاید اول', 'lumi' ), 'show_text_2' => 'yes', 'text_2' => __( 'عنوان اسلاید', 'lumi' ) ) ) ) );
		$this->end_controls_section();
		$this->start_controls_section( 'banner_layout', array( 'label' => esc_html__( 'چیدمان', 'lumi' ) ) );
		$this->responsive( 'banner_direction', array( 'label' => esc_html__( 'متن و کارت', 'lumi' ), 'type' => \Elementor\Controls_Manager::SELECT, 'default' => 'row', 'mobile_default' => 'column', 'options' => array( 'row' => esc_html__( 'کنار هم', 'lumi' ), 'row-reverse' => esc_html__( 'کنار هم معکوس', 'lumi' ), 'column' => esc_html__( 'زیر هم', 'lumi' ) ), 'selectors' => array( '{{WRAPPER}} .lumi-banner-inner' => 'flex-direction: {{VALUE}};' ) ) );
		$this->responsive( 'vertical_align', array( 'label' => esc_html__( 'تراز عمودی', 'lumi' ), 'type' => \Elementor\Controls_Manager::SELECT, 'default' => 'center', 'options' => array( 'flex-start' => esc_html__( 'بالا', 'lumi' ), 'center' => esc_html__( 'وسط', 'lumi' ), 'flex-end' => esc_html__( 'پایین', 'lumi' ) ), 'selectors' => array( '{{WRAPPER}} .lumi-banner-inner' => 'align-items: {{VALUE}};' ) ) );
		$this->responsive( 'text_align', array( 'label' => esc_html__( 'تراز متن', 'lumi' ), 'type' => \Elementor\Controls_Manager::CHOOSE, 'options' => array( 'start' => array( 'title' => esc_html__( 'ابتدا', 'lumi' ), 'icon' => 'eicon-text-align-right' ), 'center' => array( 'title' => esc_html__( 'وسط', 'lumi' ), 'icon' => 'eicon-text-align-center' ), 'end' => array( 'title' => esc_html__( 'انتها', 'lumi' ), 'icon' => 'eicon-text-align-left' ) ), 'selectors' => array( '{{WRAPPER}} .lumi-content' => 'text-align: {{VALUE}};' ) ) );
		$this->toggle( $this, 'above_fold', esc_html__( 'اسلایدر بالای صفحه است', 'lumi' ), true );
		$this->end_controls_section();
		$this->motion_controls();
		$this->start_controls_section( 'background_style', array( 'label' => esc_html__( 'تصویر بنر', 'lumi' ), 'tab' => \Elementor\Controls_Manager::TAB_STYLE ) );
		$this->add_group_control( \Elementor\Group_Control_Image_Size::get_type(), array( 'name' => 'background', 'label' => esc_html__( 'رزولوشن تصویر بنر', 'lumi' ), 'default' => 'full', 'exclude' => array( 'custom' ) ) );
		$this->dimension( 'banner_height', esc_html__( 'ارتفاع بنر', 'lumi' ), '{{WRAPPER}} .lumi-banner-inner', 'min-height', 1200, array( 'px' ) );
		$this->responsive( 'bg_position', array( 'label' => esc_html__( 'جایگاه تصویر', 'lumi' ), 'type' => \Elementor\Controls_Manager::SELECT, 'default' => 'center center', 'options' => array( 'center center' => esc_html__( 'وسط', 'lumi' ), 'left center' => esc_html__( 'چپ', 'lumi' ), 'right center' => esc_html__( 'راست', 'lumi' ), 'center top' => esc_html__( 'بالا', 'lumi' ), 'center bottom' => esc_html__( 'پایین', 'lumi' ) ), 'selectors' => array( '{{WRAPPER}} .lumi-background img' => 'object-position: {{VALUE}};' ) ) );
		$this->toggle( $this, 'overlay_enabled', esc_html__( 'پوشش رنگی تصویر', 'lumi' ), true );
		$this->color( 'overlay_color', esc_html__( 'رنگ پوشش', 'lumi' ), '{{WRAPPER}} .lumi-overlay', 'background', array( 'overlay_enabled' => 'yes' ) );
		$this->end_controls_section();
		for ( $n = 1; $n <= 4; $n++ ) { $this->text_styles( 'text' . $n, sprintf( esc_html__( 'عنوان %s', 'lumi' ), $n ), '.lumi-title-' . $n, array( 'lumi_has_text_' . $n => 'yes' ) ); }
		for ( $n = 1; $n <= 2; $n++ ) { $this->button_styles( $n ); }
		$this->card_controls();
		$this->nav_styles();
	}

	/** Common product-card appearance and mobile-only visibility. */
	private function card_controls() {
		$condition = array( 'lumi_has_card' => 'yes' );
		$this->start_controls_section( 'product_layout', array( 'label' => esc_html__( 'کارت محصول', 'lumi' ), 'tab' => \Elementor\Controls_Manager::TAB_STYLE, 'condition' => $condition ) );
		$this->dimension( 'product_width', esc_html__( 'عرض کارت', 'lumi' ), '{{WRAPPER}} .lumi-product-card', 'width', 600, array( 'px', '%' ) );
		$this->color( 'product_card_background', esc_html__( 'پس‌زمینه', 'lumi' ), '{{WRAPPER}} .lumi-product-card', 'background-color' );
		$this->color( 'product_card_color', esc_html__( 'رنگ متن', 'lumi' ), '{{WRAPPER}} .lumi-product-card' );
		$this->add_group_control( \Elementor\Group_Control_Typography::get_type(), array( 'name' => 'product_title_font', 'label' => esc_html__( 'عنوان', 'lumi' ), 'selector' => '{{WRAPPER}} .lumi-product-title' ) );
		$this->add_group_control( \Elementor\Group_Control_Typography::get_type(), array( 'name' => 'product_details_font', 'label' => esc_html__( 'جزئیات', 'lumi' ), 'selector' => '{{WRAPPER}} .lumi-product-body' ) );
		$this->toggle( $this, 'card_show_image', esc_html__( 'تصویر کارت', 'lumi' ), true );
		$this->add_group_control( \Elementor\Group_Control_Image_Size::get_type(), array( 'name' => 'product_image', 'label' => esc_html__( 'رزولوشن تصویر کارت', 'lumi' ), 'default' => 'woocommerce_thumbnail', 'exclude' => array( 'custom' ), 'condition' => array( 'card_show_image' => 'yes' ) ) );
		$this->responsive( 'product_direction', array( 'label' => esc_html__( 'چیدمان کارت', 'lumi' ), 'type' => \Elementor\Controls_Manager::SELECT, 'default' => 'column', 'mobile_default' => 'row', 'options' => array( 'column' => esc_html__( 'عمودی', 'lumi' ), 'row' => esc_html__( 'افقی', 'lumi' ), 'row-reverse' => esc_html__( 'افقی معکوس', 'lumi' ) ), 'selectors' => array( '{{WRAPPER}} .lumi-product-card' => 'flex-direction: {{VALUE}};' ) ) );
		$this->responsive( 'product_media_width', array( 'label' => esc_html__( 'عرض تصویر', 'lumi' ), 'type' => \Elementor\Controls_Manager::SLIDER, 'size_units' => array( '%' ), 'default' => array( 'size' => 100, 'unit' => '%' ), 'mobile_default' => array( 'size' => 30, 'unit' => '%' ), 'range' => array( '%' => array( 'min' => 10, 'max' => 100 ) ), 'selectors' => array( '{{WRAPPER}} .lumi-product-media' => 'width: {{SIZE}}%;' ), 'condition' => array( 'card_show_image' => 'yes' ) ) );
		$this->end_controls_section();
		$this->start_controls_section( 'mobile_card', array( 'label' => esc_html__( 'کارت محصول در موبایل', 'lumi' ), 'condition' => $condition ) );
		foreach ( array( 'card' => array( esc_html__( 'کل کارت', 'lumi' ), '.lumi-product-card' ), 'image' => array( esc_html__( 'تصویر', 'lumi' ), '.lumi-product-media' ), 'title' => array( esc_html__( 'عنوان', 'lumi' ), '.lumi-product-title' ), 'subtitle' => array( esc_html__( 'زیرعنوان', 'lumi' ), '.lumi-product-subtitle' ), 'price' => array( esc_html__( 'قیمت', 'lumi' ), '.lumi-product-price' ), 'description' => array( esc_html__( 'توضیح', 'lumi' ), '.lumi-product-description' ), 'button' => array( esc_html__( 'دکمه', 'lumi' ), '.lumi-product-button' ) ) as $id => $part ) {
			$dependent = 'card' === $id ? array() : array( 'mobile_hide_card!' => 'yes' );
			if ( 'image' === $id ) { $dependent['card_show_image'] = 'yes'; }
			$this->add_control( 'mobile_hide_' . $id, array( 'label' => sprintf( esc_html__( 'مخفی کردن %s', 'lumi' ), $part[0] ), 'type' => \Elementor\Controls_Manager::SWITCHER, 'return_value' => 'yes', 'selectors_dictionary' => array( 'yes' => 'none' ), 'selectors' => array( '(mobile){{WRAPPER}} ' . $part[1] => 'display: {{VALUE}};' ), 'condition' => $dependent ) );
		}
		$this->end_controls_section();
	}

	/** Resolve a safe product or manual card. @param array $slide Repeater values. @return array|null */
	private function card_data( $slide ) {
		if ( 'product' === $slide['card_mode'] ) {
			$product = wc_get_product( absint( $slide['product_id'] ) );
			if ( ! $product || 'publish' !== $product->get_status() || ! $product->is_visible() ) { return null; }
			return array( 'image' => $product->get_image_id(), 'title' => $product->get_name(), 'subtitle' => $product->get_sku(), 'description' => wp_trim_words( wp_strip_all_tags( $product->get_short_description() ), 24 ), 'price' => $product->get_price_html(), 'price_html' => true, 'link' => array( 'url' => $product->get_permalink() ) );
		}
		if ( 'manual' === $slide['card_mode'] ) {
			return array( 'image' => isset( $slide['card_image']['id'] ) ? absint( $slide['card_image']['id'] ) : 0, 'title' => $slide['card_title'], 'subtitle' => $slide['card_subtitle'], 'description' => $slide['card_description'], 'price' => $slide['card_price'], 'price_html' => false, 'link' => $slide['card_link'] );
		}
		return null;
	}

	/** Render the banner with responsive picture art direction. */
	protected function render() {
		$s = $this->get_settings_for_display();
		$slides = ! empty( $s['slides'] ) && is_array( $s['slides'] ) ? array_values( array_filter( $s['slides'], 'is_array' ) ) : array();
		$saved_rows = $this->stored_rows();
		foreach ( $slides as $key => $slide ) {
			$saved = isset( $saved_rows[ $key ] ) ? $saved_rows[ $key ] : $slide;
			$normalized = $this->normalize_slide( $saved );
			foreach ( $normalized as $field => $value ) { if ( ! array_key_exists( $field, $saved ) ) { $slide[ $field ] = $value; } }
			$slides[ $key ] = wp_parse_args( $slide, $normalized );
		}
		if ( ! $slides ) { return; }
		$labels = array();
		foreach ( $slides as $slide ) { $labels[] = isset( $slide['nav_title'] ) ? $slide['nav_title'] : ''; }
		$this->open_slider( $s, true, $labels );
		$total = count( $slides );
		$mobile = \Elementor\Plugin::$instance->breakpoints->get_breakpoints( 'mobile' )->get_value();
		foreach ( $slides as $i => $slide ) {
			echo '<div class="lumi-slide elementor-repeater-item-' . esc_attr( $slide['_id'] ) . '" role="group" aria-roledescription="' . esc_attr__( 'اسلاید', 'lumi' ) . '" aria-label="' . esc_attr( sprintf( __( '%1$s از %2$s', 'lumi' ), number_format_i18n( $i + 1 ), number_format_i18n( $total ) ) ) . '">';
			$bg_id = ! empty( $slide['background']['id'] ) ? absint( $slide['background']['id'] ) : 0;
			$mobile_id = 'yes' === $slide['mobile_background_enabled'] && ! empty( $slide['background_mobile']['id'] ) ? absint( $slide['background_mobile']['id'] ) : 0;
			if ( $bg_id || $mobile_id ) {
				echo '<picture class="lumi-background" aria-hidden="true">';
				if ( $mobile_id ) {
					$src = wp_get_attachment_image_url( $mobile_id, $s['background_size'] );
					$srcset = wp_get_attachment_image_srcset( $mobile_id, $s['background_size'] );
					if ( $src ) { echo '<source media="(max-width: ' . esc_attr( $mobile ) . 'px)" srcset="' . esc_attr( $srcset ? $srcset : $src ) . '" sizes="100vw">'; }
				}
				$this->image( $bg_id ? $bg_id : $mobile_id, $s['background_size'], '', 'lumi-bg-image', 0 === $i && 'yes' === $s['above_fold'] );
				echo '</picture>';
			}
			if ( 'yes' === $s['overlay_enabled'] ) { echo '<div class="lumi-overlay" aria-hidden="true"></div>'; }
			$has_buttons = ( 'yes' === $slide['show_button_1'] && '' !== trim( $slide['button_text_1'] ) ) || ( 'yes' === $slide['show_button_2'] && '' !== trim( $slide['button_text_2'] ) );
			$has_content = $has_buttons;
			for ( $n = 1; $n <= 4; $n++ ) { if ( 'yes' === $slide[ 'show_text_' . $n ] && '' !== trim( $slide[ 'text_' . $n ] ) ) { $has_content = true; } }
			echo '<div class="lumi-banner-inner">';
			if ( $has_content ) { echo '<div class="lumi-card lumi-content">'; }
			for ( $n = 1; $n <= 4; $n++ ) {
				if ( 'yes' === $slide[ 'show_text_' . $n ] ) { $this->title( $slide[ 'tag_' . $n ], 'lumi-title-' . $n, $slide[ 'text_' . $n ], 'yes' === $slide[ 'show_icon_' . $n ] ? $slide[ 'icon_' . $n ] : array(), $slide[ 'icon_position_' . $n ] ); }
			}
			if ( $has_buttons ) { echo '<div class="lumi-buttons">'; }
			for ( $n = 1; $n <= 2; $n++ ) {
				if ( 'yes' !== $slide[ 'show_button_' . $n ] || empty( $slide[ 'button_text_' . $n ] ) ) { continue; }
				echo '<a ';
				$this->link_attrs( 'button_' . $i . '_' . $n, $slide[ 'button_link_' . $n ], 'lumi-button lumi-button-' . $n );
				echo '><span>' . esc_html( $slide[ 'button_text_' . $n ] ) . '</span>';
				$this->icon( 'yes' === $slide[ 'show_button_icon_' . $n ] ? $slide[ 'button_icon_' . $n ] : array() );
				echo '</a>';
			}
			if ( $has_buttons ) { echo '</div>'; }
			if ( $has_content ) { echo '</div>'; }
			$card = 'yes' === $slide['show_card'] ? $this->card_data( $slide ) : null;
			if ( $card ) {
				echo '<article class="lumi-card lumi-product-card">';
				if ( 'yes' === $s['card_show_image'] ) {
					echo '<div class="lumi-product-media">';
					$this->image( $card['image'], $s['product_image_size'], $card['title'], 'lumi-product-image' );
					echo '</div>';
				}
				echo '<div class="lumi-product-body">';
				$this->title( 'h3', 'lumi-product-title', $card['title'] );
				$this->title( 'div', 'lumi-product-subtitle', $card['subtitle'] );
				$this->title( 'div', 'lumi-product-description', $card['description'] );
				if ( '' !== $card['price'] ) { echo '<div class="lumi-product-price">' . ( $card['price_html'] ? wp_kses_post( $card['price'] ) : esc_html( $card['price'] ) ) . '</div>'; }
				if ( ! empty( $slide['card_button'] ) ) {
					echo '<a '; $this->link_attrs( 'card_' . $i, $card['link'], 'lumi-button lumi-product-button' );
					echo '>' . esc_html( $slide['card_button'] ) . '</a>';
				}
				echo '</div></article>';
			}
			echo '</div></div>';
		}
		$this->close_slider( true, $s );
	}
}
