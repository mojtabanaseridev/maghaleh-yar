<?php
defined( 'ABSPATH' ) || exit;
/** Real WordPress/Elementor/WooCommerce assertions, loaded by wp eval-file. */
$GLOBALS['lumi_checks']=0;
function lumi_assert($ok,$label){ if(!$ok)throw new Exception($label);$GLOBALS['lumi_checks']++;echo "PASS $label\n";}
function lumi_widget($name,$settings=array()){
 return Elementor\Plugin::$instance->elements_manager->create_element_instance(array('id'=>uniqid('l'), 'elType'=>'widget','widgetType'=>$name,'settings'=>$settings));
}
function lumi_html($widget){ob_start();$widget->render_content();return ob_get_clean();}
$fixture=wp_insert_post(array('post_title'=>'Lumi integration fixture','post_status'=>'draft','post_type'=>'page'));
update_post_meta($fixture,'_elementor_edit_mode','builder');
$GLOBALS['post']=get_post($fixture);
$doc=Elementor\Plugin::$instance->documents->get($fixture);
Elementor\Plugin::$instance->documents->switch_to_document($doc);
$manager=Elementor\Plugin::$instance->widgets_manager;
foreach(array('lumi_slider','lumi_category_carousel') as $name){
 $type=$manager->get_widget_types($name);lumi_assert((bool)$type,"registered $name");$controls=$type->get_controls();
 lumi_assert(version_compare(ELEMENTOR_VERSION,'4.0','>=') ? isset($controls['_section_style']) : ((bool)$type->get_controls('_margin')&&(bool)$type->get_controls('_padding')),"native advanced $name");
 lumi_assert(!isset($controls['container_style'])&&!isset($controls['category_card_style']),"removed bloated sections $name");
 lumi_assert($controls['nav_style']['condition']===array('show_arrows'=>'yes'),"conditional arrow section $name");
 lumi_assert($controls['pagination_style']['condition']===array('dots'=>'yes'),"conditional pagination $name");
 lumi_assert(strpos($type->get_icon(),'new')===false,"no badge $name");
}
$rows=array(array('_id'=>'first','_lumi_version'=>'2','show_text_1'=>'','text_1'=>'HIDDEN TEXT','show_text_2'=>'yes','text_2'=>'Visible <script>alert(1)</script>','show_button_1'=>'','button_text_1'=>'HIDDEN BUTTON','show_card'=>'','card_mode'=>'manual','card_title'=>'HIDDEN CARD'));
$settings=array('_lumi_ui_version'=>'2','slides'=>$rows,'show_arrows'=>'','dots'=>'','autoplay'=>'','overlay_enabled'=>'');
$w=lumi_widget('lumi_slider',$settings);$html=lumi_html($w);
lumi_assert(strpos($html,'lumi-slider')!==false,'banner renders');
lumi_assert(strpos($html,'<script>alert')===false&&strpos($html,'&lt;script&gt;')!==false,'escaped banner text');
foreach(array('lumi-navigation','lumi-arrows','lumi-overlay','lumi-buttons','lumi-product-card','HIDDEN TEXT','HIDDEN BUTTON','HIDDEN CARD') as $token)lumi_assert(strpos($html,$token)===false,"disabled output absent $token");
$controls=$w->get_controls();$fields=$controls['slides']['fields'];lumi_assert($fields['text_1']['condition']===array('show_text_1'=>'yes'),'row text condition');lumi_assert($fields['card_title']['condition']===array('show_card'=>'yes','card_mode'=>'manual'),'manual card condition');
$settings['show_arrows']='yes';$settings['dots']='yes';$settings['arrow_icon_next']=array('value'=>'fas fa-chevron-right','library'=>'fa-solid');
$html=lumi_html(lumi_widget('lumi_slider',$settings));lumi_assert(substr_count($html,'data-action="next"')===1,'arrows enabled once');lumi_assert(strpos($html,'lumi-navigation" hidden')!==false,'pagination starts hidden until enhanced');lumi_assert(strpos($html,'class="lumi-icon"')!==false,'native selected icon rendered');
$settings['slides'][0]['show_button_1']='yes';$settings['slides'][0]['button_link_1']=array('url'=>'https://example.com/','is_external'=>'on','nofollow'=>'on','custom_attributes'=>'data-test|working');
$html=lumi_html(lumi_widget('lumi_slider',$settings));lumi_assert(strpos($html,'HIDDEN BUTTON')!==false,'switch re-enable keeps button value');lumi_assert(strpos($html,'data-test="working"')!==false&&strpos($html,'nofollow')!==false,'native link attributes');
$empty_settings=$settings;$empty_settings['slides'][0]['show_text_2']='';$empty_settings['slides'][0]['show_button_1']='';$html=lumi_html(lumi_widget('lumi_slider',$empty_settings));lumi_assert(strpos($html,'lumi-content')===false,'all text and buttons off removes content column');
$settings['slides'][0]['show_card']='yes';$settings['card_show_image']='';$html=lumi_html(lumi_widget('lumi_slider',$settings));lumi_assert(strpos($html,'HIDDEN CARD')!==false,'manual card renders when enabled');lumi_assert(strpos($html,'lumi-product-media')===false,'card image switch removes wrapper');
$old=lumi_widget('lumi_slider',array('slides'=>array(array('_id'=>'old','text_1'=>'Legacy title','button_text_1'=>'Legacy button','card_mode'=>'none'))));$html=lumi_html($old);lumi_assert(strpos($html,'Legacy title')!==false&&strpos($html,'Legacy button')!==false,'legacy content survives new switches');lumi_assert(strpos($html,'lumi-product-card')===false,'legacy none card stays hidden');lumi_assert($old->get_settings('lumi_has_text_1')==='yes','legacy style aggregate seeded per instance');
$term=wp_insert_term('Lumi Fixture Category','product_cat',array('slug'=>'lumi-fixture-category'));$tid=is_wp_error($term)?get_term_by('slug','lumi-fixture-category','product_cat')->term_id:$term['term_id'];
$cat=array('_lumi_ui_version'=>'2','category_items'=>array(array('_id'=>'cat','category'=>$tid)), 'show_arrows'=>'','dots'=>'','show_count'=>'yes','count_format'=>'%s products');
$html=lumi_html(lumi_widget('lumi_category_carousel',$cat));lumi_assert(strpos($html,'Lumi Fixture Category')!==false,'category fallback title');lumi_assert(strpos($html,'width="300"')!==false&&strpos($html,'height="300"')!==false,'placeholder dimensions');lumi_assert(strpos($html,'0 products')!==false,'count format');lumi_assert(strpos($html,'lumi-navigation')===false,'category pagination off no wrapper');
$cat['category_items']=array(array('_id'=>'invalid','category'=>999999));$html=lumi_html(lumi_widget('lumi_category_carousel',$cat));lumi_assert(strpos($html,'lumi-slider')===false,'deleted category no slider');
$html=lumi_html(lumi_widget('lumi_slider',array('_lumi_ui_version'=>'2','slides'=>array())));lumi_assert(strpos($html,'lumi-slider')===false,'zero slides no slider');
$css_settings=array('_lumi_ui_version'=>'2','category_items'=>array(array('_id'=>'csscat','category'=>$tid)), 'columns'=>2.3,'columns_tablet'=>2.3,'columns_mobile'=>2.3,'gap'=>array('size'=>17,'unit'=>'px'),'show_arrows'=>'','dots'=>'','arrow_size'=>array('size'=>24,'unit'=>'px'),'dot_size'=>array('size'=>8,'unit'=>'px'));
$data=array(array('id'=>'s1','elType'=>'section','settings'=>array(),'elements'=>array(array('id'=>'c1','elType'=>'column','settings'=>array(),'elements'=>array(array('id'=>'w1','elType'=>'widget','widgetType'=>'lumi_category_carousel','settings'=>$css_settings,'elements'=>array()))))));
update_post_meta($fixture,'_elementor_data',wp_slash(wp_json_encode($data)));
$css=new Elementor\Core\Files\CSS\Post($fixture);$css->update();$content=$css->get_content();
lumi_assert(strpos($content,'--lumi-cols:2.3')!==false,'fractional CSS generated by Elementor');
lumi_assert(strpos($content,'--lumi-gap:17px')!==false,'gap CSS generated by Elementor');
lumi_assert(strpos($content,'--lumi-arrow-size:24px')===false&&strpos($content,'--lumi-dot-size:8px')===false,'disabled navigation CSS omitted');
Elementor\Plugin::$instance->documents->restore_document();
$manual=array('_lumi_ui_version'=>'2','category_items'=>array(array('_id'=>'standalone','title'=>'Men<br><strong>Shoes</strong><span class="accent" style="color:red" onclick="alert(1)">New</span><script>alert(1)</script>','subtitle'=>'<em>Collection</em>','link'=>array('url'=>'#'))),'show_count'=>'yes','dots'=>'yes','category_pagination'=>'numbers');
$custom=lumi_widget('lumi_category_carousel',$manual);$html=lumi_html($custom);
lumi_assert(strpos($html,'Men<br><strong>Shoes</strong>')!==false,'category inline HTML supported');
lumi_assert(strpos($html,'<em>Collection</em>')!==false,'subtitle inline HTML supported');
lumi_assert(strpos($html,'onclick=')===false&&strpos($html,'<script>')===false,'category unsafe HTML stripped');
lumi_assert(strpos($html,'style="color:red"')!==false,'safe span formatting retained');
lumi_assert(strpos($html,'href="#"')!==false,'unbound custom item hash link');
lumi_assert(strpos($html,'lumi-count')===false,'unbound custom item no invented product count');
lumi_assert(strpos($html,'&quot;nav&quot;:&quot;numbers&quot;')!==false,'category pagination passed to engine');
$c=$custom->get_controls();
$align_control=$custom->get_controls('align');
lumi_assert(isset($align_control['tab'])&&$align_control['tab']===Elementor\Controls_Manager::TAB_STYLE,'existing alignment ID moved to Style');
lumi_assert(isset($c['hover_duration']['selectors']['{{WRAPPER}} .lumi-categories']),'hover duration scoped to category');
lumi_assert(isset($c['category_items']['fields']['_lumi_order']),'native repeater order field');
file_put_contents(ABSPATH.'lumi-title-template.json',wp_json_encode($c['category_items']['title_field']));
$manual['category_items']=array(array('_id'=>'empty','link'=>array('url'=>'#')));$html=lumi_html(lumi_widget('lumi_category_carousel',$manual));lumi_assert(strpos($html,'lumi-slider')===false,'empty custom row skipped');
$manual['category_items']=array(array('_id'=>'picture','image'=>array('id'=>999999)));$html=lumi_html(lumi_widget('lumi_category_carousel',$manual));lumi_assert(strpos($html,'lumi-slider')!==false,'image-only custom row allowed');
foreach(array('dots','lines','capsules','numbers') as $mode){
 $css_settings['dots']='yes';$css_settings['category_pagination']=$mode;$css_settings['pagination_align']='flex-end';$css_settings['hover_duration']=600;$css_settings['align']='start';
 $data[0]['elements'][0]['elements'][0]['settings']=$css_settings;
 update_post_meta($fixture,'_elementor_data',wp_slash(wp_json_encode($data)));
 $css=new Elementor\Core\Files\CSS\Post($fixture);$css->update();$content=$css->get_content();
 lumi_assert(strpos($content,'justify-content:flex-end')!==false,'pagination alignment CSS '.$mode);
 lumi_assert(strpos($content,'--lumi-hover:600ms')!==false,'hover duration CSS '.$mode);
 lumi_assert(strpos($content,'text-align:start')!==false,'category text alignment CSS '.$mode);
 if($mode==='lines')lumi_assert(strpos($content,'height:3px')!==false,'line preset CSS');
 if($mode==='capsules')lumi_assert(strpos($content,'border-radius:99px')!==false,'capsule preset CSS');
 if($mode==='numbers')lumi_assert(strpos($content,'font-size:12px')!==false,'number preset CSS');
}
wp_delete_term($tid,'product_cat');
wp_delete_post($fixture,true);
echo json_encode(array('passed'=>$GLOBALS['lumi_checks'],'wordpress'=>get_bloginfo('version'),'elementor'=>ELEMENTOR_VERSION,'woocommerce'=>WC_VERSION,'php'=>PHP_VERSION,'database'=>'SQLite'))."\n";
